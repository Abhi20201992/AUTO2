package com.excelExportAndFileIO;

import java.io.File;

import com.Utils.DateTimeStamp;

import log4j.Log;

public class ExportToExcel {
	static String sOutputFileName;
	static String sDateTimeStamp;
	static File destFile;

	public static void exportToExcel(String excelfilename) {
		ExcelDriver oExcelDriver = new ExcelDriver();
		sDateTimeStamp = DateTimeStamp.getDateTimeStamp();
		sOutputFileName = Constant.sResultFolder + "TestCases_for_" + excelfilename + "Result_as_on_" + sDateTimeStamp
				+ ".xlsx";

		oExcelDriver.saveAs(sOutputFileName);
	}

	public static String getExcelFile() throws Exception {

		destFile = new File(sOutputFileName);

		if (destFile != null) {
			Log.info("Result Excel File is given");
			System.out.println("Result Excel File is given");
			return destFile.getAbsolutePath();
		}

		Log.error("File is not available");
		System.out.println("File is not available");
		return null;

	}

}
