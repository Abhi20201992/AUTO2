package com.excelExportAndFileIO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import log4j.Log;

public class ExcelUtils {
	private static Sheet oExcelWSheet;
	private static Workbook oExcelWBook;
	private static Cell oCell;
	private static Row oRow;
	private InputStream oFileReader;
	private OutputStream oFileWriter;
	private String sExcelFileName;

	@SuppressWarnings("resource")
	public static void setExcelFile(String sPath, String SheetName) throws Exception {
		try {

			sPath = sPath.trim();

			FileInputStream ExcelFile = new FileInputStream(sPath);

			if (sPath.isEmpty()) {
				throw new Exception("Invalid path name..");
			}

			if (sPath.endsWith("xlsx")) {
				oExcelWBook = new XSSFWorkbook(ExcelFile);
				oExcelWSheet = oExcelWBook.getSheet(SheetName);
			} else if (sPath.endsWith("xls")) {
				oExcelWBook = new HSSFWorkbook(ExcelFile);
				oExcelWSheet = oExcelWBook.getSheet(SheetName);
			} else {
				throw new Exception("Invalid File Extension...");
			}

		
			Log.info("Xl File is Used here is" + ExcelFile + "Xl Sheet is getting Used here  :" + SheetName);
			System.out.println("Xl File is Used here is" + ExcelFile + "Xl Sheet is getting Used here  :" + SheetName);

		} catch (Exception e) {
			e.printStackTrace();
			Log.info("some error occured while setting Excel File :" + e);
			System.out.println("some error occured while setting Excel File :");

		}
	}

	public String getCellData(int RowNum, int ColNum) throws Exception {
		try {
			oCell = oExcelWSheet.getRow(RowNum).getCell(ColNum);

			String CellData;

			if (oCell.getCellTypeEnum() == CellType.NUMERIC) {
				CellData = NumberToTextConverter.toText(oCell.getNumericCellValue());
			} else {
				CellData = oCell.getStringCellValue();
			}

			/*
			 * if(DateUtil.isCellDateFormatted(Cell)) { CellData=Cell.getDateCellValue(); }
			 */

			Log.info("String received from Excel is :" + CellData);
			System.out.println("String received from Excel is :" + CellData);

			return CellData;
		} catch (Exception e) {
			e.printStackTrace();
			Log.info("String is not received from Excel :" + e);
			System.out.println("String is not received from Excel");
			return "";

		}
	}

	// This method is to write in the Excel cell, Row num and Col num are the
	// parameters
	public static void setCellData(String Result, int RowNum, int ColNum) throws Exception {
		try {
			oRow = oExcelWSheet.getRow(RowNum);
			oCell = oRow.getCell(ColNum, MissingCellPolicy.CREATE_NULL_AS_BLANK);

			if (oCell == null) {
				oCell = oRow.createCell(ColNum);
				oCell.setCellValue(Result);

			} else {
				oCell.setCellValue(Result);

			}

			Log.info("String entered to Excel for row" + RowNum + "and column" + ColNum + "is:" + Result);
			System.out.println("String entered to Excel for row" + RowNum + "and column" + ColNum + "is:" + Result);

			// Constant variables Test Data path and Test Data file name
			FileOutputStream fileOut = new FileOutputStream(Constant.Path_TestData + Constant.File_TestData);
			ZipSecureFile.setMinInflateRatio(-1.0d);
			oExcelWBook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (Exception e) {
			e.printStackTrace();
			Log.info("String  not entered to Excel for row" + RowNum + "and column" + ColNum + "is:" + Result);
			System.out
					.println("String  not entered to Excel for row" + RowNum + "and column" + ColNum + "is:" + Result);

		}
	}

	public void close() {
		try {
			oExcelWBook.close();
			oFileReader.close();

			Log.info("\n Work Book is Closed");
			System.out.println("\n Work Book is Closed");
		} catch (Exception e) {
			Log.error("\n There was a problem is closing WorkBook due to" + e);
			System.out.println("\n There was a problem is closing WorkBook");
			e.printStackTrace();
		}
	}

	public void createExcelWorkbook(String sFilename) {

		try {

			sFilename = sFilename.trim();

			if (sFilename.isEmpty()) {
				Log.error("\n Invalid file name..");
				System.out.println("\n Invalid file name..");
				throw new Exception("Invalid file name..");
			}

			if (new File(sFilename).exists()) {
				Log.error("\n File already exists..");
				System.out.println("\n File already exists..");
				throw new Exception("File already exists");
			}

			if (sFilename.endsWith("xlsx")) {
				oExcelWBook = new XSSFWorkbook();
			} else if (sFilename.endsWith("xls")) {
				oExcelWBook = new HSSFWorkbook();
			} else {
				throw new Exception("Invalid File Extension...");
			}

			oFileWriter = new FileOutputStream(sFilename);
			oExcelWBook.write(oFileWriter);
			oFileWriter.close();
			oExcelWBook.close();

			Log.info("\n Excel is Created with File Name" + sFilename);
			System.out.println("\n Excel is Created with File Name" + sFilename);

		} catch (Exception e) {

			Log.error("\n Excel is not Created with given File Name due to" + e);
			System.out.println("\n Excel is not Created with given File Name");
			e.printStackTrace();
		}

	}

	public void createSheet(String sSheetName) {
		try {

			sSheetName = sSheetName.trim();

			if (sSheetName.isEmpty()) {
				throw new Exception("Sheet name not specified..");
			}
			Sheet oSheet;
			oSheet = oExcelWBook.getSheet(sSheetName);

			if (oSheet != null) {
				Log.error("\n Sheet Already exist...");
				System.out.println("\n Sheet Already exist...");
				throw new Exception("Sheet Already exist...");
			}
			oExcelWBook.createSheet(sSheetName);
			Log.info("\n Sheet is Created with Name" + sSheetName);
			System.out.println("\n Sheet is Created with Name" + sSheetName);

		} catch (Exception e) {

			Log.error("\n Excel is not Created with given File Name due to" + e);
			System.out.println("\n Excel is not Created with given File Name");
			e.printStackTrace();
		}
	}

	public int getCellCount(String sSheetName, int iRow) {
		try {

			sSheetName = sSheetName.trim();

			if (sSheetName.isEmpty()) {
				throw new Exception("Sheet name not specified..");
			}

			Sheet oSheet;

			oSheet = oExcelWBook.getSheet(sSheetName);

			if (oSheet == null) {
				throw new Exception("Sheet doesnot exist...");
			}

			if (iRow < 1) {
				throw new Exception("Row Index start from 1");
			}

			Row oRow;

			oRow = oSheet.getRow(iRow);
			if (oRow == null) {
				return 0;
			} else {
				return oRow.getLastCellNum();
			}

		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

	public int getRowCountoFSheet(String sSheetName) {
		try {

			sSheetName = sSheetName.trim();

			if (sSheetName.isEmpty()) {
				throw new Exception("Sheet name not specified..");
			}

			Sheet oSheet;
			oSheet = oExcelWBook.getSheet(sSheetName);

			if (oSheet == null) {
				throw new Exception("Sheet doesnot exist...");
			}

			return oSheet.getLastRowNum();

		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

	public void openExcelWorkbook(String sFileName) {
		try {

			sFileName = sFileName.trim();

			if (sFileName.isEmpty()) {
				throw new Exception("File Name not specified");
			}

			if (!(new File(sFileName)).exists()) {
				throw new Exception("File doesnot exist.. ");
			}

			oFileReader = new FileInputStream(sFileName);
			sExcelFileName = sFileName;
			oExcelWBook = WorkbookFactory.create(oFileReader);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public void save() {
		try {

			oFileWriter = new FileOutputStream(sExcelFileName);
			oExcelWBook.write(oFileWriter);

			oFileWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void saveAs(String sFileNewName) {
		try {
			sFileNewName = sFileNewName.trim();
			if (sFileNewName.isEmpty()) {
				throw new Exception("File name does not exists");
			}

			if ((new File(sFileNewName)).exists()) {
				throw new Exception("File already exists");
			}

			oFileWriter = new FileOutputStream(sFileNewName);
			oExcelWBook.write(oFileWriter);
			oFileWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
