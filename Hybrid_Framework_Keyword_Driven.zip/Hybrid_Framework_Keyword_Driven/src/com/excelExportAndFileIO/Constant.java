package com.excelExportAndFileIO;


public class Constant {
	public static final String Path_TestData = System.getProperty("user.dir") + "\\TestCasesExcelOutputFiles\\";
	
	public static String File_TestData;
	public static final String sResultFolder = System.getProperty("user.dir") + "\\TestCasesExcelOutputFiles\\";
	public static final int ActionKeywordColumn=10;
	public static final int ObjectLocatorColumn=11;
	public static final int ObjectTypeColumn=12;
	public static final int ArgumentValueColumn=13;
	
	static String SupportingFiles = System.getProperty("user.dir") + "\\Supporting Files";
	public static String TestCasesInputFolder=System.getProperty("user.dir") +"\\TestCasesExcelInputFiles";

	public static String fileName="PerfData.xlsx";
	public static String sheetName="PerfData";

	public static final String BaseUrl = "https://mfcomb.birlasunlife.com/";
	
	public static final String IEBrowserAuth=SupportingFiles +"\\smsappIEAuth64.exe";
	public static final String ChromeDriverPath = SupportingFiles +"\\chromedriver.exe";
	public static final String FireFoxDriverPath = SupportingFiles +"\\geckodriver.exe";
	public static final String IEDriverPath = SupportingFiles + "\\IEDriverServer.exe";
	public static final String ChromeBrowserAuth = SupportingFiles + "\\smsappAuth64.exe";
	
	public static final String SiteUserAuth = SupportingFiles + "\\SiteUserAuth64.exe";
	public static final String MailTo="abhijay.ghadyale@adityabirlacapital.com";
	public static final String MailFrom="Automation_Testing_Team@adityabirlacapital.com";
	public static final String smtpHost="smtp.bsli.com";
	public static final String subject = "Automation Status(Automatically Generated Email)";

	public static final String TestCasesOutputFolder = System.getProperty("user.dir") +"\\TestCasesExcelOutputFiles";;
	
	
	public static String getfile_TestData() {
		return File_TestData;
	}

	public static String setfile_TestData(String FileNameWithExtn) {
		return Constant.File_TestData = FileNameWithExtn;
	}

}
