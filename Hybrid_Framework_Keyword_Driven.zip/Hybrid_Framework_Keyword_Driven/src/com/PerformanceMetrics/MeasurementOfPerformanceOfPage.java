package com.PerformanceMetrics;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.CommonDriver.CommonDriverControls;
import com.excelExportAndFileIO.Constant;
import com.excelExportAndFileIO.ExcelUtils;

import log4j.Log;

public class MeasurementOfPerformanceOfPage {

	public static void measurePerformanceOfPageinMillisec(String value) throws Exception {

		WebDriver driver = CommonDriverControls.getdriver();

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData(Constant.fileName),Constant.sheetName);
	
		try {
			JavascriptExecutor js = ((JavascriptExecutor) driver);
			
			/*long redirectTime =(Long) js.executeScript("return (window.performance.timing.redirectStart-window.performance.timing.redirectEnd)");
			long unloadTime=(Long) js.executeScript("return (window.performance.timing.unloadEventStart-window.performance.timing.unloadEventEnd)");
			
			long AppCacheTime=(Long) js.executeScript("return (window.performance.timing.fetchStart-window.performance.timing.domainLookupStart)");
			
			long DNSTime=(Long) js.executeScript("return (window.performance.timing.domainLookupStart-window.performance.timing.domainLookupEnd)");
			long TcpTime=(Long) js.executeScript("return (window.performance.timing.connectStart-window.performance.timing.connectEnd)");
			
            long SSLTime=(Long) js.executeScript("return (window.performance.timing.secureConnectionStart-window.performance.timing.connectEnd)");
						

            long requestTime=(Long) js.executeScript("return (window.performance.timing.requestStart-window.performance.timing.responseStart)");
		    long responseTime=(Long) js.executeScript("return (window.performance.timing.responseStart-window.performance.timing.responseEnd)");
			*/
		
			
			long navigationStart=(Long) js.executeScript("return (window.performance.timing.navigationStart)");
			long redirectStart=(Long) js.executeScript("return (window.performance.timing.redirectStart)");
			long redirectEnd=(Long) js.executeScript("return ( window.performance.timing.redirectEnd)");
			long fetchStart=(Long) js.executeScript("return (window.performance.timing.fetchStart)");
			long domainLookupStart=(Long) js.executeScript("return (window.performance.timing.domainLookupStart)");
			long domainLookupEnd=(Long) js.executeScript("return (window.performance.timing.domainLookupEnd)");
			long connectStart=(Long) js.executeScript("return (window.performance.timing.connectStart)");
			long secureConnectionStart=(Long) js.executeScript("return (window.performance.timing.secureConnectionStart)");
			long connectEnd=(Long) js.executeScript("return (window.performance.timing.connectEnd)");
			long requestStart=(Long) js.executeScript("return (window.performance.timing.requestStart)");
			long responseStart=(Long) js.executeScript("return (window.performance.timing.responseStart)");
			long responseEnd=(Long) js.executeScript("return (window.performance.timing.responseEnd)");
			long unloadEventStart=(Long) js.executeScript("return (window.performance.timing.unloadEventStart)");
			long unloadEventEnd=(Long) js.executeScript("return (window.performance.timing.unloadEventEnd)");
			long domLoading=(Long) js.executeScript("return (window.performance.timing.domLoading)");
			long domInteractive=(Long) js.executeScript("return (window.performance.timing.domInteractive)");
			long domContentLoadedEventStart=(Long) js.executeScript("return (window.performance.timing.domContentLoadedEventStart)");
			long domContentLoadedEventEnd=(Long) js.executeScript("return (window.performance.timing.domContentLoadedEventEnd)");
			long domComplete=(Long) js.executeScript("return (window.performance.timing.domComplete)");
			long loadEventEnd=(Long) js.executeScript("return (window.performance.timing.loadEventEnd)");
			long loadEventStart=(Long) js.executeScript("return (window.performance.timing.loadEventStart)");
					    
		    
			//long Timing=(Long) js.executeScript("return (window.performance.timing)");
		    
		    
			//System.out.println("Timing :" + Timing);
			System.out.println("Performance Metrics For-:"+driver.getTitle());
			System.out.println("navigationStart Time :" + navigationStart);
		    System.out.println("redirectStart Time :" + redirectStart);
		    System.out.println("redirectEnd Time :" + redirectEnd);
		    System.out.println("fetchStart Time :" + fetchStart);
		    System.out.println("domainLookupStart Time :" + domainLookupStart);
		    System.out.println("domainLookupEnd Time :" + domainLookupEnd);
		    System.out.println("connectStart Time :" + connectStart);
		    System.out.println("secureConnectionStart Time :" + secureConnectionStart);
		    System.out.println("connectEnd Time :" + connectEnd); 		  
		    System.out.println("requestStart Time :" + requestStart);
		    System.out.println("responseStart Time :" + responseStart);
		    System.out.println("responseEnd Time :" + responseEnd);
		    System.out.println("unloadEventStart Time :" + unloadEventStart);
		    System.out.println("unloadEventEnd Time :" + unloadEventEnd);
		    System.out.println("domLoading Time :" + domLoading);
		    System.out.println("domInteractive Time :" + domInteractive);    		    
		    System.out.println("domContentLoadedEventStart Time :" +  domContentLoadedEventStart);
		    System.out.println("domContentLoadedEventEnd Time :" +  domContentLoadedEventEnd);
		    System.out.println("domComplete Time :" +domComplete);
		    System.out.println("loadEventStart Time :" +loadEventStart);
		    System.out.println("loadEventEnd Time :" +loadEventEnd);
		    
		    Log.info("Performance Metrics For-:"+driver.getTitle());
		    Log.info("navigationStart Time :" + navigationStart);
		    Log.info("redirectStart Time :" + redirectStart);
		    Log.info("redirectEnd Time :" + redirectEnd);
		    Log.info("fetchStart Time :" + fetchStart);
		    Log.info("domainLookupStart Time :" + domainLookupStart);
		    Log.info("domainLookupEnd Time :" + domainLookupEnd);
		    Log.info("connectStart Time :" + connectStart);
		    Log.info("secureConnectionStart Time :" + secureConnectionStart);
		    Log.info("connectEnd Time :" + connectEnd); 		  
		    Log.info("requestStart Time :" + requestStart);
		    Log.info("responseStart Time :" + responseStart);
		    Log.info("responseEnd Time :" + responseEnd);
		    Log.info("unloadEventStart Time :" + unloadEventStart);
		    Log.info("unloadEventEnd Time :" + unloadEventEnd);
		    Log.info("domLoading Time :" + domLoading);
		    Log.info("domInteractive Time :" + domInteractive);    		    
		    Log.info("domContentLoadedEventStart Time :" +  domContentLoadedEventStart);
		    Log.info("domContentLoadedEventEnd Time :" +  domContentLoadedEventEnd);
		    Log.info("domComplete Time :" +domComplete);
		    Log.info("loadEventStart Time :" +loadEventStart);
		    Log.info("loadEventEnd Time :" +loadEventEnd);
		    
		    System.out.println("--------------------------##-----------------------##-----------------------");
		    
		 
		    System.out.println("Total Redirect Time :" +(redirectEnd-redirectStart)+" millisec");
		    System.out.println("Total App Cache Time :" +(domainLookupStart-fetchStart)+" millisec");
		    System.out.println("Total First byte Time = "+(responseStart - navigationStart)+" millisec");
		    System.out.println("Total Network latency =" +(responseStart-fetchStart)+" millisec");
		    System.out.println("DNS/Domain Lookup Time =" +(domainLookupEnd - domainLookupStart)+" millisec");
		    System.out.println("Total TCP-SSL Time :" +(connectEnd-secureConnectionStart)+" millisec");
		    System.out.println("Server connect Time =" +(connectEnd - connectStart)+" millisec");
		    System.out.println("Server Response Time =" +(responseStart - requestStart)+" millisec");
		    System.out.println("Page Load time =" +(loadEventStart - navigationStart)+" millisec");
		    System.out.println("Transfer/Page Download Time /Page Response Time= "+(responseEnd - responseStart)+" millisec");
		    System.out.println("DOM Interactive Time =" +(domInteractive - navigationStart)+" millisec");
		    System.out.println("DOM Content Load Time =" +(domContentLoadedEventEnd - navigationStart)+" millisec");
		    System.out.println("DOM Processing to Interactive =" +(domInteractive - domLoading)+" millisec");
		    System.out.println("Dom Processing time :" +(domComplete - domLoading)+" millisec");
		    System.out.println("The time taken for page load once the page is received from the server:" +(loadEventEnd-responseEnd)+" millisec");   
		    System.out.println("(How long the browser spends loading the webpage until the user can starting interacting with it)Server Response Time =" +(responseStart - requestStart)+" millisec");
		    System.out.println("(How long it takes for the browser to load images/videos and execute any JavaScript code waiting for the domContentLoaded event)DOM Interactive to Complete =" +(domComplete - domInteractive)+" millisec");
		    System.out.println("(How long it takes the browser to execute Javascript code waiting for the window.load event)Onload =" +(loadEventEnd - loadEventStart)+" millisec");
		    System.out.println("Total Navaigation + Load Time :" +(loadEventEnd-navigationStart)+" millisec");
		   	
		    Log.info("Total Redirect Time :" +(redirectEnd-redirectStart)+" millisec");
		    Log.info("Total App Cache Time :" +(domainLookupStart-fetchStart)+" millisec");
		    Log.info("Total First byte Time = "+(responseStart - navigationStart)+" millisec");
		    Log.info("Total Network latency =" +(responseStart-fetchStart)+" millisec");
		    Log.info("DNS/Domain Lookup Time =" +(domainLookupEnd - domainLookupStart)+" millisec");
		    Log.info("Total TCP-SSL Time :" +(connectEnd-secureConnectionStart)+" millisec");
		    Log.info("Server connect Time =" +(connectEnd - connectStart)+" millisec");
		    Log.info("Server Response Time =" +(responseStart - requestStart)+" millisec");
		    Log.info("Page Load time =" +(loadEventStart - navigationStart)+" millisec");
		    Log.info("Transfer/Page Download Time /Page Response Time= "+(responseEnd - responseStart)+" millisec");
		    Log.info("DOM Interactive Time =" +(domInteractive - navigationStart)+" millisec");
		    Log.info("DOM Content Load Time =" +(domContentLoadedEventEnd - navigationStart)+" millisec");
		    Log.info("DOM Processing to Interactive =" +(domInteractive - domLoading)+" millisec");
		    Log.info("Dom Processing time :" +(domComplete - domLoading)+" millisec");
		    Log.info("The time taken for page load once the page is received from the server:" +(loadEventEnd-responseEnd)+" millisec");   
		    Log.info("(How long the browser spends loading the webpage until the user can starting interacting with it)Server Response Time =" +(responseStart - requestStart)+" millisec");
		    Log.info("(How long it takes for the browser to load images/videos and execute any JavaScript code waiting for the domContentLoaded event)DOM Interactive to Complete =" +(domComplete - domInteractive)+" millisec");
		    Log.info("(How long it takes the browser to execute Javascript code waiting for the window.load event)Onload =" +(loadEventEnd - loadEventStart)+" millisec");
		    Log.info("Total Navaigation + Load Time :" +(loadEventEnd-navigationStart)+" millisec");
		   	
	        int rowNumber1=Integer.parseInt(value);
		    ExcelUtils.setCellData(driver.getTitle(),rowNumber1, 1);
		    ExcelUtils.setCellData(String.valueOf(redirectEnd-redirectStart),rowNumber1, 2);
		    ExcelUtils.setCellData(String.valueOf(domainLookupStart-fetchStart),rowNumber1, 3);
		    ExcelUtils.setCellData(String.valueOf(responseStart - navigationStart),rowNumber1, 4);
		    ExcelUtils.setCellData(String.valueOf(responseStart-fetchStart),rowNumber1, 5);
		    ExcelUtils.setCellData(String.valueOf(domainLookupEnd - domainLookupStart),rowNumber1, 6);
		    ExcelUtils.setCellData(String.valueOf(connectEnd-secureConnectionStart),rowNumber1, 6);
		    ExcelUtils.setCellData(String.valueOf(connectEnd - connectStart),rowNumber1, 7);
		    ExcelUtils.setCellData(String.valueOf(responseStart - requestStart),rowNumber1, 8);
		    ExcelUtils.setCellData(String.valueOf(loadEventStart - navigationStart),rowNumber1, 9);
		    ExcelUtils.setCellData(String.valueOf(responseEnd - responseStart),rowNumber1, 10);
		    ExcelUtils.setCellData(String.valueOf(domInteractive - navigationStart),rowNumber1, 11);
		    ExcelUtils.setCellData(String.valueOf(domContentLoadedEventEnd - navigationStart),rowNumber1, 12);
		    ExcelUtils.setCellData(String.valueOf(domInteractive - domLoading),rowNumber1, 13);
		    ExcelUtils.setCellData(String.valueOf(domComplete - domLoading),rowNumber1, 14);
		    ExcelUtils.setCellData(String.valueOf(loadEventEnd-responseEnd),rowNumber1, 15);
		    ExcelUtils.setCellData(String.valueOf(responseStart - requestStart),rowNumber1, 16);
		    ExcelUtils.setCellData(String.valueOf(domComplete - domInteractive),rowNumber1, 17);
		    ExcelUtils.setCellData(String.valueOf(loadEventEnd - loadEventStart),rowNumber1, 18);
		    ExcelUtils.setCellData(String.valueOf(loadEventEnd-navigationStart),rowNumber1, 19);
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
}
