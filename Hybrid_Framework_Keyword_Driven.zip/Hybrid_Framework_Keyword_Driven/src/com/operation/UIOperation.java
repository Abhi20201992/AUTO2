package com.operation;

import static org.junit.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.CommonDriver.CommonDriverControls;
import com.EMailNotification.SendMailNotification;
import com.EMailNotification.SendMailNotificationWithAttachment;
import com.Implementation.CommonActionControls;
import com.Implementation.CommonAlertControls;
import com.Implementation.CommonBrowserControls;
import com.Implementation.CommonCheckboxControls;
import com.Implementation.CommonDropdownControls;
import com.Implementation.CommonIFrameControls;
import com.Implementation.CommonJavaScriptExecuter;
import com.Implementation.CommonMouseControls;
import com.Implementation.CommonSessionClean;
import com.Implementation.CommonTextboxControls;
import com.Implementation.CommonWebElementControls;
import com.Implementation.CommonWindowHandleControls;
import com.Implementation.CommonWindowSnapshotControls;
import com.PerformanceMetrics.MeasurementOfPerformanceOfPage;
import com.excelExportAndFileIO.Constant;

public class UIOperation {

	CommonDriverControls Obj = new CommonDriverControls();
	CommonActionControls Obj1 = new CommonActionControls();
	CommonAlertControls Obj2 = new CommonAlertControls();
	CommonBrowserControls Obj3 = new CommonBrowserControls();
	CommonCheckboxControls Obj4 = new CommonCheckboxControls();
	CommonDropdownControls Obj5 = new CommonDropdownControls();
	CommonIFrameControls Obj6 = new CommonIFrameControls();
	CommonJavaScriptExecuter Obj7 = new CommonJavaScriptExecuter();
	CommonMouseControls Obj8 = new CommonMouseControls();
	CommonTextboxControls Obj9 = new CommonTextboxControls();
	CommonWebElementControls Obj10 = new CommonWebElementControls();
	CommonWindowHandleControls Obj11 = new CommonWindowHandleControls();
	CommonWindowSnapshotControls Obj12 = new CommonWindowSnapshotControls();
	CommonSessionClean Obj13 = new CommonSessionClean();

	static String browserType = CommonBrowserControls.getBrowserType();

	@SuppressWarnings("static-access")
	public UIOperation(WebDriver driver) {
		driver = Obj.getdriver();
	}

	public String perform(Properties p, String operation, String objectName, String objectName1, String objectType,
			String objectType1, String value, String value1) throws Exception {

		System.out.println("");
		String sOperationAction = operation.trim();

		if (sOperationAction.isEmpty()) {

		}

		if (sOperationAction.equalsIgnoreCase("")) {

		}
		// ACTION-CONTROLS-METHODS------------------------------------------------------------------------
		if (sOperationAction.equalsIgnoreCase("Double_Click")) {

			Obj1.doubleClick(this.getObject(p, objectName, objectType));

		}

		if (sOperationAction.equalsIgnoreCase("Drag_And_Drop")) {

			Obj1.dragAndDrop(this.getObject(p, objectName, objectType), this.getObject(p, objectName1, objectType1));

		}

		if (sOperationAction.equalsIgnoreCase("Drag_And_DropBy")) {
			Obj1.dragAndDropBy((this.getObject(p, objectName, objectType)), Integer.parseInt(value),
					Integer.parseInt(value1));

		}

		if (sOperationAction.equalsIgnoreCase("Move_To_Element")) {
			Obj1.moveToElement(this.getObject(p, objectName, objectType));

		}

		if (sOperationAction.equalsIgnoreCase("Move_To_Element_And_Click")) {
			Obj1.moveToElementClick(this.getObject(p, objectName, objectType));

		}

		// ALERT-CONTROLS-METHODS------------------------------------------------------------------------

		if (sOperationAction.equalsIgnoreCase("Accept_Alert")) {
			Obj2.acceptAlert();

		}

		if (sOperationAction.equalsIgnoreCase("Get_Message_From_Alert")) {
			Obj2.getMessageFromAlert();

		}

		if (sOperationAction.equalsIgnoreCase("Reject_Alert")) {
			Obj2.rejectAlert();

		}

		if (sOperationAction.equalsIgnoreCase("Send_Message_Alert")) {
			Obj2.sendMessageAlert(value);

		}

		if (sOperationAction.equalsIgnoreCase("Wait_For_Alert")) {
			Obj2.waitForAlert();

		}

		// Browser-Controls-METHODS------------------------------------------------------------------------
		if (sOperationAction.equalsIgnoreCase("Delete_All_Cookies")) {
			Obj3.deleteAllCookies();
			Thread.sleep(1000);

		}

		if (sOperationAction.equalsIgnoreCase("Open_Browser")) {
			Obj3.openBrowser(value);

		}

		if (sOperationAction.equalsIgnoreCase("Close_Browser")) {
			Obj3.closeBrowser();

		}

		if (sOperationAction.equalsIgnoreCase("LAUNCHURL")) {
			Obj3.getUrl(value);

		}

		if (sOperationAction.equalsIgnoreCase("MAXIMIZE_WINDOW")) {
			Obj3.maximizeWindow();
			Thread.sleep(1000);

		}

		if (sOperationAction.equalsIgnoreCase("AUTHENTICATION")) {
			Obj3.Authentication(browserType);

			Thread.sleep(1000);

		}

		if (sOperationAction.equalsIgnoreCase("Implicit_Wait")) {
			Obj3.ImplicitWait(Integer.parseInt(value));
			Thread.sleep(1000);

		}

		if (sOperationAction.equalsIgnoreCase("Navigate_Refresh")) {
			Obj3.navigateRefresh();
			Thread.sleep(1000);

		}

		// WebElement-CommonCheckbox-Controls------------------------------------------------------------------------
		if (sOperationAction.equalsIgnoreCase("Change_CheckBox_Status")) {
			return (Obj4.changeCheckBoxStatus(this.getObject(p, objectName, objectType), Boolean.valueOf(value)));
		}

		// WebElement-
		// Dropdown-Controls-Methods-----------------------------------------------------------------------
		if (sOperationAction.equalsIgnoreCase("SELECTVIATEXT")) {
			return (Obj5.selectViaVisibleText(this.getObject(p, objectName, objectType), value));
		}
		if (sOperationAction.equalsIgnoreCase("SELECTVIAVALUE")) {
			return (Obj5.selectViaValue(this.getObject(p, objectName, objectType), value));
		}
		if (sOperationAction.equalsIgnoreCase("SELECTVIAINDEX")) {
			return (Obj5.selectViaIndex(this.getObject(p, objectName, objectType), Integer.parseInt(value)));
		}

		if (sOperationAction.equalsIgnoreCase("GET_FIRST_SELECTED_OPTION")) {
			return ((Obj5.getFirstSelectedOption(this.getObject(p, objectName, objectType))).toString());
		}
		// Common-IFrame-Controls----------------------------------------------------------------------------------------

		if (sOperationAction.equalsIgnoreCase("SWITCH_TO_DEFAULT_CONTENT")) {
			return (Obj6.switchToDefaultContent());
		}

		if (sOperationAction.equalsIgnoreCase("SWITCH_TO_IFRAME_BY_ID")) {
			return (Obj6.switchToIframeByID(value));
		}

		if (sOperationAction.equalsIgnoreCase("SWITCH_TO_IFRAME_BY_INDEX")) {
			return (Obj6.switchToIframeByIndex(Integer.parseInt(value)));
		}

		if (sOperationAction.equalsIgnoreCase("SWITCH_TO_IFRAME_BY_NAME")) {
			return (Obj6.switchToIframeByName(value));
		}

		if (sOperationAction.equalsIgnoreCase("SWITCH_TO_IFRAME_BY_WEBELEMENT")) {
			return (Obj6.switchToIframeByWebElement(this.getObject(p, objectName, objectType)));
		}

		if (sOperationAction.equalsIgnoreCase("SWITCH_TO_PARENT_IFRAME")) {
			return (Obj6.switchToParentIframe());
		}

		// WebElement-CommonTextbox-Controls------------------------------------------------------------------------
		if (sOperationAction.equalsIgnoreCase("EnterText")) {
			return (Obj9.setText(this.getObject(p, objectName, objectType), value));
		}

		if (sOperationAction.equalsIgnoreCase("ClearText")) {
			Obj9.clearText(this.getObject(p, objectName, objectType));
			Thread.sleep(1000);
		}

		// WebElement-Controls-Methods------------------------------------------------------------------------
		if (sOperationAction.equalsIgnoreCase("click")) {
			return (Obj10.click(this.getObject(p, objectName, objectType)));
		}

		// Window-Snapshot-Controls-Methods------------------------------------------------------------------------
		if (sOperationAction.equalsIgnoreCase("Take_SnapShot")) {
			return (Obj12.takeSnapShot(value));
		}

		if (sOperationAction.equalsIgnoreCase("SITEUSERAUTHENTICATION")) {
			try {
				Runtime.getRuntime().exec(Constant.SiteUserAuth);
				Thread.sleep(3000);
				return "SiteUser Authenticaton is Done";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}

		}

		// Window-Handle-Controls------------------------------------------------------------------------
		if (sOperationAction.equalsIgnoreCase("GET_LIST_OF_WINDOWHANDLES")) {
			Obj11.getListOfWindowHandles();
			Thread.sleep(2000);

		}

		if (sOperationAction.equalsIgnoreCase("SWITCH_TO_SECOND_WINDOW")) {
			return (Obj11.switchToSecondWindow());

		}

		if (sOperationAction.equalsIgnoreCase("SWITCH_TO_FIRST_WINDOW")) {
			return (Obj11.switchToFirstWindow());

		}

		if (sOperationAction.equalsIgnoreCase("GET_WINDOW_HANDLES")) {
			Obj11.getWindowHandles();
			Thread.sleep(2000);

		}

		if (sOperationAction.equalsIgnoreCase("GET_WINDOW_HANDLE")) {
			return (Obj11.getWindowHandle());

		}

		if (sOperationAction.equalsIgnoreCase("Close_Extra_Window_And_Switch_FirstTab")) {
			return (Obj11.CloseExtraWindowAndSwitchFirstTab());

		}

		if (sOperationAction.equalsIgnoreCase("CLOSEWINDOW")) {
			return (Obj3.closeBrowser());

		}

		// Explicit-Sleep-Methods-----------------------------------------------------------------------

		if (sOperationAction.equalsIgnoreCase("Sleep5")) {
			Thread.sleep(5000);
			return "Sleep performed for 5 sec";
		}

		if (sOperationAction.equalsIgnoreCase("Sleep10")) {
			Thread.sleep(10000);
			return "Sleep performed for 10 sec";
		}

		if (sOperationAction.equalsIgnoreCase("Sleep")) {
			Thread.sleep(Integer.parseInt(value));
		}

		if (sOperationAction.equalsIgnoreCase("ASSERT_TRUE_IS_ELEMENT_VISIBLE")) {
			try {
				assertTrue(Obj10.isElementVisible(this.getObject(p, objectName, objectType)), "Element is not Visible");
				return "assertion is performed";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}
		}

		if (sOperationAction.equalsIgnoreCase("ASSERT_FALSE_IS_ELEMENT_VISIBLE")) {
			try {
				assertFalse(Obj10.isElementVisible(this.getObject(p, objectName, objectType)), "Element is Visible");
				return "assertion is performed";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}
		}

		if (sOperationAction.equalsIgnoreCase("ASSERT_TRUE_IS_ELEMENT_SELECTED")) {
			try {
				assertTrue(Obj10.isElementSelected(this.getObject(p, objectName, objectType)),
						"Element is not selected");
				return "assertion is performed";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}
		}

		if (sOperationAction.equalsIgnoreCase("ASSERT_TRUE_IS_ELEMENT_SELECTED")) {
			try {
				assertTrue(Obj10.isElementSelected(this.getObject(p, objectName, objectType)),
						"Element is not selected");
				return "assertion is performed";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}
		}

		if (sOperationAction.equalsIgnoreCase("ASSERT_FALSE_IS_ELEMENT_SELECTED")) {
			try {
				assertFalse(Obj10.isElementSelected(this.getObject(p, objectName, objectType)), "Element is selected");
				return "assertion is performed";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}
		}

		if (sOperationAction.equalsIgnoreCase("ASSERT_TRUE_IS_ELEMENT_CHECKED")) {
			try {
				assertTrue(Obj10.isElementSelected(this.getObject(p, objectName, objectType)));
				return "assertion is performed";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}
		}

		if (sOperationAction.equalsIgnoreCase("ASSERT_FALSE_IS_ELEMENT_CHECKED")) {
			try {
				assertFalse(Obj10.isElementSelected(this.getObject(p, objectName, objectType)));
				return "assertion is performed";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}
		}

		if (sOperationAction.equalsIgnoreCase("ASSERT_TRUE_IS_ELEMENT_DETECTED")) {
			try {
				assertTrue(Obj10.isElementDetected(this.getObject(p, objectName, objectType)));
				return "assertion is performed";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}

		}

		if (sOperationAction.equalsIgnoreCase("ASSERT_FALSE_IS_ELEMENT_DETECTED")) {
			try {
				assertFalse(Obj10.isElementDetected(this.getObject(p, objectName, objectType)));
				return "assertion is performed";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}

		}

		if (sOperationAction.equalsIgnoreCase("ASSERT_IS_PAGE_TITLE_AS_EXPECTED")) {
			try {
				assertEquals(value, Obj3.getTitle());
				return "assertion is performed";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}

		}

		if (sOperationAction.equalsIgnoreCase("ASSERT_IS_TEXT_ENTERED_AS_EXPCTED")) {
			try {
				assertEquals(Obj3.getAttribute(this.getObject(p, objectName, objectType), value), value);
				return "assertion is performed";
			} catch (Exception e) {
				e.printStackTrace();
				return ExceptionUtils.getStackTrace(e);
			}
		}

		if (sOperationAction.equalsIgnoreCase("FIND_PERF_METRICS")) {

			try {
				MeasurementOfPerformanceOfPage.measurePerformanceOfPageinMillisec(value);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		if (sOperationAction.equalsIgnoreCase("SEND_MAIL_NOTIFICATION")) {

			try {
				SendMailNotification.mailSend(value);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		if (sOperationAction.equalsIgnoreCase("SEND_MAIL_NOTIFICATION_WITH_SNAPSHOT")) {

			try {
				Obj12.takeSnapShot(value);
				SendMailNotificationWithAttachment.mailToSendWithAttachment(value1, Obj12.getSnapShot());
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		if (sOperationAction.equalsIgnoreCase("START_A_CLEAN_SESSION")) {

			try {
				Obj13.start_a_Clean_Session();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		return "Some Error Occured in perform method of UIOperation Class";

	}

	private By getObject(Properties p, String objectName, String objectType) throws Exception {

		if (objectType.equalsIgnoreCase("XPATH")) {
			try {
				return By.xpath(p.getProperty(objectName));
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		else if (objectType.equalsIgnoreCase("ID")) {

			try {
				return By.id(p.getProperty(objectName));
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		else if (objectType.equalsIgnoreCase("CLASSNAME")) {

			try {
				return By.className(p.getProperty(objectName));
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		else if (objectType.equalsIgnoreCase("NAME")) {

			try {
				return By.name(p.getProperty(objectName));
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		else if (objectType.equalsIgnoreCase("CSS")) {

			try {
				return By.cssSelector(p.getProperty(objectName));
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		else if (objectType.equalsIgnoreCase("LINK")) {

			try {
				return By.linkText(p.getProperty(objectName));
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}

		else if (objectType.equalsIgnoreCase("PARTIALLINK")) {

			try {
				return By.partialLinkText(p.getProperty(objectName));
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}

		} else {
			throw new Exception("error object type");
		}

	}
}
