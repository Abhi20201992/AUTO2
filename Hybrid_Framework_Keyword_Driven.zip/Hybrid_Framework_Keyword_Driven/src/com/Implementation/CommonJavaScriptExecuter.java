package com.Implementation;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.CommonDriver.CommonDriverControls;
import com.Contracts.IJavaScriptExecuter;

import log4j.Log;

public class CommonJavaScriptExecuter implements IJavaScriptExecuter {
	WebDriver driver = CommonDriverControls.getdriver();
	JavascriptExecutor js = (JavascriptExecutor) driver;

	public String executeJavaScript(String scriptToExecute) throws Exception {
		try {
			js.executeScript(scriptToExecute);
			Log.info("Successfully Script using JavaScript Executed is:" + scriptToExecute);
			System.out.println("Successfully Script using JavaScript Executed is:" + scriptToExecute);
			return "Successfully Script using JavaScript Executed is:" + scriptToExecute;

		} catch (Exception e) {
			Log.error("Failed-Script using JavaScript is not Executed" + "due to" + e);
			System.out.println("Failed-Script using JavaScript is not Executed");
			e.printStackTrace();
			return ExceptionUtils.getStackTrace(e);
		}
	}

	public String scrollDown(int x, int y) throws Exception {
		try {
			js.executeScript("window.scrollBy(x,y)");
			return "Successfully scrolling down is done";
		} catch (Exception e) {
			return ExceptionUtils.getStackTrace(e);
		}

	}

	public void executeJavaScriptWithReturnValue(String scriptToExecute) throws Exception {
		
	}

	public void executeAsyncJavaScript(String scriptToExecute, Object[] args) throws Exception {
		
		// Call executeAsyncScript() method to wait for 5 seconds
		//js.executeAsyncScript("window.setTimeout(arguments[arguments.length - 1], 5000);");

	}

	@Override
	public void scrollUp(int x, int y) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
