package com.Implementation;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class CommonSessionClean {

	static String browserType = CommonBrowserControls.getBrowserType();

	public void start_a_Clean_Session() {
		if (browserType.contains("Chrome") || browserType.contains("chrome") || browserType.contains("CM")) {
			try {
				DesiredCapabilities capabilities = DesiredCapabilities.chrome();
				capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (browserType.contains("FireFox") || browserType.contains("firefox") || browserType.contains("ff")) {
			try {
				DesiredCapabilities capabilities = DesiredCapabilities.firefox();
				capabilities.setCapability("marionette", true);
				capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);

			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (browserType.contains("InternetExplore") || browserType.contains("InternetExplore")|| browserType.contains("IE")) {
			try {
				DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
				capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
}
