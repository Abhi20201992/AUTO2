package com.Implementation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.CommonDriver.CommonDriverControls;
import com.Contracts.IMouseControls;

public class CommonMouseControls implements IMouseControls {
	WebDriver driver = CommonDriverControls.getdriver();
	WebDriverWait wait = new WebDriverWait(driver, 40);

	public void clickAndHold() throws Exception {

	}

	public void contextClick(By oBy) throws Exception {
	}

	public void keyDown(String modifier_Downkey) {

	}

	public void keyUp(String modifier_Upkey) {

	}

	public void release() {

	}

}
