package com.EMailNotification;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.excelExportAndFileIO.Constant;

import log4j.Log;

public class SendMailNotification {

	public static void mailSend(String messageTosend) {

		String to = Constant.MailTo;
		String from = Constant.MailFrom;
		String host = Constant.smtpHost;// or IP address
		String subject = Constant.subject;

		// Get the session object
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		Session session = Session.getDefaultInstance(properties);

		// Compose the message
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setSubject(subject);
			message.setText(messageTosend);
	
		 // Send message
			Transport.send(message);
			Log.info("Message body in mail is sent as " + message);
			System.out.println("Message body in mail is sent as " + message);

		} catch (MessagingException mex) {
			
			Log.error("Mail sending is Failed " + "due to" + mex);
			System.out.println("Mail sending is Failed");
			mex.printStackTrace();
			
		}
	}

}
