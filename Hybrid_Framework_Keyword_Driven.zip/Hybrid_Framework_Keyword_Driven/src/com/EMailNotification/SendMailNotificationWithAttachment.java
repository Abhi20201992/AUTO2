package com.EMailNotification;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.excelExportAndFileIO.Constant;

import log4j.Log;

public class SendMailNotificationWithAttachment {

	public static void mailToSendWithAttachment(String messageTosend, String snapShotFile) {

		String to = Constant.MailTo;
		String from = Constant.MailFrom;
		String host = Constant.smtpHost;// or IP address
		String subject = Constant.subject;

		// Get the session object
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		Session session = Session.getDefaultInstance(properties);

		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setSubject(subject);

			// message.setText(messageTosend);
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setText(messageTosend);
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);

			messageBodyPart = new MimeBodyPart();

			String filepath = snapShotFile;
			
			DataSource source = new FileDataSource(filepath);
			messageBodyPart.setDataHandler(new DataHandler(source));
					
	        Path p = Paths.get(filepath);
	        String NameOffile = p.getFileName().toString();
	        
			messageBodyPart.setFileName(NameOffile);
			multipart.addBodyPart(messageBodyPart);

			// Send the complete message parts
			message.setContent(multipart);

			// Send message
			Transport.send(message);

			Log.info("Message is sent Successfully");
			System.out.println("Message is sent Successfully");

		} catch (MessagingException e) {
			Log.error("Mail sending is Failed " + "due to" + e);
			System.out.println("Mail sending is Failed");
			throw new RuntimeException(e);
		}
	}
}
