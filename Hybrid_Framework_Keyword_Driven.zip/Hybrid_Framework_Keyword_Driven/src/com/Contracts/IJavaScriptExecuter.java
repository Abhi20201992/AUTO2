package com.Contracts;

public interface IJavaScriptExecuter {

	public String executeJavaScript(String scriptToExecute) throws Exception;

	public String scrollDown(int x, int y) throws Exception;

	public void executeJavaScriptWithReturnValue(String scriptToExecute) throws Exception;

	public void executeAsyncJavaScript(String scriptToExecute, Object[] args) throws Exception;

	public void scrollUp(int x, int y) throws Exception;

}
