package com.Contracts;

import org.openqa.selenium.WebDriver;

public interface IWindowSnapshot {
	public static void takeSnapShot(WebDriver webdriver, String fileWithPath) throws Exception {

	}

}
