package com.CommonDriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.Implementation.CommonBrowserControls;
import com.excelExportAndFileIO.Constant;

import log4j.Log;

public class CommonDriverControls {

	private static WebDriver driver;
	static String browserType = CommonBrowserControls.getBrowserType();

	public static WebDriver getdriver() {
		if (driver == null) {
			if (browserType.contains("Chrome") || browserType.contains("chrome") || browserType.contains("CM")) {
				try {
					DesiredCapabilities capabilities = DesiredCapabilities.chrome();
					capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
					System.setProperty("webdriver.chrome.driver", Constant.ChromeDriverPath);
					driver = new ChromeDriver();
					Log.info("Chrome is Opened");
					System.out.println("Chrome is Opened");
					return driver;
				} catch (Exception e) {
					e.printStackTrace();
					Log.info("Chrome is not Opened" + "due to\n" + e);
					System.out.println("Chrome is not Opened" + "due to\n" + e);
					return null;
				}
			} else if (browserType.contains("FireFox") || browserType.contains("firefox")
					|| browserType.contains("ff")) {
				try {
					DesiredCapabilities capabilities=DesiredCapabilities.firefox();
					capabilities.setCapability("marionette", true);
					capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
					
					System.setProperty("webdriver.gecko.driver", Constant.FireFoxDriverPath);
					driver = new FirefoxDriver();
					Log.info("FireFox is Opened");
					System.out.println("FireFox is Opened");
					return driver;
				} catch (Exception e) {
					Log.info("Firefox is not Opened" + "due to" + e);
					System.out.println("Firefox is not Opened" + "due to" + e);
					e.printStackTrace();
					return null;
				}
			} else if (browserType.contains("InternetExplore") || browserType.contains("InternetExplore")
					|| browserType.contains("IE")) {
				try {
					DesiredCapabilities capabilities = new DesiredCapabilities();
					capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
					capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
					
					System.setProperty("webdriver.ie.driver", Constant.IEDriverPath);
					driver = new InternetExplorerDriver();
					Log.info("IE is Opened");
					System.out.println("IE is Opened");
					return driver;
				} catch (Exception e) {
					Log.info("IE is not Opened" + "due to\n" + e);
					System.out.println("IE is not Opened" + "due to\n" + e);
					e.printStackTrace();
					return null;
				}
			}
		} else {
			return driver;
		}
		return driver;
	}

	public static void setDriver(WebDriver driver) throws Exception {
		CommonDriverControls.driver = driver;
	}

}