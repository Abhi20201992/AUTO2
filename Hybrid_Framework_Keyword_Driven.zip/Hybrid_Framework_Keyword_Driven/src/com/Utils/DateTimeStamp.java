package com.Utils;

import java.util.Date;

public class DateTimeStamp {

	public static String getDateTimeStamp() {

		Date oDate;
		String[] sDatePart;
		String sDateStamp;

		oDate = new Date();
		System.out.println(oDate.toString());
		// Mon Sep 07 17:28:42 IST 2015
		sDatePart = oDate.toString().split(" ");
		sDateStamp = sDatePart[5] + "_" + sDatePart[1] + "_" + sDatePart[2] + "_" + sDatePart[3];
		sDateStamp = sDateStamp.replace(":", "_");
		System.out.println(sDateStamp);
		// 2016_Jan_31_10_47_48
		return sDateStamp;
	}

	

}
