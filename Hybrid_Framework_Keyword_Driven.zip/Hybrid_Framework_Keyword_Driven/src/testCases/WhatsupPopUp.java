package testCases;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.CommonDriver.CommonDriverControls;

import log4j.Log;

public class WhatsupPopUp {
	
	WebDriver driver = CommonDriverControls.getdriver();
	
	@BeforeMethod
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		//ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Dashboard.xlsx"), "Dashboard");
	}

	@AfterTest
	public void afterTest() throws InterruptedException {
		Thread.sleep(1000);
	}

	@Test(description = "Goto Whatsup Iframe")
	public void whatsupPopUp_TC01() throws Exception {

		try {
			
			Thread.sleep(1500);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			WebElement el1 = wait          
					.until(ExpectedConditions.presenceOfElementLocated(By.id("ctl00_m_g_e8e6e5b9_f91b_4286_9438_afe832ba38c2_ctl00_InvDashboardScheme_iWhatsapp")));
			el1.click();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("\n WhatsupFrame is Clicked");
			System.out.println("\n WhatsupFrame is Clicked");
			//ExcelUtils.setCellData("Passed", Constant.TestCaseColumn1, Constant.Result);
			//System.out.println(el1.isEnabled());
			//assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("\n WhatsupFrame is not Clicked" + "\n" + e);
			System.out.println("\n WhatsupFrame  is not Clicked");
			//ExcelUtils.setCellData("Failed", Constant.TestCaseColumn1, Constant.Result);
			//TakeScreenShot.takeScreenShot(driver, Constant.DashboardFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Close is Clicked")
	public void whatsupPopUp_TC02() throws Exception {

		try {
			Thread.sleep(1500);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id=\"dvWhatsappmsg\"]/div[3]/div[1]/span")));
			el1.click();
			
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			
			Log.info("\n Close is Clicked");
			System.out.println("\nClose is Clicked");
			//ExcelUtils.setCellData("Passed", Constant.TestCaseColumn2, Constant.Result);
			
			
			
			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				driver.switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			
			//System.out.println(el1.isEnabled());
			//assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("\n Close is not Clicked" + "\n" + e);
			System.out.println("\n Close  is not Clicked");
			//ExcelUtils.setCellData("Failed",Constant.TestCaseColumn2, Constant.Result);
			//TakeScreenShot.takeScreenShot(driver, Constant.DashboardFailedSnapShot);
			e.printStackTrace();
		}
	}



	

}
