package testCases;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.EMailNotification.SendMailNotificationWithAttachment;
import com.Implementation.CommonWindowSnapshotControls;
import UIAutomationInTest.UITest;

public class eOTM_Registration_NonLogged {
	UITest oUITest = new UITest();

	@BeforeMethod
	public void init() {
		DOMConfigurator.configure("log4j.xml");
	}

	@AfterMethod
	public void tearDown(ITestResult result) throws Exception {
		if (ITestResult.FAILURE == result.getStatus()) {

			CommonWindowSnapshotControls Obj12 = new CommonWindowSnapshotControls();
			Obj12.takeSnapShot("LoginInitiateFailed");
			SendMailNotificationWithAttachment.mailToSendWithAttachment(
					"Hi, \n Automation Scripts of UAT Testing getting error at Page 'EOTM Non Logged'. \n \n Please collect attached Snapshot of Failure ",
					Obj12.getSnapShot());
		}

		// close application
		// CommonDriverControls.getdriver().quit();
	}

	@Parameters({ "browsertype" })
	@Test
	public void testNonLoginEOTMNBSuccess(String browsertype) throws Exception {
		oUITest.uiTestOperationBrowser(browsertype, "eOTMRegistration", "EOTM_NonLogged.xlsx", "EOTM_NonLogged", 14, 67,
				"EOTM_NonLogged_NB_Success");

	}

	@Parameters({ "browsertype" })
	@Test
	public void testNonLoginEOTMNBFailure(String browsertype) throws Exception {
		oUITest.uiTestOperationBrowser(browsertype, "eOTMRegistration", "EOTM_NonLogged.xlsx", "EOTM_NonLogged", 67, 121,
				"EOTM_NonLogged_NB_Failure");

	}

	@Parameters({ "browsertype" })
	@Test
	public void testNonLoginEOTMNBReject(String browsertype) throws Exception {
		oUITest.uiTestOperationBrowser(browsertype, "eOTMRegistration", "EOTM_NonLogged.xlsx", "EOTM_NonLogged", 122, 176,
				"EOTM_NonLogged_NB_Reject");

	}

	@Parameters({ "browsertype" })
	@Test
	public void testNonLoginEOTMAadhaarSuccess(String browsertype) throws Exception {
		oUITest.uiTestOperationBrowser(browsertype, "eOTMRegistration", "EOTM_NonLogged.xlsx", "EOTM_NonLogged", 177, 232,
				"EOTM_NonLogged_Aadhaar_Success");

	}

	@Parameters({ "browsertype" })
	@Test
	public void testNonLoginEOTMAadhaarFailure(String browsertype) throws Exception {
		oUITest.uiTestOperationBrowser(browsertype, "eOTMRegistration", "EOTM_NonLogged.xlsx", "EOTM_NonLogged", 233, 288,
				"EOTM_NonLogged_Aadhaar_Failure");

	}

	@Parameters({ "browsertype" })
	@Test
	public void testNonLoginEOTMAadhaarReject(String browsertype) throws Exception {
		oUITest.uiTestOperationBrowser(browsertype, "eOTMRegistration", "EOTM_NonLogged.xlsx", "EOTM_NonLogged", 289, 343,
				"EOTM_NonLogged_Aadhaar_Reject");

	}

}