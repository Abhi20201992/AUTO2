package testCases;

import java.util.Properties;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.CommonDriver.CommonDriverControls;
import com.EMailNotification.SendMailNotificationWithAttachment;
import com.Implementation.CommonBrowserControls;
import com.Implementation.CommonWindowSnapshotControls;
import com.excelExportAndFileIO.Constant;
import com.excelExportAndFileIO.ExcelDriver;
import com.excelExportAndFileIO.ExportToExcel;
import com.operation.ReadObject;
import com.operation.UIOperation;

public class TestingTuto {

	String sActionKeyword;
	String sObjectLocator;
	String sObjectType;
	String sArgumentValue;
	String sRunStatus;
	String sComment;
	String sReturnValue;
	String sCurrentTestCaseStatus;
	String sTestCaseSheetName;
	String TestCaseWorkBook;
	String sRunFlag;
	int iRow, iRowCount;
	ExcelDriver oExcelDriver = new ExcelDriver();
	
	@BeforeMethod
	public void init() {
		DOMConfigurator.configure("log4j.xml");

	}

	@AfterMethod
	public void tearDown(ITestResult result) throws Exception {
		if (ITestResult.FAILURE == result.getStatus()) {

			CommonWindowSnapshotControls Obj12 = new CommonWindowSnapshotControls();
			Obj12.takeSnapShot("LoginInitiateFailed");
			SendMailNotificationWithAttachment.mailToSendWithAttachment(
					"Hi, \n Automation Scripts of UAT Testing getting error at Page 'Tutorials Point Page'. \n \n Please collect attached Snapshot of Failure ",
					Obj12.getSnapShot());
		}

		// close application
		// CommonDriverControls.getdriver().quit();
	}

	@Parameters({ "browsertype" })
	@Test
	public void testNonLoginInitiate(String browsertype) throws Exception {
		DOMConfigurator.configure("log4j.xml");
		CommonBrowserControls.setBrowserType(browsertype);
		WebDriver driver = CommonDriverControls.getdriver();
		CommonWindowSnapshotControls Obj12 = new CommonWindowSnapshotControls();
		
		ReadObject object = new ReadObject();
		Properties allObjects = object.getObjectRepository("Testing");
		UIOperation operation = new UIOperation(driver);

		TestCaseWorkBook = Constant.TestCasesInputFolder + "\\Testing.xlsx";
		oExcelDriver.openExcelWorkbook(TestCaseWorkBook);
		oExcelDriver.setExcelSheet("Testing");
		iRowCount = oExcelDriver.getRowCountoFSheet("Testing");

		for (int iRow = 14; iRow < iRowCount; iRow++) {

			// sTestCaseSheetName =
			// oExcelDriver.getCellData(oExcelDriver.getExcelSheet(),iRow, 9);
			sRunFlag = oExcelDriver.getCellData(oExcelDriver.getExcelSheet(), iRow, 16);
			sRunFlag = sRunFlag.toLowerCase().trim();
			// sTestCaseSheetName = sTestCaseSheetName.trim();
			// sCurrentTestCaseStatus = "Pass";

			if (sRunFlag.equalsIgnoreCase("yes")) {
				try {
					sActionKeyword = oExcelDriver
							.getCellData(oExcelDriver.getExcelSheet(), iRow, Constant.ActionKeywordColumn).trim();
					sObjectLocator = oExcelDriver
							.getCellData(oExcelDriver.getExcelSheet(), iRow, Constant.ObjectLocatorColumn).trim();
					sObjectType = oExcelDriver
							.getCellData(oExcelDriver.getExcelSheet(), iRow, Constant.ObjectTypeColumn).trim();
					sArgumentValue = oExcelDriver
							.getCellData(oExcelDriver.getExcelSheet(), iRow, Constant.ArgumentValueColumn).trim();
					System.out.println(
							sActionKeyword + "----" + sObjectLocator + "----" + sObjectType + "----" + sArgumentValue);

					if (oExcelDriver.getCellData(oExcelDriver.getExcelSheet(), iRow, 9).length() == 0) {
						sReturnValue=operation.perform(allObjects, sActionKeyword, sObjectLocator, null, sObjectType,null, sArgumentValue, null);

						
						if (sReturnValue.contains("Exception")||sReturnValue.contains("exception")) {
							
							oExcelDriver.setCellData(oExcelDriver.getExcelSheet(), iRow, 19, "Failed");
							oExcelDriver.setCellData(oExcelDriver.getExcelSheet(), iRow, 22, sReturnValue);
							Obj12.takeSnapShot("NonLoginInitiateFailed");
							SendMailNotificationWithAttachment.mailToSendWithAttachment(
									"Hi, \n Automation Scripts of UAT Testing getting error at Page 'Login'. \n \n Please collect attached Snapshot of Failure because of \n\n"+sReturnValue,
									Obj12.getSnapShot());
							
						} else {
							oExcelDriver.setCellData(oExcelDriver.getExcelSheet(), iRow, 19, "Passed");
						}
						
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
			}

		}
		
		ExportToExcel.exportToExcel("Testing_Tuto");

	}

}
