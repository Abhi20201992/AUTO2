package testCases;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.EMailNotification.SendMailNotificationWithAttachment;
import com.Implementation.CommonWindowSnapshotControls;
import UIAutomationInTest.UITest;

public class LoginABCMF {

	UITest oUITest = new UITest();

	@BeforeMethod
	public void init() {
		DOMConfigurator.configure("log4j.xml");

	}

	@AfterMethod
	public void tearDown(ITestResult result) throws Exception {
		if (ITestResult.FAILURE == result.getStatus()) {

			CommonWindowSnapshotControls Obj12 = new CommonWindowSnapshotControls();
			Obj12.takeSnapShot("LoginInitiateFailed");
			SendMailNotificationWithAttachment.mailToSendWithAttachment(
					"Hi, \n Automation Scripts of UAT Testing getting error at Page 'Login'. \n \n Please collect attached Snapshot of Failure ",
					Obj12.getSnapShot());
		}

		// close application
		// CommonDriverControls.getdriver().quit();
	}

	@Parameters({ "browsertype" })
	@Test
	public void testLoginInitiate(String browsertype) throws Exception {
		oUITest.uiTestOperationBrowser(browsertype, "LoginABCMF", "Login.xlsx", "Login", 14, 37, "LoginABCMF");
	}
}