package testCases;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.EMailNotification.SendMailNotificationWithAttachment;
import com.Implementation.CommonWindowSnapshotControls;
import UIAutomationInTest.UITest;

public class eOTM_Registration_Logged {
	UITest oUITest = new UITest();

	@BeforeMethod
	public void init() {
		DOMConfigurator.configure("log4j.xml");
	}

	@AfterMethod
	public void tearDown(ITestResult result) throws Exception {
		if (ITestResult.FAILURE == result.getStatus()) {

			CommonWindowSnapshotControls Obj12 = new CommonWindowSnapshotControls();
			Obj12.takeSnapShot("LoginInitiateFailed");
			SendMailNotificationWithAttachment.mailToSendWithAttachment(
					"Hi, \n Automation Scripts of UAT Testing getting error at Page 'EOTM Logged'. \n \n Please collect attached Snapshot of Failure ",
					Obj12.getSnapShot());
		}

		// close application
		// CommonDriverControls.getdriver().quit();
	}

	@Test(priority=1)
	public void testNonLoginEOTMNBSuccess() throws Exception {
		oUITest.uiTestOperationNoBrowser("eOTMRegistration", "EOTM_Logged.xlsx", "EOTM_Logged", 14, 47,
				"EOTM_Logged_NB_Success");

	}

	@Test(priority=2)
	public void testNonLoginEOTMNBFailure() throws Exception {
		oUITest.uiTestOperationNoBrowser("eOTMRegistration", "EOTM_Logged.xlsx", "EOTM_Logged", 47, 75,
				"EOTM_Logged_NB_Failure");

	}

	@Test(priority=3)
	public void testNonLoginEOTMNBReject() throws Exception {
		oUITest.uiTestOperationNoBrowser("eOTMRegistration", "EOTM_Logged.xlsx", "EOTM_Logged", 75, 103,
				"EOTM_Logged_NB_Reject");

	}

	@Test(priority=4)
	public void testNonLoginEOTMAadhaarSuccess() throws Exception {
		oUITest.uiTestOperationNoBrowser("eOTMRegistration", "EOTM_Logged.xlsx", "EOTM_Logged",103, 132,
				"EOTM_Logged_Aadhaar_Success");

	}

	@Test(priority=5)
	public void testNonLoginEOTMAadhaarFailure() throws Exception {
		oUITest.uiTestOperationNoBrowser("eOTMRegistration", "EOTM_Logged.xlsx", "EOTM_Logged", 132 ,161,
				"EOTM_Logged_Aadhaar_Failure");

	}

	@Test(priority=6)
	public void testNonLoginEOTMAadhaarReject() throws Exception {
		oUITest.uiTestOperationNoBrowser("eOTMRegistration", "EOTM_Logged.xlsx", "EOTM_Logged", 161, 190,
				"EOTM_Logged_Aadhaar_Reject");

	}

}