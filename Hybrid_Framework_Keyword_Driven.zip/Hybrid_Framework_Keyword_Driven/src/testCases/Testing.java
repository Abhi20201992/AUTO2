package testCases;

import java.util.Properties;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import com.CommonDriver.CommonDriverControls;
import com.EMailNotification.SendMailNotificationWithAttachment;
import com.Implementation.CommonBrowserControls;
import com.Implementation.CommonWindowSnapshotControls;
import com.excelExportAndFileIO.Constant;
import com.excelExportAndFileIO.ExcelDriver;
import com.excelExportAndFileIO.ExportToExcel;
import com.operation.ReadObject;
import com.operation.UIOperation;

public class Testing {
	static String sActionKeyword;
	static String sObjectLocator;
	static String sObjectType;
	static String sArgumentValue;
	String sRunStatus;
	String sComment;
	static String sReturnValue;
	String sCurrentTestCaseStatus;
	String sTestCaseSheetName;
	static String TestCaseWorkBook;
	static String sRunFlag;
	int iRow;
	static int iRowCount;
	static ExcelDriver oExcelDriver = new ExcelDriver();

	public static void main(String args[]) throws Exception {

		DOMConfigurator.configure("log4j.xml");
		CommonBrowserControls.setBrowserType("chrome");
		WebDriver driver = CommonDriverControls.getdriver();
		CommonWindowSnapshotControls Obj12 = new CommonWindowSnapshotControls();
		ReadObject object = new ReadObject();
		Properties allObjects = object.getObjectRepository("Testing");
		UIOperation operation = new UIOperation(driver);

		TestCaseWorkBook = Constant.TestCasesInputFolder + "\\Testing.xlsx";
		oExcelDriver.openExcelWorkbook(TestCaseWorkBook);
		oExcelDriver.setExcelSheet("Testing");
		iRowCount = oExcelDriver.getRowCountoFSheet("Testing");

		try {
			for (int iRow = 14; iRow < iRowCount; iRow++) {

				// sTestCaseSheetName =
				// oExcelDriver.getCellData(oExcelDriver.getExcelSheet(),iRow, 9);
				sRunFlag = oExcelDriver.getCellData(oExcelDriver.getExcelSheet(), iRow, 16);
				sRunFlag = sRunFlag.toLowerCase().trim();
				// sTestCaseSheetName = sTestCaseSheetName.trim();
				// sCurrentTestCaseStatus = "Pass";

				if (sRunFlag.equalsIgnoreCase("yes")) {
					try {
						sActionKeyword = oExcelDriver
								.getCellData(oExcelDriver.getExcelSheet(), iRow, Constant.ActionKeywordColumn).trim();
						sObjectLocator = oExcelDriver
								.getCellData(oExcelDriver.getExcelSheet(), iRow, Constant.ObjectLocatorColumn).trim();
						sObjectType = oExcelDriver
								.getCellData(oExcelDriver.getExcelSheet(), iRow, Constant.ObjectTypeColumn).trim();
						sArgumentValue = oExcelDriver
								.getCellData(oExcelDriver.getExcelSheet(), iRow, Constant.ArgumentValueColumn).trim();
						System.out.println(sActionKeyword + "----" + sObjectLocator + "----" + sObjectType + "----"
								+ sArgumentValue);

						if (oExcelDriver.getCellData(oExcelDriver.getExcelSheet(), iRow, 9).length() == 0) {
							sReturnValue = operation.perform(allObjects, sActionKeyword, sObjectLocator, null,
									sObjectType, null, sArgumentValue, null);

							if (sReturnValue.contains("Exception") || sReturnValue.contains("exception")) {

								oExcelDriver.setCellData(oExcelDriver.getExcelSheet(), iRow, 19, "Failed");
								oExcelDriver.setCellData(oExcelDriver.getExcelSheet(), iRow, 22, sReturnValue);
								Obj12.takeSnapShot("NonLoginInitiateFailed");
								SendMailNotificationWithAttachment.mailToSendWithAttachment(
										"Hi, \n Automation Scripts of UAT Testing getting error at Page 'Login'. \n \n Please collect attached Snapshot of Failure because of \n\n"
												+ sReturnValue,
										Obj12.getSnapShot());

							} else {
								oExcelDriver.setCellData(oExcelDriver.getExcelSheet(), iRow, 19, "Passed");
							}

						}

					} catch (Exception e) {
						e.printStackTrace();
					}

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ExportToExcel.exportToExcel("Testing_Abhi");
			SendMailNotificationWithAttachment.mailToSendWithAttachment(
					"Hi, \n Automation Scripts of UAT Testing Execution is completed.Please collect result of Testing as \n\n",
					ExportToExcel.getExcelFile());	
	
		}
	}

}
