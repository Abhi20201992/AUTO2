package testCases;

import UIAutomationInTest.UITest;

public class TestingABC {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		UITest oUITest=new UITest ();
		
		oUITest.uiTestOperationBrowser("chrome", "eOTM", "EOTM_NonLogged.xlsx", "EOTM_NonLogged_Success", 14, 67, "EOTM_NonLogged_NB_Success");
		
	}

}
