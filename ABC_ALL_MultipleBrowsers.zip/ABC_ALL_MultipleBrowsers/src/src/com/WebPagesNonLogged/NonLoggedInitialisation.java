package src.com.WebPagesNonLogged;

import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;
import src.com.WebPagesLogged.DriverClass;

public class NonLoggedInitialisation {

	// public static void NonLoginOperation() throws Exception {
	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "NonLogin Initiate");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "INVEST WITH US is clicked")
	public void NonLogin_TC01() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//*[@id=\"ctl00_liTopNavigation_IndNonLoggedInMenu\"]/li[5]/a")));
			
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			Log.info("Clicked on INVEST WITH US");
			System.out.println("Clicked on INVEST WITH US");
			ExcelUtils.setCellData("Passed", Constant.NonLogin1, Constant.Result);
		    //assertTrue(el1.isEnabled());
		    
		} catch (Exception e) {
			Log.error("Not Clicked on INVEST WITH US" + "\n" + e);
			System.out.println("Not Clicked on INVEST WITH US");
			ExcelUtils.setCellData("Failed", Constant.NonLogin1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Clicked Quick Invest")
	public void NonLogin_TC02() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Quick Invest")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			Log.info("Clicked Quick Invest");
			System.out.println("Clicked Quick Invest");
			ExcelUtils.setCellData("Passed", Constant.NonLogin2, Constant.Result);
		    //assertTrue(el1.isEnabled());
			
		} catch (Exception e) {
			Log.error("Not Clicked Quick Invest" + "\n" + e);
			System.out.println("Not Clicked Quick Invest");
			ExcelUtils.setCellData("Failed", Constant.NonLogin2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "PAN CARD IS ENTERED")
	public void NonLogin_TC03() throws Exception {
		try {
			
			DriverClass.getdriver().navigate().refresh();
			
			Thread.sleep(3000);
			
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_0c1be14d_d39f_4d78_875e_3329816a006b_ctl00_txtIOPAN")));

			Thread.sleep(2000);
			el1.clear();
			Thread.sleep(1000);
			el1.sendKeys(ExcelUtils.getCellData(Constant.NonLogin3, Constant.InputData).trim());
			//AAKPS9421R
			Thread.sleep(2000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("PAN CARD IS ENTERED");
			System.out.println("PAN CARD IS ENTERED");
			ExcelUtils.setCellData("Passed", Constant.NonLogin3,Constant.Result);

			
			//String text = el1.getAttribute("value");
			//assertEquals(text, ExcelUtils.getCellData(Constant.NonLogin3, Constant.InputData).trim());
			

		} catch (Exception e) {
			Log.error("PAN CARD IS not ENTERED" + "\n" + e);
			System.out.println("PAN CARD IS not ENTERED");
			ExcelUtils.setCellData("Failed", Constant.NonLogin3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Verify is Clicked")
	public void NonLogin_TC04() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//*[@id=\"ctl00_m_g_0c1be14d_d39f_4d78_875e_3329816a006b_ctl00_lbtnVerify\"]")));
			
			JavascriptExecutor executor = (JavascriptExecutor)DriverClass.getdriver();
			executor.executeScript("arguments[0].click();", el1);
			
			//while(!el1.isEnabled())
			//el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Verify is Clicked");
			System.out.println("Verify is Clicked");
			ExcelUtils.setCellData("Passed", Constant.NonLogin4, Constant.Result);
			

			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			// System.out.println(el1.isEnabled());
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Verify is Clicked" + "\n" + e);
			System.out.println("Verify is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.NonLogin4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	
	
	@Test(description = "Folio number is selected")
	public void NonLogin_TC05() throws Exception {
		
			try {
				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			    wait.until(ExpectedConditions.presenceOfElementLocated(
						By.id("ctl00_m_g_0c1be14d_d39f_4d78_875e_3329816a006b_ctl00_ddlPanBasedFolios")));
				
				Thread.sleep(1000);
			
				Select folioNumber = new Select(DriverClass.getdriver().findElement(
						By.id("ctl00_m_g_0c1be14d_d39f_4d78_875e_3329816a006b_ctl00_ddlPanBasedFolios")));			
				//folioNumber.deselectAll();
				Thread.sleep(2000);
				folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLogin5, Constant.InputData).trim());
				DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
         
				Log.info("Folio number is selected");
				System.out.println("Folio number is selected");
				ExcelUtils.setCellData("Passed", Constant.NonLogin5, Constant.Result);
				//System.out.println(el1.isSelected());
				//assertEquals(folioNumber.getFirstSelectedOption().getText(),ExcelUtils.getCellData(Constant.NonLogin5, Constant.InputData).trim());
				
			} catch (Exception e) {
				Log.error("Folio number is not selected" + "\n" + e);
				System.out.println("Folio number is not selected");
				ExcelUtils.setCellData("Failed", Constant.NonLogin5, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginFailedSnapShot);
				e.printStackTrace();
			}
		}
	

	@Test(description = "Submit is clicked")
	public void NonLogin_TC06() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_0c1be14d_d39f_4d78_875e_3329816a006b_ctl00_lbtnSubmit")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Submit is Clicked");
			System.out.println("Submit is Clicked");
			ExcelUtils.setCellData("Passed", Constant.NonLogin6, Constant.Result);
		
		//System.out.println(el1.isEnabled());
			//assertTrue(el1.isEnabled());
		

			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
		
		} catch (Exception e) {
			Log.error("Submit is not Clicked" + "\n" + e);
			System.out.println("Submit is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.NonLogin6, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(),  Constant.NonLoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	
	
	
	@Test(description = "Generate OTP is Clicked")
	public void NonLogin_TC07() throws Exception {
		try {
			Thread.sleep(17000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Generate OTP")));
			el1.click();

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Generate OTP is Clicked");
			System.out.println("Generate OTP is Clicked");
			ExcelUtils.setCellData("Passed", Constant.NonLogin7, Constant.Result);
			//System.out.println(el1.isEnabled());
			//assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("Generate OTP is not Clicked" + "\n" + e);
			System.out.println("Generate OTP is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.NonLogin7, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(),  Constant.NonLoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	
	
	
	@Test(description="Alert is Accepted",enabled =true)
	public void NonLogin_TC08() throws Exception {

		try {
			Thread.sleep(4000);
			Alert alert = DriverClass.getdriver().switchTo().alert();
			DriverClass.getdriver().switchTo().alert();
			alert.getText();
			alert.accept();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Alert is Accepted");
			System.out.println("Alert is Accepted");
			ExcelUtils.setCellData("Passed", Constant.NonLogin8, Constant.Result);
			//System.out.println(alert.getText());
			//assertEquals(alert.getText(), "");

		} catch (Exception e) {
			Log.error("Alert is not Accepted" + "\n" + e);
			System.out.println("Alert is not Accepted");
			ExcelUtils.setCellData("Failed", Constant.NonLogin8, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}
	
	
	
	@Test(description = "OTP is Entered")
	public void NonLogin_TC09() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			try {
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
						By.id("ctl00_m_g_0c1be14d_d39f_4d78_875e_3329816a006b_ctl00_txtOTPCode")));

				Thread.sleep(1500);
				el1.clear();
				Thread.sleep(1500);
				el1.sendKeys(ExcelUtils.getCellData(Constant.NonLogin9, Constant.InputData).trim());
			} catch (Exception e) {

				WebElement el2 = wait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("ctl00_m_g_0c1be14d_d39f_4d78_875e_3329816a006b_ctl00_txtOTPCode")));

				Thread.sleep(1500);
				el2.clear();
				Thread.sleep(1500);
				el2.sendKeys("123456");
			}
			
			//123456
			Thread.sleep(2000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("OTP IS ENTERED");
			System.out.println("OTP IS ENTERED");
			ExcelUtils.setCellData("Passed", Constant.NonLogin9, Constant.Result);

			
			//String text = el1.getAttribute("value");
			//assertEquals(text, ExcelUtils.getCellData(Constant.NonLogin8, Constant.InputData).trim());
			

		} catch (Exception e) {
			Log.error("OTP is not Entered" + "\n" + e);
			System.out.println("OTP is not Entered");
			ExcelUtils.setCellData("Failed", Constant.NonLogin9, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(),  Constant.NonLoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Register Button is Clicked")
	public void NonLogin_TC10() throws Exception {

		try {
			Thread.sleep(1500);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_0c1be14d_d39f_4d78_875e_3329816a006b_ctl00_lnbRegister")));
			//while(!el1.isEnabled())
			el1.click();
			Thread.sleep(1500);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Log.info("Register Button is Clicked");
			System.out.println("Register Button is Clicked");
			ExcelUtils.setCellData("Passed", Constant.NonLogin10, Constant.Result);
			
			

			if(!(wait.until(ExpectedConditions.alertIsPresent())==null)) {
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}
			//System.out.println(el1.isEnabled());
			//assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("Register Button is not Clicked" + "\n" + e);
			System.out.println("Register Button is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.NonLogin10, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(),Constant.NonLoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "CheckBox is Checked")
	public void NonLogin_TC11() throws Exception {

		try {
			Thread.sleep(1500);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);

			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_0c1be14d_d39f_4d78_875e_3329816a006b_ctl00_chkIAgree")));
			//while(!el1.isSelected())
			el1.click();

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("\n CheckBox is Checked");
			System.out.println("\n CheckBox is Checked");
			ExcelUtils.setCellData("Passed", Constant.NonLogin11, Constant.Result);
			//System.out.println(el1.isEnabled());
			//assertTrue(el1.isSelected());
		} catch (Exception e) {
			Log.error("\n CheckBox is not Checked" + "\n" + e);
			System.out.println("\n CheckBox is not Checked");
			ExcelUtils.setCellData("Failed", Constant.NonLogin11,Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(),Constant.NonLoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Screen Shot is Taken and saved")
	public void NonLogin_TC12() throws Exception {
		try {
			
			
			System.out.println(DriverClass.getdriver().getTitle());
			
			//if(DriverClass.getdriver().getTitle()=="")
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.NonLogin12, Constant.Result);
			Log.info("Non Logged Initialisation is Successfully Completed,Thank you");
			System.out.println("Non Logged Initialisation is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.NonLogin12, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginFailedSnapShot);
			e.printStackTrace();

		}

	}

	@Test(description = "SetDriver")
	public void NonLogin_TC13() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
