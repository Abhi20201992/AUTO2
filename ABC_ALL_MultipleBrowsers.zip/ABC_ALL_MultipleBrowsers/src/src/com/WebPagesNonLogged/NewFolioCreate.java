package src.com.WebPagesNonLogged;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;
import src.com.WebPagesLogged.DriverClass;

public class NewFolioCreate {
	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");
		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "New Folio Creation");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "INVEST WITH US is clicked")
	public void newfolio_TC01() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//*[@id=\"ctl00_liTopNavigation_IndNonLoggedInMenu\"]/li[5]/a")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Clicked on INVEST WITH US");
			System.out.println("Clicked on INVEST WITH US");
			ExcelUtils.setCellData("Passed", Constant.Newfolio1, Constant.Result);
		//	assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Not Clicked on INVEST WITH US" + "\n" + e);
			System.out.println("Not Clicked on INVEST WITH US");
			ExcelUtils.setCellData("Failed", Constant.Newfolio1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "New Investor is clicked")
	public void newfolio_TC02() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("New Investor")));
			el1.click();

			Thread.sleep(3000);
			Log.info("New Investor is clicked");
			System.out.println("New Investor is clicked");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio2, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("New Investor is not clicked" + "\n" + e);
			System.out.println("New Investor is not clicked");
			ExcelUtils.setCellData("Failed", Constant.Newfolio2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Get Started is clicked")
	public void newfolio_TC03() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_lnbtnGetStarted")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Get Started is clicked");
			System.out.println("Get Started is clicked");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio3, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Get Started is not Clicked" + "\n" + e);
			System.out.println("Get Started is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Newfolio3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "PAN CARD IS ENTERED")
	public void newfolio_TC04() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_txtFirstPAN")));
			el1.clear();

			Thread.sleep(1000);
			el1.sendKeys(ExcelUtils.getCellData(Constant.Newfolio4, Constant.InputData).trim());
			Thread.sleep(2000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("PAN CARD IS ENTERED");
			System.out.println("PAN CARD IS ENTERED");
			ExcelUtils.setCellData("Passed", Constant.Newfolio4, Constant.Result);

			//String text = el1.getAttribute("value");
			//assertEquals("AAKPS9421R", text);

		} catch (Exception e) {
			Log.error("PAN CARD IS not ENTERED" + "\n" + e);
			System.out.println("PAN CARD IS not ENTERED");
			ExcelUtils.setCellData("Failed", Constant.Newfolio4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "DOB IS ENTERED")
	public void newfolio_TC05() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_txtFirstDob")));
			el1.clear();

			Thread.sleep(1000);
			el1.sendKeys(ExcelUtils.getCellData(Constant.Newfolio5, Constant.InputData).trim());
			
			//el1.sendKeys("11-Mar-1992");
			Thread.sleep(2000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("DOB IS ENTERED");
			System.out.println("DOB IS ENTERED");
			ExcelUtils.setCellData("Passed", Constant.Newfolio5, Constant.Result);

			//String text = el1.getAttribute("value");
			//assertEquals("11-MAR-1992", text);

		} catch (Exception e) {
			Log.error("DOB IS not ENTERED" + "\n" + e);
			System.out.println("DOB IS not ENTERED");
			ExcelUtils.setCellData("Failed", Constant.Newfolio5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Mobile number IS ENTERED")

	public void newfolio_TC06() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_txtMobileNo")));
			el1.clear();
			Thread.sleep(1000);
			el1.sendKeys(ExcelUtils.getCellData(Constant.Newfolio6, Constant.InputData).trim());
			Thread.sleep(2000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Mobile number IS ENTERED");
			System.out.println("Mobile number IS ENTERED");
			ExcelUtils.setCellData("Passed", Constant.Newfolio6, Constant.Result);

			//String text = el1.getAttribute("value");
			//assertEquals("7789456589", text);

		} catch (Exception e) {
			Log.error("Mobile number is not ENTERED" + "\n" + e);
			System.out.println("Mobile number is not ENTERED");
			ExcelUtils.setCellData("Failed", Constant.Newfolio6, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Email IS ENTERED")
	public void newfolio_TC07() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_txtEmail")));
			el1.clear();

			Thread.sleep(1000);
			el1.sendKeys(ExcelUtils.getCellData(Constant.Newfolio7, Constant.InputData).trim());
			Thread.sleep(2000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Email IS ENTERED");
			System.out.println("Email IS ENTERED");
			ExcelUtils.setCellData("Passed", Constant.Newfolio7, Constant.Result);

			//String text = el1.getAttribute("value");
			//assertEquals("kumarraja@gmail.com", text);

		} catch (Exception e) {
			Log.error("Email is not ENTERED" + "\n" + e);
			System.out.println("Email is not ENTERED");
			ExcelUtils.setCellData("Failed", Constant.Newfolio7, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Direct is selected")
	public void newfolio_TC08() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_rbAdvDetailDirect")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Direct is selected");
			System.out.println("Direct is selected");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio8, Constant.Result);
			//AssertJUnit.assertTrue(el1.isSelected());

		} catch (Exception e) {
			Log.error("Direct is not selected" + "\n" + e);
			System.out.println("Direct is not selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio8, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Check Status is Clicked")
	public void newfolio_TC09() throws Exception {
		try {
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_lnbtnNext1")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Check Status is Clicked");
			System.out.println("Check Status is Clicked");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio9, Constant.Result);
			//AssertJUnit.assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Check Status is not Clicked" + "\n" + e);
			System.out.println("Check Status is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Newfolio9, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Proceed is Clicked")
	public void newfolio_TC10() throws Exception {
		try {
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_lnbtnNext1")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Proceed is Clicked");
			System.out.println("Proceed is Clicked");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio10, Constant.Result);
			//AssertJUnit.assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Proceed is not Clicked" + "\n" + e);
			System.out.println("Proceed is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Newfolio10, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Generate OTP is Clicked")
	public void newfolio_TC11() throws Exception {
		try {
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_f77e8258_6596_44b2_af88_70fdd21f7662_ctl00_btnSubmit")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Generate OTP is Clicked");
			System.out.println("Generate OTP is Clicked");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio11, Constant.Result);
			//AssertJUnit.assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Generate OTP is not Clicked" + "\n" + e);
			System.out.println("Generate OTP is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Newfolio11, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Alert is Accepted", enabled = true)
	public void newfolio_TC12() throws Exception {

		try {
			Alert alert = DriverClass.getdriver().switchTo().alert();
			DriverClass.getdriver().switchTo().alert();
			alert.getText();
			alert.accept();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Alert is Accepted");
			System.out.println("Alert is Accepted");
			ExcelUtils.setCellData("Passed", Constant.Newfolio12, Constant.Result);
			System.out.println(alert.getText());
			// assertEquals(alert.getText(), "");

		} catch (Exception e) {
			Log.error("Alert is not Accepted" + "\n" + e);
			System.out.println("Alert is not Accepted");
			ExcelUtils.setCellData("Failed", Constant.Newfolio12, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "OTP IS ENTERED")
	public void newfolio_TC13() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_f77e8258_6596_44b2_af88_70fdd21f7662_ctl00_txtOTPCode")));
			el1.clear();

			Thread.sleep(1000);
			el1.sendKeys(ExcelUtils.getCellData(Constant.Newfolio13, Constant.InputData).trim());

			Thread.sleep(2000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			
			Log.info("OTP IS ENTERED");
			System.out.println("OTP IS ENTERED");
			ExcelUtils.setCellData("Passed", Constant.Newfolio13, Constant.Result);

			//String text = el1.getAttribute("value");
			//assertEquals("123456", text);

		} catch (Exception e) {
			Log.error("OTP is not ENTERED" + "\n" + e);
			System.out.println("OTP is not ENTERED");
			ExcelUtils.setCellData("Failed", Constant.Newfolio13, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Register Clicked")
	public void newfolio_TC14() throws Exception {
		try {
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_f77e8258_6596_44b2_af88_70fdd21f7662_ctl00_lnbRegister")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Register is Clicked");
			System.out.println("Register is Clicked");
		
			ExcelUtils.setCellData("Passed", Constant.Newfolio14, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Register is not Clicked" + "\n" + e);
			System.out.println("Register is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Newfolio14, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Tax Status is Selected")
	public void newfolio_TC15() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_ddlStatus")));
			Thread.sleep(1000);

			Select Name = new Select(el1);
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.Newfolio15, Constant.InputData).trim());
			// Resident Individual

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Tax Status  is Selected");
			System.out.println("Tax Status  is Selected");
			ExcelUtils.setCellData("Passed", Constant.Newfolio15, Constant.Result);
			System.out.println(el1.isSelected());
			//assertEquals(ExcelUtils.getCellData(Constant.Newfolio15, Constant.InputData).trim(),
				//	Name.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.error("Tax Status is not Selected" + "\n" + e);
			System.out.println("Tax Status is not Selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio15, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Next Clicked")
	public void newfolio_TC16() throws Exception {
		try {
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_lnbtnNext1")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Next is Clicked");
			System.out.println("Next is Clicked");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio16, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Next is not Clicked" + "\n" + e);
			System.out.println("Next is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Newfolio16, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Income is Selected")
	public void newfolio_TC17() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_ddlKycFApplicantGrossIncome")));
			Thread.sleep(1000);

			Select Name = new Select(el1);
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.Newfolio17, Constant.InputData).trim());
			// >5 <=10 Lacs

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Income is Selected");
			System.out.println("Income is Selected");
			ExcelUtils.setCellData("Passed", Constant.Newfolio17, Constant.Result);
			System.out.println(el1.isSelected());
			//assertEquals(ExcelUtils.getCellData(Constant.Newfolio17, Constant.InputData).trim(),
				//	Name.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.error("Income is not Selected" + "\n" + e);
			System.out.println("Income is not Selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio17, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Occupation is Selected")
	public void newfolio_TC18() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_ddlKycFApplicantOccup")));
			Thread.sleep(1000);

			Select Name = new Select(el1);
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.Newfolio18, Constant.InputData).trim());
			// Business

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Occupation is Selected");
			System.out.println("Occupation is Selected");
			ExcelUtils.setCellData("Passed", Constant.Newfolio18, Constant.Result);
			System.out.println(el1.isSelected());
			//assertEquals(ExcelUtils.getCellData(Constant.Newfolio18, Constant.InputData).trim(),
					//Name.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.error("Occupation is not Selected" + "\n" + e);
			System.out.println("Occupation is not Selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio18, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Politically Exposed yes/No is Selected")
	public void newfolio_TC19() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_ddlPoliticallyExposedFApplicanat")));
			Thread.sleep(1000);

			Select Name = new Select(el1);
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.Newfolio19, Constant.InputData).trim());
			// Yes

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Politically Exposed yes/No is Selected");
			System.out.println("Politically Exposed yes/No is Selected");
			ExcelUtils.setCellData("Passed", Constant.Newfolio19, Constant.Result);
			System.out.println(el1.isSelected());
			//assertEquals(ExcelUtils.getCellData(Constant.Newfolio19, Constant.InputData).trim(),
					//Name.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.error("Politically Exposed yes/No is not Selected" + "\n" + e);
			System.out.println("Politically Exposed yes/No is not Selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio19, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Birth Place is Selected")
	public void newfolio_TC20() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_ddlCountryOfBirthFApplicant")));
			Thread.sleep(1000);

			Select Name = new Select(el1);
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.Newfolio20, Constant.InputData).trim());
			// India

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Birth Place is Selected is Selected");
			System.out.println("Birth Place is Selected is Selected");
			ExcelUtils.setCellData("Passed", Constant.Newfolio20, Constant.Result);
			System.out.println(el1.isSelected());
			//assertEquals(ExcelUtils.getCellData(Constant.Newfolio20, Constant.InputData).trim(),
				//	Name.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.error("Birth Place is Selected is not Selected" + "\n" + e);
			System.out.println("Birth Place is Selectedis not Selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio20, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Place of birth is entered")
	public void newfolio_TC21() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_txtFApplPlaceOfBirth")));
			el1.clear();

			Thread.sleep(1000);
			el1.sendKeys(ExcelUtils.getCellData(Constant.Newfolio21, Constant.InputData).trim());
			Thread.sleep(2000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Place of Birth IS ENTERED");
			System.out.println("Place of Birth IS ENTERED");
			ExcelUtils.setCellData("Passed", Constant.Newfolio21, Constant.Result);

			//String text = el1.getAttribute("value");
			//assertEquals("Mumbai", text);

		} catch (Exception e) {
			Log.error("Place of Birth is not ENTERED" + "\n" + e);
			System.out.println("Place of Birth is not ENTERED");
			ExcelUtils.setCellData("Failed", Constant.Newfolio21, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Aadhar is entered")
	public void newfolio_TC22() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_txtFApplAadhar")));
			el1.clear();

			Thread.sleep(1000);
			el1.sendKeys(ExcelUtils.getCellData(Constant.Newfolio22, Constant.InputData).trim());
			Thread.sleep(2000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Aadhar IS ENTERED");
			System.out.println("Aadhar IS ENTERED");
			ExcelUtils.setCellData("Passed", Constant.Newfolio22, Constant.Result);

			//String text = el1.getAttribute("value");
			//assertEquals("234434533455", text);

		} catch (Exception e) {
			Log.error("Aadhar is not ENTERED" + "\n" + e);
			System.out.println("Aadhar is not ENTERED");
			ExcelUtils.setCellData("Failed", Constant.Newfolio22, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Gender is Selected")
	public void newfolio_TC23() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_ddlfirstApplicantgender")));
			Thread.sleep(1000);

			Select Name = new Select(el1);
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.Newfolio23, Constant.InputData).trim());
			// Male

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Gender is Selected");
			System.out.println("Gender is Selected");
			ExcelUtils.setCellData("Passed", Constant.Newfolio23, Constant.Result);
			System.out.println(el1.isSelected());
			//assertEquals(ExcelUtils.getCellData(Constant.Newfolio23, Constant.InputData).trim(),
			//		Name.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.error("Gender is not Selected" + "\n" + e);
			System.out.println("Gender is not Selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio23, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Fatca is selected")
	public void newfolio_TC24() throws Exception {
		try {
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_rbFATCTANonIndianNo")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Fatca is selected");
			System.out.println("Next is Clicked");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio24, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Fatca is not selected" + "\n" + e);
			System.out.println("Fatca is not selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio24, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Checkbox is selected")
	public void newfolio_TC25() throws Exception {
		try {
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_ChkUBO_DECLARATIONYes")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Checkbox is Clicked");
			System.out.println("Checkbox is Clicked");
			ExcelUtils.setCellData("Passed", Constant.Newfolio25, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Checkbox is not selected" + "\n" + e);
			System.out.println("Checkbox is not selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio25, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "NExt is Clicked")
	public void newfolio_TC26() throws Exception {
		try {
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_lnbtnNextKYCFATCA")));
			el1.click();
			Thread.sleep(3000);
			Log.info("NExt is Clicked");
			System.out.println("NExt is Clicked");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio26, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Next is not Clicked" + "\n" + e);
			System.out.println("NExt is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Newfolio26, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Bank is selected")
	public void newfolio_TC27() throws Exception {
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_ddlBankName")));

			Select Name = new Select(el1);
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.Newfolio27, Constant.InputData).trim());
			// BANK OF AMERICA

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			Thread.sleep(3000);
			Log.info("BANK is selected");
			System.out.println("BANK is selected");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio27, Constant.Result);
			//assertEquals(ExcelUtils.getCellData(Constant.Newfolio23, Constant.InputData).trim(),
			//		Name.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.error("BANK is not selected" + "\n" + e);
			System.out.println("BANK is not selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio27, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Branch city is selected")
	public void newfolio_TC28() throws Exception {
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_ddlBranchCity")));

			Select Name = new Select(el1);
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.Newfolio28, Constant.InputData).trim());
			// �MUMBAI

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			Thread.sleep(3000);
			Log.info("Branch City is selected");
			System.out.println("Branch City is selected");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio28, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("BANK is not selected" + "\n" + e);
			System.out.println("BANK is not selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio28, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Branch name is selected")
	public void newfolio_TC29() throws Exception {
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_ddlBranchName")));

			Select Name = new Select(el1);
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.Newfolio29, Constant.InputData).trim());
			// RTGS-HO

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			Thread.sleep(3000);
			Log.info("Branch name is selected");
			System.out.println("Branch name is selected");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio29, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Branch name is not selected" + "\n" + e);
			System.out.println("Branch name  is not selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio29, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Account Type is selected")
	public void newfolio_TC30() throws Exception {
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_ddlAccountType")));

			Select Name = new Select(el1);
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.Newfolio30, Constant.InputData).trim());
			// Savings Account

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			Thread.sleep(3000);
			Log.info("Account Type is selected");
			System.out.println("Account Type is selected");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio30, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Account Type is not selected" + "\n" + e);
			System.out.println("Account Type  is not selected");
			ExcelUtils.setCellData("Failed", Constant.Newfolio30, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Account number is entered")
	public void newfolio_TC31() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_txtAccountNo")));
			el1.clear();

			Thread.sleep(1000);
			el1.sendKeys(ExcelUtils.getCellData(Constant.Newfolio31, Constant.InputData).trim());
			Thread.sleep(2000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Account number IS ENTERED");
			System.out.println("Account number IS ENTERED");
			ExcelUtils.setCellData("Passed", Constant.Newfolio31, Constant.Result);

			//String text = el1.getAttribute("value");
			//assertEquals("234434533455", text);

		} catch (Exception e) {
			Log.error("Account number is not ENTERED" + "\n" + e);
			System.out.println("Account number is not ENTERED");
			ExcelUtils.setCellData("Failed", Constant.Newfolio31, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Confirm Account number is entered")
	public void newfolio_TC32() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_txtConfirmAccountNo")));
			el1.clear();

			Thread.sleep(1000);
			el1.sendKeys(ExcelUtils.getCellData(Constant.Newfolio32, Constant.InputData).trim());
			Thread.sleep(2000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Account number IS ENTERED again ");
			System.out.println("Account number IS ENTERED again");
			ExcelUtils.setCellData("Passed", Constant.Newfolio32, Constant.Result);

			//String text = el1.getAttribute("value");
			//assertEquals("234434533455", text);

		} catch (Exception e) {
			Log.error("Account number is not ENTERED again" + "\n" + e);
			System.out.println("Account number is not ENTERED again");
			ExcelUtils.setCellData("Failed", Constant.Newfolio32, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Next is Clicked")
	public void newfolio_TC33() throws Exception {
		try {
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_lnbtnNext2")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Next is Clicked");
			System.out.println("Next is Clicked");
		
			ExcelUtils.setCellData("Passed", Constant.Newfolio33, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Next is not Clicked" + "\n" + e);
			System.out.println("Next is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Newfolio33, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Checkbox is Clicked")
	public void newfolio_TC34() throws Exception {
		try {
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_chkNomination")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Checkbox is Clicked");
			System.out.println("Checkbox is Clicked");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio34, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Checkbox is not Clicked" + "\n" + e);
			System.out.println("Checkbox is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Newfolio34, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Next is Clicked")
	public void newfolio_TC35() throws Exception {
		try {
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_30580ef3_7c90_4df5_bf70_319a594b50d6_ctl00_lnbtnNext3")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Next is Clicked");
			System.out.println("Next is Clicked");
			
			ExcelUtils.setCellData("Passed", Constant.Newfolio35, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Next is not Clicked" + "\n" + e);
			System.out.println("Next is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Newfolio35, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Screen Shot is Taken and saved")
	public void newfolio_TC36() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioSuccessSnapShot1);

			try {
				JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
				js.executeScript("window.scrollBy(0,200)");
			} catch (Exception e) {
				e.printStackTrace();
			}
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioSuccessSnapShot2);

			try {
				JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
				js.executeScript("window.scrollBy(0,200)");
			} catch (Exception e) {
				e.printStackTrace();
			}
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioSuccessSnapShot3);

			try {
				JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
				js.executeScript("window.scrollBy(0,200)");
			} catch (Exception e) {
				e.printStackTrace();
			}
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioSuccessSnapShot4);

			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.Newfolio36, Constant.Result);
			Log.info("New Folio Creation is Successfully Completed,Thank you");
			System.out.println("Logged Purchase is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.Newfolio36, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NewfolioFailedSnapShot);
			e.printStackTrace();

		}

	}

	@Test(description = "SetDriver")
	public void newfolio_TC37() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
