package src.com.WebPagesLogged;

import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class Switch {

	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");
		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Switch");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

		

	/*@Test(description = "Login is Clicked")
	public void LoginABC_TC01() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait
					.until(ExpectedConditions.presenceOfElementLocated(By.id("ctl00_liTopNavigation_LoginId")));
			el1.click();

			System.out.println("Login is Clicked");
			Log.info("Login is Clicked");
			//ExcelUtils.setCellData("Passed", Constant.LoginABCrow, Constant.Result);
		} catch (Exception e) {

			Log.error("Login Click is not Working" + "\n" + e);
			//ExcelUtils.setCellData("Failed", Constant.LoginABCrow, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}


	@Test(description = "Username is Entered")
	public void LoginABC_TC02() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_ab26497d_e15c_4de5_bd3e_1c795586e234_ctl00_txtUsername")));
			el1.clear();
			el1.sendKeys("anupdi@123");
			Log.info("Username is entered");
			System.out.println("Username is Entered ");
			//ExcelUtils.setCellData("Passed", Constant.LoginABCrow1, Constant.Result);
			//String text = el1.getAttribute("value");
			//assertEquals(text, "anupdi@123");

		} catch (Exception e) {
			Log.error("Username is not entered" + "\n" + e);
			System.out.println("Username is not Entered ");
			//ExcelUtils.setCellData("Failed", Constant.LoginABCrow1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}


	@Test(description = "Password is entered")
	public void LoginABC_TC03() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_ab26497d_e15c_4de5_bd3e_1c795586e234_ctl00_txtPassword")));
			el1.clear();
			el1.sendKeys("pass@123");
			Log.info("Password is entered");
			System.out.println("Password is Entered");
			//ExcelUtils.setCellData("Passed", Constant.LoginABCrow2, Constant.Result);
			//String text = el1.getAttribute("value");
			//assertEquals(text, "pass@123");

		} catch (Exception e) {
			Log.error("Password is not entered" + "\n" + e);
			System.out.println("Password is not Entered");
			//ExcelUtils.setCellData("Failed", Constant.LoginABCrow2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Login Button is Clicked")
	public void LoginABC_TC04() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_ab26497d_e15c_4de5_bd3e_1c795586e234_ctl00_btnLogin")));
			el1.click();
			Log.info("Login Button is Clicked");
			System.out.println("Login Button is Clicked");
			//ExcelUtils.setCellData("Passed", Constant.LoginABCrow3, Constant.Result);
		} catch (Exception e) {
			Log.error("Login Button is not Clicked" + "\n" + e);
			System.out.println("Login Button is not Clicked");
			//ExcelUtils.setCellData("Failed", Constant.LoginABCrow3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Extra Tab is Closed")
	public void LoginABC_TC05() throws Exception {
		try {

			Thread.sleep(2000);

			ArrayList<String> tabs2 = new ArrayList<String>(DriverClass.getdriver().getWindowHandles());
			DriverClass.getdriver().switchTo().window(tabs2.get(1));
			DriverClass.getdriver().close();
			DriverClass.getdriver().switchTo().window(tabs2.get(0));
			Log.info("Extra Tab is Closed");
			System.out.println("Extra Tab is Closed");
			//ExcelUtils.setCellData("Passed", Constant.LoginABCrow4, Constant.Result);
		} catch (Exception e) {
			Log.error("Extra Tab is not Closed" + "\n" + e);
			System.out.println("Extra Tab is not Closed");
			//ExcelUtils.setCellData("Failed", Constant.LoginABCrow4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Site User Authenticatio is Done")
	public void LoginABC_TC06() throws Exception {
		try {
			Runtime.getRuntime().exec(Constant.SiteUserAuth);
			System.out.println("SiteUser Authentication is done");
			//ExcelUtils.setCellData("Passed", Constant.LoginABCrow5, Constant.Result);
			Log.info("Site User Authenticatio is Done");
			ExcelUtils.setCellData("Passed", Constant.LoginABCrow5, Constant.Result);

		} catch (Exception e) {
			Log.error("Site User Authenticatio is not Done" + "\n" + e);
			System.out.println("Site User Authenticatio is not Done");
			//ExcelUtils.setCellData("Failed", Constant.LoginABCrow5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Clicked Mutual Funds")
	public void LoginABC_TC07() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginSuccessSnapShot);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"mfheading\"]/a/h4")));
			el1.click();
			Log.info("Clicked Mutual Funds");
			System.out.println("Clicked Mutual Funds ");
			//ExcelUtils.setCellData("Passed", Constant.LoginABCrow6, Constant.Result);

		} catch (Exception e) {
			Log.error("Clicked Mutual Funds Failed" + "\n" + e);
			System.out.println("Clicked Mutual Funds Failed ");
			//ExcelUtils.setCellData("Failed", Constant.LoginABCrow6, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}

	}
	
*/
	
	@Test(description = "Switch is clicked")
	public void switch_TC01() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_e8e6e5b9_f91b_4286_9438_afe832ba38c2_ctl00_InvDashboardScheme_lbnSwitch")));
			el1.click();
			Thread.sleep(2000);
			Log.info("Switch is clicked");
			System.out.println("Switch is clicked");
			ExcelUtils.setCellData("Passed", Constant.switch1, Constant.Result);
			//assertEquals("Pages - Switch", DriverClass.getdriver().getTitle(), "Incorrect Page Opened");

		} catch (Exception e) {
			Log.error("Switch is not clicked" + "\n" + e);
			System.out.println("Switch is not clicked");
			ExcelUtils.setCellData("Failed", Constant.switch1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Advisor is selected")
	public void switch_TC02() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(
					"ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_ddlAdvDetailAdvisorName")));
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			Select advisorName = new Select(DriverClass.getdriver().findElement(By.id(
					"ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_ddlAdvDetailAdvisorName")));
			advisorName.selectByVisibleText(ExcelUtils.getCellData(Constant.switch2, Constant.InputData).trim());
			// Direct
			Log.info("Advisor is Selected");
			System.out.println("Advisor is Selected");
			ExcelUtils.setCellData("Passed", Constant.switch2, Constant.Result);

			//assertEquals(advisorName.getFirstSelectedOption().getText(),
			//		ExcelUtils.getCellData(Constant.switch2, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Advisor is not selected" + "\n" + e);
			System.out.println("Advisor is not selected");
			ExcelUtils.setCellData("Failed", Constant.switch2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "Advisor details are entered", enabled=true)
	public void switch_TC03() throws Exception {
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement e11 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_txtAdvDetailARN")));

			e11.clear();
			e11.sendKeys(ExcelUtils.getCellData(Constant.switch3, Constant.InputData).trim());
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			Thread.sleep(1500);
			Log.info(ExcelUtils.getCellData(Constant.switch3, Constant.InputData).trim()+"is entered");
			System.out.println(ExcelUtils.getCellData(Constant.switch3, Constant.InputData).trim()+"is entered");
			ExcelUtils.setCellData("Passed", Constant.switch3, Constant.Result);

			//String text = e11.getAttribute("value");
			//assertEquals(text, "ARN-4968");

		} catch (Exception e) {
			Log.info(ExcelUtils.getCellData(Constant.switch3, Constant.InputData).trim()+"is not entered");
			System.out.println(ExcelUtils.getCellData(Constant.switch3, Constant.InputData).trim()+"is not entered");
			ExcelUtils.setCellData("Failed", Constant.switch3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "checkbox selected")
	public void switch_TC04() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement e11 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_chkEUIN")));
			e11.click();
			Thread.sleep(2000);
			Log.info("checkbox selected");
			System.out.println("checkbox selected");
			ExcelUtils.setCellData("Passed", Constant.switch4, Constant.Result);
			//assertTrue(e11.isSelected());
		} catch (Exception e) {
			Log.error("checkbox selected" + "\n" + e);
			System.out.println("checkbox selected");
			ExcelUtils.setCellData("Failed", Constant.switch4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "Scheme details is selected")
	public void switch_TC05() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id(
					"ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_ddlSchDetailsFromScheme")));
			Select fromScheme = new Select(el1);
			
			fromScheme.selectByVisibleText(ExcelUtils.getCellData(Constant.switch5, Constant.InputData).trim());
			
			// Frontline Equity Fund -Dividend-Regular Plan is selected
			Log.info("Scheme details is selected");
			System.out.println("Scheme details is selected");
			ExcelUtils.setCellData("Passed", Constant.switch5, Constant.Result);

			//assertEquals(fromScheme.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.switch5, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Scheme details not Selected" + "\n" + e);
			System.out.println("Scheme details not Selected");
			ExcelUtils.setCellData("Failed", Constant.switch5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Catagory is selected")
	public void switch_TC06() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(
					"ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_ddlSchDetailsSchCategory")));
			
			
			String Index=ExcelUtils.getCellData(Constant.switch6, Constant.InputData2).trim();
			int Index1=Integer.parseInt(Index);
			
			Select catagory = new Select(DriverClass.getdriver().findElement(By.id(
					"ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_ddlSchDetailsSchCategory")));
			try {
			catagory.selectByVisibleText(ExcelUtils.getCellData(Constant.switch6, Constant.InputData).trim());// DEBT
			}
			catch(Exception e) {
			 e.printStackTrace();
			 catagory.selectByIndex(Index1);
			}
			
			Log.info("Catagory is selected");
			System.out.println("Catagory is selected");
			ExcelUtils.setCellData("Passed", Constant.switch6, Constant.Result);
			//assertEquals(catagory.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.switch6, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Catagory is not selected" + "\n" + e);
			System.out.println("Catagory is not selected");
			ExcelUtils.setCellData("Failed", Constant.switch6, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}

	}
	

	@Test(description = "Scheme sub Catagory is selected")
	public void switch_TC07() throws Exception {
		
			try {
				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(
						"ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_ddlToSchemeSubCategory")));

				Thread.sleep(1500);
				
				
				String Index=ExcelUtils.getCellData(Constant.switch7, Constant.InputData2).trim();
				int Index1=Integer.parseInt(Index);
					
				Select SchemeCat = new Select(DriverClass.getdriver().findElement(By.id("ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_ddlToSchemeSubCategory")));	   
		
				try {
				  SchemeCat.selectByVisibleText(ExcelUtils.getCellData(Constant.switch7, Constant.InputData).trim());
		    	} catch (Exception e) {
				  e.printStackTrace();
				  SchemeCat.selectByIndex(Index1);
			    }
			
				Thread.sleep(1500);
				DriverClass.getdriver().manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
				Log.info("Scheme sub Catagory is selected");
				System.out.println("Scheme Catagory is selected");
				ExcelUtils.setCellData("Passed", Constant.switch7, Constant.Result);
				// System.out.println(el1.isSelected());
				// assertTrue(el1.isSelected());
				//assertEquals(ExcelUtils.getCellData(Constant.switch6, Constant.InputData).trim(),SchemeCat.getFirstSelectedOption().getText());

			} catch (Exception e) {
				Log.error("Scheme sub Catagory is not selected" + "\n" + e);
				System.out.println("Scheme sub Catagory is not selected");
				ExcelUtils.setCellData("Failed",Constant.switch7, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(),Constant.SwitchFailedSnapShot);
				e.printStackTrace();
			}
		}
	
	
		
	@Test(description = "To Scheme option is selected")
	public void switch_TC08() throws Exception {

	
			try {
				DriverClass.getdriver().findElement(By.id(
						"ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_ddlSchDetailstToScheme"));
				DriverClass.getdriver().manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
				Select Name = new Select(DriverClass.getdriver().findElement(By.id(
						"ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_ddlSchDetailstToScheme")));
				
				
				String Index=ExcelUtils.getCellData(Constant.switch8, Constant.InputData2).trim();
				int Index1=Integer.parseInt(Index);
				
				
				try {
				Name.selectByVisibleText(ExcelUtils.getCellData(Constant.switch8, Constant.InputData).trim());
				}catch(Exception e) {
					e.printStackTrace();
					Name.selectByIndex(Index1);
				}
				Log.info("To Scheme is selected");
				System.out.println("To Scheme is selected");

				ExcelUtils.setCellData("Passed", Constant.switch8, Constant.Result);
				//assertEquals(Name.getFirstSelectedOption().getText(),
					//	ExcelUtils.getCellData(Constant.switch8, Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("To Scheme is not selected" + "\n" + e);
				System.out.println("To Scheme is not selected");
				ExcelUtils.setCellData("Failed", Constant.switch8, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
				e.printStackTrace();
			}
		}
	

	@Test(description = "Scheme details option is selected")
	public void switch_TC09() throws Exception {

		
			try {

				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id(
						"ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_ddlSchDetailsSchOption")));

				Thread.sleep(1000);
				String Index=ExcelUtils.getCellData(Constant.switch9, Constant.InputData2).trim();
				int Index1=Integer.parseInt(Index);
				
				
				
			    Select Name = new Select(el1);
			
			    try {
			    Name.selectByVisibleText(ExcelUtils.getCellData(Constant.switch9, Constant.InputData).trim());// Growth
			    }catch(Exception e) {
			    	e.printStackTrace();
			    	Name.selectByIndex(Index1);
			    }
				Log.info("Scheme details option is selected");
				System.out.println("Scheme details option is selected");

				ExcelUtils.setCellData("Passed", Constant.switch9, Constant.Result);
				//assertEquals(Name.getFirstSelectedOption().getText(),
					//	ExcelUtils.getCellData(Constant.switch9, Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("Scheme details option is not selected" + "\n" + e);
				System.out.println("Scheme details option is not selected");
				ExcelUtils.setCellData("Failed", Constant.switch9, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
				e.printStackTrace();
			}
		}


	@Test(description = "No is Clicked")
	public void switch_TC10() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_rdNo")));
			el1.click();

			Log.info("No is Clicked");
			System.out.println("No is Clicked");
			ExcelUtils.setCellData("Passed", Constant.switch10, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("No is not Clicked" + "\n" + e);
			System.out.println("No is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.switch10, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "Amount Radio button Clicked", enabled = false)
	public void switch_TC11() throws Exception {
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_rdAmount")));
			el1.click();
			
			Log.info("Amount is Clicked");
			System.out.println("Amount is Clicked");
			ExcelUtils.setCellData("Passed", Constant.switch11, Constant.Result);
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Amount is not Clicked" + "\n" + e);
			System.out.println("Amount is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.switch11, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Amount Radio button Clicked")
	public void switch_TC12() throws Exception {
		try {
			Thread.sleep(5000);
			
			WebElement element = DriverClass.getdriver()
					.findElement(By.id("ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_rdAmount"));
			JavascriptExecutor executor = (JavascriptExecutor) DriverClass.getdriver();
			executor.executeScript("arguments[0].click();", element);

			Log.info("Amount Radio button was tried to click One Way");
			System.out.println("Amount Radio button was tried to click One Way");

			ExcelUtils.setCellData("Passed", Constant.switch12, Constant.Result);
			//assertTrue(element.isEnabled());

		} catch (Exception e) {
			Log.error("Amount Radio button is not Clicked" + "\n" + e);
			System.out.println("Amount Radio button is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.switch12, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Amount is Entered")
	public void switch_TC13() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id(
					"ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_txtSchDetailsUnitsToSwitch")));
			el1.clear();
			Thread.sleep(2500);
			el1.sendKeys(ExcelUtils.getCellData(Constant.switch13,Constant.InputData));
			Thread.sleep(3000);
						
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Thread.sleep(1500);
			Log.info("Amount is Entered");
			System.out.println("Amount is Entered");
			ExcelUtils.setCellData("Passed", Constant.switch13, Constant.Result);

			//String text = el1.getAttribute("value");
			//assertEquals(text, "1000");

		} catch (Exception e) {
			Log.error("Amount is not Entered" + "\n" + e);
			System.out.println("Amount is not Entered");
			ExcelUtils.setCellData("Failed", Constant.switch13, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "checkKeyInfo is not Clicked")
	public void switch_TC14() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_chkKeyInfo")));
			el1.click();
			Thread.sleep(2000);

			Log.info("checkKeyInfo is Clicked");
			System.out.println("checkKeyInfo is Clicked");
			ExcelUtils.setCellData("Passed", Constant.switch14, Constant.Result);
			//assertTrue(el1.isSelected());

		} catch (Exception e) {
			Log.error("checkKeyInfo is not Clicked" + "\n" + e);
			System.out.println("checkKeyInfo is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.switch14, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Next is Clicked")
	public void switch_TC15() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_lbtnSchemeDetailNext")));
			el1.click();
			Thread.sleep(2000);

			Log.info("Next is Clicked");
			System.out.println("Next is Clicked");
			ExcelUtils.setCellData("Passed", Constant.switch15, Constant.Result);
			//assertTrue(el1.isSelected());

			

			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
		} catch (Exception e) {
			Log.error("Next is not Clicked" + "\n" + e);
			System.out.println("Next is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.switch15, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Pop up accept", enabled=false)
	public void switch_TC16() throws Exception {

		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_divduplicate")));
			el1.click();
			Thread.sleep(2000);
			WebElement el2 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_btnYespop")));
			el2.click();

			Log.info("Pop up is accepted");
			System.out.println("Pop up is accepted");
			ExcelUtils.setCellData("Passed", Constant.switch16, Constant.Result);
			//assertTrue(el2.isSelected());

		} catch (Exception e) {

			Log.error("Pop up is  not Clicked" + "\n" + e);
			System.out.println("Pop up is  not Clicked");
			ExcelUtils.setCellData("Failed", Constant.switch16, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();

		}

	}

	@Test(description = "Next is Clicked")
	public void switch_TC17() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By
					.id("ctl00_m_g_c46609bb_f310_4bdb_b267_824c1721615f_ctl00_SwitchRequest1_lbtnConfirmDetailsNext")));
			el1.click();
			Thread.sleep(2000);

			Log.info("Next is Clicked");
			System.out.println("Next is Clicked");
			ExcelUtils.setCellData("Passed", Constant.switch17, Constant.Result);
			//assertTrue(el1.isSelected());

			

			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
		} catch (Exception e) {
			Log.error("Next is not Clicked" + "\n" + e);
			System.out.println("Next is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.switch17, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Scrolling is done")
	public void switch_TC18() throws Exception {
		try {

			JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
			js.executeScript("window.scrollBy(0,-500)");
			ExcelUtils.setCellData("Passed", Constant.switch18, Constant.Result);
			Log.info("Scrolling is done");
			System.out.println("Scrolling is done");

		} catch (Exception e) {
			Log.error("Scolling is not done" + "\n" + e);
			System.out.println("Scolling is not done");
			ExcelUtils.setCellData("Failed", Constant.switch18, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Screen Shot is Taken and saved")
	public void switch_TC19() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.switch19, Constant.Result);
			Log.info("Switch is Successfully Completed,Thank you");
			System.out.println("Switch is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.switch19, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "SetDriver")
	public void switch_TC20() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
