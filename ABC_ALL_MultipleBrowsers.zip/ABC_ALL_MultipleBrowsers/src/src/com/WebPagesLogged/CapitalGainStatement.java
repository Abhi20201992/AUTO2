package src.com.WebPagesLogged;

import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class CapitalGainStatement {

	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");
		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "CapitalGainStatement");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "Capital Gain is Clicked")
	public void capitalGainStatement_TC01() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			Thread.sleep(1500);
			WebElement el2 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_e8e6e5b9_f91b_4286_9438_afe832ba38c2_ctl00_InvDashboardScheme_lbnCapitalGain")));	
			el2.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("\n Capital Gain is Clicked ");
			System.out.println("\n Capital Gain is Clicked");
			ExcelUtils.setCellData("Passed", Constant.CapitalGainStatement1, Constant.Result);
			//assertTrue(el2.isEnabled());
		} catch (Exception e) {
			Log.error("\n Capital Gain is not Clicked" + "\n" + e);
			System.out.println("\n Capital Gain is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.CapitalGainStatement1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.CapitalGainStatementFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Folio Number is selected")
	public void capitalGainStatement_TC02() throws Exception {
			try {
				
				DriverClass.getdriver().findElement(By.xpath("//*[@id=\"ctl00_m_g_338b2341_6334_4a77_87d3_59fa341aad7d\"]/div[2]/div[1]")).click();
				
				DriverClass.getdriver().findElement(By.xpath("//*[@id=\"ctl00_m_g_338b2341_6334_4a77_87d3_59fa341aad7d\"]/div[2]/div[2]/div")).click();
				
				//DriverClass.getdriver().findElement(By.xpath("")).click();
				
								
				Select Name = new Select(DriverClass.getdriver()
						.findElement(By.id("ctl00_m_g_338b2341_6334_4a77_87d3_59fa341aad7d_ctl00_ddlFolioNo")));
				Name.selectByVisibleText(ExcelUtils.getCellData(Constant.CapitalGainStatement2, Constant.InputData).trim());// 4
			
				DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				
				Log.error("Folio Number is selected" );
				System.out.println("Folio Number is  selected");
				ExcelUtils.setCellData("Passed", Constant.CapitalGainStatement2, Constant.Result);
			
			
			} catch (Exception e) {
				Log.error("Folio Number is not selected" + "\n" + e);
				System.out.println("Folio Number is not selected");
				ExcelUtils.setCellData("Failed", Constant.CapitalGainStatement2, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.CapitalGainStatementFailedSnapShot);
				e.printStackTrace();
			}
		}
	
	@Test(description = "Financial Year is selected")
	public void capitalGainStatement_TC03() throws Exception {
	
			try {
				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			    wait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id=\"ctl00_m_g_338b2341_6334_4a77_87d3_59fa341aad7d_ctl00_ddlYear\"]")));
				Thread.sleep(1000);
			
				Select Name = new Select(DriverClass.getdriver()
						.findElement(By.xpath("//*[@id=\"ctl00_m_g_338b2341_6334_4a77_87d3_59fa341aad7d_ctl00_ddlYear\"]")));
			
				Name.selectByVisibleText(ExcelUtils.getCellData(Constant.CapitalGainStatement3, Constant.InputData).trim());// 4
				DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

				Log.info("Financial Year is selected");
				System.out.println("Financial Year is selected");

				ExcelUtils.setCellData("Passed", Constant.CapitalGainStatement3, Constant.Result);
				//System.out.println(el1.isSelected());
				//assertEquals(Name.getFirstSelectedOption().getText(),
				//		ExcelUtils.getCellData(Constant.CapitalGainStatement3, Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("Financial Year is not selected " + "\n" + e);
				System.out.println("Financial Year is not selected");
				ExcelUtils.setCellData("Failed", Constant.CapitalGainStatement3, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.CapitalGainStatementFailedSnapShot);
				e.printStackTrace();
			}
		}


	@Test(description = "Pdf is downloading")
	public void capitalGainStatement_TC04() throws Exception {

		try {
			Thread.sleep(1500);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//*[@id=\"ctl00_m_g_338b2341_6334_4a77_87d3_59fa341aad7d_ctl00_lbtnDownload\"]")));
		
			el1.click();
			
			try {
				Thread.sleep(8000);
				wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
			}catch(Exception e) {
				e.printStackTrace();
			}
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("\n Pdf is downloading ");
			System.out.println("\n Pdf is downloading");
			ExcelUtils.setCellData("Passed", Constant.CapitalGainStatement4, Constant.Result);
			//assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("\n Capital Gain is not Clicked" + "\n" + e);
			System.out.println("\n Capital Gain is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.CapitalGainStatement4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.CapitalGainStatementFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Screen Shot is Taken and saved")
	public void capitalGainStatement_TC05() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.CapitalGainStatementSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.CapitalGainStatement5, Constant.Result);
			Log.info("Capital Gain Statement Testing is Successfully Completed,Thank you");
			System.out.println("Capital Gain Statement Testing is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.CapitalGainStatement5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.CapitalGainStatementFailedSnapShot);
			e.printStackTrace();

		}

	}

	@Test(description = "SetDriver")
	public void capitalGainStatement_TC06() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
