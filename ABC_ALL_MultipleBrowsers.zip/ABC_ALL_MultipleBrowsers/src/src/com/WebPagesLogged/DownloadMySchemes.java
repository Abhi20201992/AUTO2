package src.com.WebPagesLogged;

import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class DownloadMySchemes {

	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");
		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "DownloadMySchemes");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "Excel is downloding")
	public void downloadMySchemes_TC01() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_e8e6e5b9_f91b_4286_9438_afe832ba38c2_ctl00_InvDashboardScheme_lbndownload")));
			el1.click();
			Thread.sleep(4000);
			Log.info("Excel is downloding");
			System.out.println("Excel is downloding");
			ExcelUtils.setCellData("Passed", Constant.downloadMySchemes1, Constant.Result);
			
			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			
			
		} catch (Exception e) {
			Log.error("Excel is not downloding" + "\n" + e);
			System.out.println("Excel is not downloding");
			ExcelUtils.setCellData("Failed", Constant.downloadMySchemes1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.DownloadMySchemesFailedSnapShot);
			e.printStackTrace();
		}
	}
	
	@Test(description="Screen Shot is Taken and saved")
	public void downloadMySchemes_TC02() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.DownloadMySchemesSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.downloadMySchemes2, Constant.Result);
			Log.info("Download MySchemes is Successfully Completed,Thank you");
			System.out.println("Download MySchemes is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.downloadMySchemes2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.DownloadMySchemesFailedSnapShot);
			e.printStackTrace();
		}

	}
	
	
	@Test(description = "SetDriver")
	public void downloadMySchemes_TC03() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
