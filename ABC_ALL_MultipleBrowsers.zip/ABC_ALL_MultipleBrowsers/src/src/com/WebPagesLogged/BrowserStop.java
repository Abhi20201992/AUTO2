package src.com.WebPagesLogged;

import org.testng.annotations.AfterSuite;

public class BrowserStop {
	@AfterSuite
	public static void closeBrowser() {
		DriverClass.getdriver().close();
	}
}
