package src.com.WebPagesLogged;

import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.Keys;
import org.testng.annotations.BeforeSuite;

import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class BrowserStart {

	@BeforeSuite
	public static void openBrowser() throws Exception {

		DOMConfigurator.configure("log4j.xml");

		System.out.println("Browser is Starting");
		Log.info("Browser is Starting");
		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "BrowserStart");
		
		
		try {
			
			String BrowserType=ExcelUtils.getCellData(Constant.browserrow0, Constant.InputData).trim();
			DriverClass.setBrowserType(BrowserType);
			if (DriverClass.getBrowserType().contains("Chrome") || DriverClass.getBrowserType().contains("chrome")) {
				DriverClass.getdriver().manage().deleteAllCookies();
			}
			System.out.println("Cookies deleted");
			Log.info("Cookies deleted");

			if (DriverClass.getBrowserType().contains("Chrome") || DriverClass.getBrowserType().contains("chrome")) {
				DriverClass.getdriver().manage().window().maximize();
			}
			ExcelUtils.setCellData("Passed", Constant.browserrow, Constant.Result);
			System.out.println("Browser Window is Maximized");
			Log.info("Browser Window is Maximized");

		} catch (Exception e) {
			e.printStackTrace();
			ExcelUtils.setCellData("Failed", Constant.browserrow, Constant.Result);
			Log.error("Browser Window is Maximize is Failed" + "\n" + e);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.BrowserFailedSnapShot);

		}

		try {
			if (DriverClass.getBrowserType().contains("Chrome") || DriverClass.getBrowserType().contains("chrome")) {
				Runtime.getRuntime().exec(Constant.BrowserAuth);
			} else if (DriverClass.getBrowserType().contains("Firefox")
					|| DriverClass.getBrowserType().contains("firefox")) {

				Thread.sleep(1000);
				DriverClass.getdriver().switchTo().alert().sendKeys("smsapp" + Keys.TAB + "let$c0nnect");
				Thread.sleep(2000);
				DriverClass.getdriver().switchTo().alert().accept();

			}

			ExcelUtils.setCellData("Passed", Constant.browserrow1, Constant.Result);
			System.out.println("Browser Authentication is performed");
			Log.info("Browser Authentication is Done");
		} catch (Exception e) {
			e.printStackTrace();
			ExcelUtils.setCellData("Failed", Constant.browserrow1, Constant.Result);
			Log.error("Browser Window is authentication is not done" + "\n" + e);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.BrowserFailedSnapShot);

		}

		try {
			DriverClass.getdriver().get(Constant.BaseUrl);
			ExcelUtils.setCellData("Passed", Constant.browserrow2, Constant.Result);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			// System.out.println(DriverClass.getdriver().getTitle());
			// System.out.println(DriverClass.getdriver().getTitle() == "Best Invesment
			// Options | Wealth Creation | Tax Saving & Regular Income Plans � Birla Sun
			// Life Mutual Fund");
			System.out.println("Base URL is launched in browser");
			Log.info("Base URL is launched in browser");
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.BrowserSuccessSnapShot);
		} catch (Exception e) {
			e.printStackTrace();
			ExcelUtils.setCellData("Failed", Constant.browserrow2, Constant.Result);
			Log.error("Base URL is launched in browser");
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.BrowserFailedSnapShot);
		}

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}