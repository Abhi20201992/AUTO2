package src.com.WebPagesLogged;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import src.com.ExcelInputOutput.Constant;

public class DriverClass {
	private static WebDriver driver;
	public static String browserType;

	
	public static WebDriver getdriver() {
		if (driver == null) {
			if (DriverClass.getBrowserType().contains("Chrome") || DriverClass.getBrowserType().contains("chrome")) {
				DesiredCapabilities capabilities = DesiredCapabilities.chrome();
				capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
				System.setProperty("webdriver.chrome.driver", Constant.ChromeDriverPath);
				driver = new ChromeDriver();
				return driver;
			} else if (DriverClass.getBrowserType().contains("Firefox") || DriverClass.getBrowserType().contains("firefox")) {
				System.setProperty("webdriver.gecko.driver", "E:\\Soft\\Drivers\\Driver2.34\\geckodriver.exe");
				driver = new FirefoxDriver();
				return driver;
			}

		} else {
			return driver;
		}
		return driver;

	}

	public static void setDriver(WebDriver driver) {
		DriverClass.driver = driver;
	}

	
	
	public static String getBrowserType() {
		return browserType;

	}	
	
	
	public static void setBrowserType(String browserType) {
		DriverClass.browserType=browserType;
	}	
	
}