package src.com.WebPagesLogged;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class STP {

	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "STP");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "STP is Clicked ")
	public void STP_TC01() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_e8e6e5b9_f91b_4286_9438_afe832ba38c2_ctl00_InvDashboardScheme_lbnSTP")));
			el1.click();
			Log.info("STP is Clicked ");
			System.out.println("STP is Clicked ");
			ExcelUtils.setCellData("Passed", Constant.STP1, Constant.Result);
			System.out.println(DriverClass.getdriver().getTitle());
			//AssertJUnit.assertEquals("Pages - STP", DriverClass.getdriver().getTitle(), " Incorrect Page Opened");

		} catch (Exception e) {
			Log.error("STP is not Clicked " + "\n" + e);
			System.out.println("STP is not Clicked ");
			ExcelUtils.setCellData("Failed", Constant.STP1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Advisor is selected")
	public void STP_TC02() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlAdvDetailAdvisorName")));
			Select advisor = new Select(el1);
			advisor.selectByVisibleText(ExcelUtils.getCellData(Constant.STP2, Constant.InputData).trim());
			Log.info("Advisor is selected");// ARN-4968 / RAMESH CHAND MALOO
			System.out.println("Advisor is selected ");
			ExcelUtils.setCellData("Passed", Constant.STP2, Constant.Result);
			//AssertJUnit.assertEquals(ExcelUtils.getCellData(Constant.STP2, Constant.InputData).trim(),
				//	advisor.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.error("Advisor is not selected " + "\n" + e);
			System.out.println("Advisor is not selected");
			ExcelUtils.setCellData("Failed", Constant.STP2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "EUIN is entered")
	public void STP_TC03() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_txtEUIN")));
			el1.sendKeys(ExcelUtils.getCellData(Constant.STP3, Constant.InputData).trim());

			Log.info("EUIN is entered");
			System.out.println("EUIN is entered");
			ExcelUtils.setCellData("Passed", Constant.STP3, Constant.Result);
			//String text = el1.getAttribute("value");
			//AssertJUnit.assertEquals(ExcelUtils.getCellData(Constant.STP2, Constant.InputData).trim(), text);

		} catch (Exception e) {
			Log.error("EUIN is not entered" + "\n" + e);
			System.out.println("EUIN is not entered");
			ExcelUtils.setCellData("Failed", Constant.STP3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "Transfer From Scheme name is selected")
	public void STP_TC04() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailTransFromSchName")));
			Select schName = new Select(el1);
			
			
			String Index =ExcelUtils.getCellData(Constant.STP4, Constant.InputData2).trim();
		    int Index1=Integer.parseInt(Index);
			
			try {
				schName.selectByVisibleText(ExcelUtils.getCellData(Constant.STP4, Constant.InputData).trim());
			} catch (Exception e) {
				e.printStackTrace(); // Frontline Equity Fund -Dividend-Regular Plan
				schName.selectByIndex(Index1);
			}
			Log.info("Transfer From Scheme name is selected");
			System.out.println("Transfer From Scheme name is selected ");
			ExcelUtils.setCellData("Passed", Constant.STP4, Constant.Result);
			//AssertJUnit.assertEquals(schName.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.STP4, Constant.InputData).trim());

		} catch (Exception e) {

			Log.error("Transfer From Scheme name is not selected");
			System.out.println("Transfer From Scheme name  is not selected ");
			ExcelUtils.setCellData("Failed", Constant.STP4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);

			e.printStackTrace();
		}
	}

	@Test(description = "Transfer To Scheme Catagory is selected")
	public void STP_TC05() throws Exception {
		for(int i=0;i<3;i++) {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By
					.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailTransToSchCategory")));
			Select schName = new Select(el1);
			schName.selectByVisibleText(ExcelUtils.getCellData(Constant.STP5, Constant.InputData).trim());
			// DEBT
			Log.info("Transfer To Scheme Catagory is selected");
			System.out.println("Transfer To Scheme Catagory is selected ");
			ExcelUtils.setCellData("Passed", Constant.STP5, Constant.Result);
			//AssertJUnit.assertEquals(schName.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.STP5, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Transfer To Scheme Catagory is not selected");
			System.out.println("Transfer To Scheme Catagory is not selected ");
			ExcelUtils.setCellData("Failed", Constant.STP5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();
		}

	}
}
	@Test(description = "Scheme Sub Catagory is selected")
	public void STP_TC06() throws Exception {
		for(int i=0;i<3;i++) {
			try {

				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id(
						"ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailTransToSchSubCategory")));

				Select folioNumber = new Select(el1);
				folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.STP6, Constant.InputData).trim());

				// CORPORATE BOND
				Log.info("Scheme Sub Catagory is selected");
				System.out.println("Scheme Sub Catagory is selected");

				try {
					JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
					js.executeScript("window.scrollBy(0,50)");
					js.executeScript("window.scrollBy(0,50)");
				} catch (Exception e) {
					e.printStackTrace();
				}

				ExcelUtils.setCellData("Passed", Constant.STP6, Constant.Result);

				//assertEquals(folioNumber.getFirstSelectedOption().getText(),
					//	ExcelUtils.getCellData(Constant.STP6, Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("Scheme Sub Catagory is not selected" + "\n" + e);
				System.out.println("Scheme Sub Catagory is not selected");
				ExcelUtils.setCellData("Failed", Constant.STP6, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
				e.printStackTrace();
			}
		}
	}

	@Test(description = "Transfer To Scheme Name  is selected")
	public void STP_TC07() throws Exception {
		for(int i=0;i<3;i++) {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailTransToSchName")));
			Select schName = new Select(el1);
			schName.selectByVisibleText(ExcelUtils.getCellData(Constant.STP7, Constant.InputData).trim());
			// BANKING & PSU DEBT FUND - DIVIDEND - REGULAR PLAN
			Log.info("Transfer To Scheme Name  is selected");
			System.out.println("Transfer To Scheme Name is selected ");
			ExcelUtils.setCellData("Passed", Constant.STP7, Constant.Result);
			//AssertJUnit.assertEquals(schName.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.STP7, Constant.InputData).trim());

		} catch (Exception e) {

			Log.info("Transfer To Scheme Name is not selected");
			System.out.println("Transfer To Scheme Name  is not selected ");
			ExcelUtils.setCellData("Failed", Constant.STP7, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();

		}
	}
}
	@Test(description = "Scheme Option is selected ")
	public void STP_TC08() throws Exception {
		for(int i=0;i<3;i++) {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailTransToSchOption")));
			Select schName = new Select(el1);
			schName.selectByVisibleText(ExcelUtils.getCellData(Constant.STP8, Constant.InputData).trim());
			// Re-Investment
			Log.info("Scheme Option is selected ");
			System.out.println("Scheme Option is selected ");
			ExcelUtils.setCellData("Passed", Constant.STP8, Constant.Result);
			//AssertJUnit.assertEquals(schName.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.STP8, Constant.InputData).trim());

		} catch (Exception e) {
			Log.info("Scheme Option is not selected");
			System.out.println("Scheme Option is not selected ");
			ExcelUtils.setCellData("Failed", Constant.STP8, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();
		}
	}
}
	@Test(description = "Frequency is selected  Monthly")
	public void STP_TC09() throws Exception {
		for(int i=0;i<3;i++) {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailFrequency")));
			Select schName = new Select(el1);
			schName.selectByVisibleText(ExcelUtils.getCellData(Constant.STP9, Constant.InputData).trim());
			// Monthly
			Log.info("Frequency is selected  Monthly");
			System.out.println("Frequency is selected  Monthly ");
			ExcelUtils.setCellData("Passed", Constant.STP9, Constant.Result);
			//AssertJUnit.assertEquals(schName.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.STP9, Constant.InputData).trim());

		} catch (Exception e) {
			Log.info("Frequency is not selected  Monthly");
			System.out.println("Frequency is not selected  Monthly ");
			ExcelUtils.setCellData("Failed", Constant.STP9, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();

		}
	}
}
	@Test(description = "Amount is Entered")
	public void STP_TC10() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_txtTransDetailAmountPerTrans")));
		
			el1.clear();
			el1.sendKeys(ExcelUtils.getCellData(Constant.STP10, Constant.InputData).trim());
		
				

			Log.info("Amount is Entered");
			System.out.println("Amount is Entered");
			ExcelUtils.setCellData("Passed", Constant.STP10, Constant.Result);
			//String text = el1.getAttribute("value");
			//AssertJUnit.assertEquals(ExcelUtils.getCellData(Constant.STP10, Constant.InputData).trim(), text);

		} catch (Exception e) {
			Log.info("Amount is not  Entered");
			System.out.println("Amount is not Entered");
			ExcelUtils.setCellData("Failed", Constant.STP10, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();

		}
	}

	@Test(description = "From month Selected")
	public void STP_TC11() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailFromMonth")));
			Select fromMonth = new Select(el1);
			fromMonth.selectByVisibleText(ExcelUtils.getCellData(Constant.STP11, Constant.InputData).trim());
			// May
			Log.info("From month Selected");
			System.out.println("From month Selected ");
			ExcelUtils.setCellData("Passed", Constant.STP11, Constant.Result);
			//AssertJUnit.assertEquals(fromMonth.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.STP11, Constant.InputData).trim());

		} catch (Exception e) {
			Log.info("From month is not Selected");
			System.out.println("From month is not Selected");
			ExcelUtils.setCellData("Failed", Constant.STP11, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "From Year selected")
	public void STP_TC12() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailFromYear")));
			Select fromYear = new Select(el1);

			String Input = ExcelUtils.getCellData(Constant.STP12, Constant.InputData).trim();
			System.out.println(ExcelUtils.getCellData(Constant.STP12,Constant.InputData).trim());

			
			fromYear.selectByVisibleText(Input);
			
			// WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
			// By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailFromYear")));
			// Select folioNumber = new Select(el1);
			// folioNumber.selectByValue("2018");
			// System.out.println("From Year selected ");

			Log.info("From Year selected");
			System.out.println("From Year selected");
			ExcelUtils.setCellData("Passed", Constant.STP12, Constant.Result);
			//AssertJUnit.assertEquals(Input, fromYear.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.info("From Year is not selected");
			System.out.println("From Year is not selected");
			ExcelUtils.setCellData("Failed", Constant.STP12, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();

		}
	}

	@Test(description = "To month Selected")
	public void STP_TC13() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailToMonth")));
			Select toMonth = new Select(el1);
			toMonth.selectByVisibleText(ExcelUtils.getCellData(Constant.STP13, Constant.InputData).trim());
			// May
			Log.info("To month Selected");
			System.out.println("To month Selected ");
			ExcelUtils.setCellData("Passed", Constant.STP13, Constant.Result);
			//AssertJUnit.assertEquals(ExcelUtils.getCellData(Constant.STP13, Constant.InputData).trim(),
				//	toMonth.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.info("To month is not selected");
			System.out.println("To month is not selected");
			ExcelUtils.setCellData("Failed", Constant.STP13, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();

		}
	}

	@Test(description = "To Year selected")
	public void STP_TC14() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailToYear")));
			Select fromYear = new Select(el1);
			String Input = ExcelUtils.getCellData(Constant.STP14, Constant.InputData).trim();
			// System.out.println(ExcelUtils.getCellData(Constant.STP13,
			// Constant.InputData).trim());
			
			fromYear.selectByVisibleText(Input);
			// 2022
			Log.info("To Year selected");
			System.out.println("To Year selected ");
			ExcelUtils.setCellData("Passed", Constant.STP14, Constant.Result);
			//AssertJUnit.assertEquals(Input, fromYear.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.info("To Year is not selected");
			System.out.println("To Year is not selected");
			ExcelUtils.setCellData("Failed", Constant.STP14, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();

		}
	}

	@Test(description = "Date selected")
	public void STP_TC15() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_ddlTransDetailTransDate")));
			Select toDate = new Select(el1);

			String Input = ExcelUtils.getCellData(Constant.STP15, Constant.InputData).trim();
			// System.out.println("ExcelUtils.getCellData(Constant.STP14,
			// Constant.InputData).trim()");
			
			toDate.selectByVisibleText(Input);
			
			Log.info("Date selected ");
			System.out.println("Date selected ");
			ExcelUtils.setCellData("Passed", Constant.STP15, Constant.Result);
			//AssertJUnit.assertEquals(Input, toDate.getFirstSelectedOption().getText());
		} catch (Exception e) {
			Log.info("Date not selected");
			System.out.println("Date not selected");
			ExcelUtils.setCellData("Failed", Constant.STP15, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();

		}
	}

	@Test(description = "Checkbox is Clicked ")
	public void STP_TC16() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_chkTransDetailKeyInfo")));
			el1.click();
			Log.info("Checkbox is Clicked ");
			System.out.println("Checkbox is Clicked ");
			ExcelUtils.setCellData("Passed", Constant.STP16, Constant.Result);
			//AssertJUnit.assertTrue(el1.isEnabled());

		} catch (Exception e) {

			Log.info("Checkbox is not Clicked" + "\n" + e);
			System.out.println("Checkbox is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.STP16, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();

		}
	}

	@Test(description = "Next is Clicked ")
	public void STP_TC17() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_lbtnTransDetailNext")));
			el1.click();

			Log.info("Next is Clicked ");
			System.out.println("Next is clicked ");
			ExcelUtils.setCellData("Passed", Constant.STP17, Constant.Result);

			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			//System.out.println(DriverClass.getdriver().getTitle());
			//AssertJUnit.assertEquals("Pages - STP", DriverClass.getdriver().getTitle(), " Incorrect Page Opened");
		} catch (Exception e) {

			Log.info("Next is Clicked" + "\n" + e);
			System.out.println("Next is Clicked");
			ExcelUtils.setCellData("Failed", Constant.STP17, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();

		}
	}

	@Test(description = "Next is Clicked")
	public void STP_TC18() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_79f2bea6_fa59_4d5c_a7a4_419ecb59de5f_ctl00_STP1_lbtnConfirmDetailsConfirm")));
			el1.click();

			Log.info("Next is Clicked ");
			System.out.println("Next is clicked ");
			ExcelUtils.setCellData("Passed", Constant.STP18, Constant.Result);
			
			

			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			//AssertJUnit.assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.info("Next is Clicked" + "\n" + e);
			System.out.println("Next is Clicked");
			ExcelUtils.setCellData("Failed", Constant.STP18, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();

		}

	}

	@Test(description = "Screen Shot is Taken and saved")
	public void STP_TC19() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.STP19, Constant.Result);
			Log.info("STP is Successfully Completed,Thank you");
			System.out.println("STP is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.STP19, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.STPFailedSnapShot);
			e.printStackTrace();

		}

	}

	@Test(description = "SetDriver")
	public void setDriver() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
