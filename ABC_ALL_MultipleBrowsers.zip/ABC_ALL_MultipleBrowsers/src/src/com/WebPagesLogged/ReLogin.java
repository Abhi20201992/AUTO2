package src.com.WebPagesLogged;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class ReLogin {

	// public static void loginAbcOperation() throws Exception {
	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");
		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "ReLogin");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(1000);
	}

	@Test(description = "Extra Tab is closed")
	public void reLogin_TC01() throws Exception {
		try {

			Thread.sleep(2000);

			ArrayList<String> tabs2 = new ArrayList<String>(DriverClass.getdriver().getWindowHandles());
			DriverClass.getdriver().switchTo().window(tabs2.get(1));
			DriverClass.getdriver().close();
			DriverClass.getdriver().switchTo().window(tabs2.get(0));
			Log.info("Extra Tab is Closed");
			System.out.println("Extra Tab is Closed");
			ExcelUtils.setCellData("Passed", Constant.Relogin1, Constant.Result);
		} catch (Exception e) {
			Log.error("Extra Tab is not Closed" + "\n" + e);
			System.out.println("Extra Tab is not Closed");
			ExcelUtils.setCellData("Failed", Constant.Relogin1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.ReLoginFailedSnapShot);
			e.printStackTrace();
		}
	}
	/*----*/

	@Test(description = "Close rating tab")
	public void reLogin_TC02() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("survey-close-div")));
			el1.click();

			WebElement el2 = wait
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("html/body/div[1]/div")));
			el2.click();
			
			WebElement el3 = wait
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='survey-close-div']/i")));
			el3.click();
			
			
			WebElement el4 = wait
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div/div[1]/i")));
			el4.click();
			

			Log.info("Rating Tab is Closed");
			System.out.println("Rating Tab is Closed ");
			ExcelUtils.setCellData("Passed", Constant.Relogin2, Constant.Result);

		} catch (Exception e) {
			Log.error("Username is not entered" + "\n" + e);
			System.out.println("Username is not Entered ");
			ExcelUtils.setCellData("Failed", Constant.Relogin2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);

			e.printStackTrace();
		}

	}

	@Test(description = "Username is Entered")
	public void relogin_TC03() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("UserId")));
			el1.clear();
			el1.sendKeys(ExcelUtils.getCellData(Constant.Relogin3, Constant.InputData).trim());
			Log.info("Username is entered");
			System.out.println("Username is Entered ");
			ExcelUtils.setCellData("Passed", Constant.Relogin3, Constant.Result);
			String text = el1.getAttribute("value");
			AssertJUnit.assertEquals(text,ExcelUtils.getCellData(Constant.Relogin3, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Username is not entered" + "\n" + e);
			System.out.println("Username is not Entered ");
			ExcelUtils.setCellData("Failed", Constant.Relogin3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.ReLoginFailedSnapShot);
			e.printStackTrace();
		}
	}
	/*---*/

	@Test(description = "Password is entered")
	public void relogin_TC04() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("Password")));
			el1.clear();
			el1.sendKeys(ExcelUtils.getCellData(Constant.Relogin4, Constant.InputData).trim());
			Log.info("Password is entered");
			System.out.println("Password is Entered");
			ExcelUtils.setCellData("Passed", Constant.Relogin4, Constant.Result);
			String text = el1.getAttribute("value");
			AssertJUnit.assertEquals(text, "pass@123");

		} catch (Exception e) {
			Log.error("Password is not entered" + "\n" + e);
			System.out.println("Password is not Entered");
			ExcelUtils.setCellData("Failed", Constant.Relogin4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.ReLoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Submit Button is Clicked")
	public void relogin_TC05() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submit")));
			el1.click();
			Log.info("Submit Button is Clicked");
			System.out.println("Submit Button is Clicked");
			ExcelUtils.setCellData("Passed", Constant.Relogin5, Constant.Result);
		} catch (Exception e) {
			Log.error("Submit Button is not Clicked" + "\n" + e);
			System.out.println("Submit Button is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Relogin5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.ReLoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Relogin Successfull")
	public void relogin_TC06() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.ReLoginSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			Log.info("Relogin Successfull");
			System.out.println("Relogin Successfull ");
			ExcelUtils.setCellData("Passed", Constant.Relogin6, Constant.Result);

		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.Relogin6, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.ReLoginFailedSnapShot);
			e.printStackTrace();

		}

	}

	@Test(description = "Clicked Mutual Funds")
	public void relogin_TC07() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.ReLoginSuccessClickMFSnapShot);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"mfheading\"]/a/h4")));
			el1.click();
			Log.info("Clicked Mutual Funds");
			System.out.println("Clicked Mutual Funds ");
			ExcelUtils.setCellData("Passed", Constant.Relogin7, Constant.Result);

		} catch (Exception e) {
			Log.error("Clicked Mutual Funds Failed" + "\n" + e);
			System.out.println("Clicked Mutual Funds Failed ");
			ExcelUtils.setCellData("Failed", Constant.Relogin7, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.ReLoginFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "SetDriver")
	public void setDriver() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
