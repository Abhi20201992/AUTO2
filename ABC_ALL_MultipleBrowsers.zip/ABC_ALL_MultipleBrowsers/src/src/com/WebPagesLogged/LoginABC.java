package src.com.WebPagesLogged;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class LoginABC {

	// public static void loginAbcOperation() throws Exception {
	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");
		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Login Page");
		
	
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(1000);
	}

	@Test(description = "Login is Clicked", invocationCount = 2, successPercentage = 100)
	public void LoginABC_TC01() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait
					.until(ExpectedConditions.presenceOfElementLocated(By.id("ctl00_liTopNavigation_LoginId")));
			el1.click();

			System.out.println("Login is Clicked");
			Log.info("Login is Clicked");
			ExcelUtils.setCellData("Passed", Constant.LoginABCrow, Constant.Result);
		} catch (Exception e) {

			Log.error("Login Click is not Working" + "\n" + e);
			ExcelUtils.setCellData("Failed", Constant.LoginABCrow, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}
	/*----*/

	@Test(description = "Username is Entered")
	public void LoginABC_TC02() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_ab26497d_e15c_4de5_bd3e_1c795586e234_ctl00_txtUsername")));
			el1.clear();
			el1.sendKeys(ExcelUtils.getCellData(Constant.LoginABCrow1,Constant.InputData).trim());
			Log.info("Username is entered");
			System.out.println("Username is Entered ");
			ExcelUtils.setCellData("Passed", Constant.LoginABCrow1, Constant.Result);
			//String text = el1.getAttribute("value");
			//assertEquals(text, "test909");

		} catch (Exception e) {
			Log.error("Username is not entered" + "\n" + e);
			System.out.println("Username is not Entered ");
			ExcelUtils.setCellData("Failed", Constant.LoginABCrow1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}
	/*---*/

	@Test(description = "Password is entered")
	public void LoginABC_TC03() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_ab26497d_e15c_4de5_bd3e_1c795586e234_ctl00_txtPassword")));
			el1.clear();
			el1.sendKeys(ExcelUtils.getCellData(Constant.LoginABCrow2,Constant.InputData).trim());
			Log.info("Password is entered");
			System.out.println("Password is Entered");
			ExcelUtils.setCellData("Passed", Constant.LoginABCrow2, Constant.Result);
			String text = el1.getAttribute("value");
			assertEquals(text, "pass@123");

		} catch (Exception e) {
			Log.error("Password is not entered" + "\n" + e);
			System.out.println("Password is not Entered");
			ExcelUtils.setCellData("Failed", Constant.LoginABCrow2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Login Button is Clicked")
	public void LoginABC_TC04() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_ab26497d_e15c_4de5_bd3e_1c795586e234_ctl00_btnLogin")));
			el1.click();
			Log.info("Login Button is Clicked");
			System.out.println("Login Button is Clicked");
			ExcelUtils.setCellData("Passed", Constant.LoginABCrow3, Constant.Result);
	
		    try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
		    Thread.sleep(5000);
		
		} catch (Exception e) {
			Log.error("Login Button is not Clicked" + "\n" + e);
			System.out.println("Login Button is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.LoginABCrow3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Extra Tab is Closed")
	public void LoginABC_TC05() throws Exception {
		try {
			Thread.sleep(7000);
			
			ArrayList<String> tabs2 = new ArrayList<String>(DriverClass.getdriver().getWindowHandles());
			DriverClass.getdriver().switchTo().window(tabs2.get(1));
			DriverClass.getdriver().close();
			DriverClass.getdriver().switchTo().window(tabs2.get(0));
			Log.info("Extra Tab is Closed");
			System.out.println("Extra Tab is Closed");
			ExcelUtils.setCellData("Passed", Constant.LoginABCrow4, Constant.Result);
		} catch (Exception e) {
			Log.error("Extra Tab is not Closed" + "\n" + e);
			System.out.println("Extra Tab is not Closed");
			ExcelUtils.setCellData("Failed", Constant.LoginABCrow4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Site User Authenticatio is Done" ,invocationCount = 3, successPercentage = 100)
	public void LoginABC_TC06() throws Exception {
		try {
			
			if (DriverClass.getBrowserType() == "Chrome" || DriverClass.getBrowserType() == "chrome") {
				// Runtime.getRuntime().exec(Constant.SiteUserAuth);
				Thread.sleep(1000);
				DriverClass.getdriver().switchTo().alert().sendKeys("SiteUser" + Keys.TAB + "5$@43*MG5!4xq~VmQ");
				Thread.sleep(1000);
				DriverClass.getdriver().switchTo().alert().accept();

			} else if (DriverClass.getBrowserType() == "Firefox" || DriverClass.getBrowserType() == "firefox") {
				Thread.sleep(1000);
				DriverClass.getdriver().switchTo().alert().sendKeys("SiteUser" + Keys.TAB + "5$@43*MG5!4xq~VmQ");
				Thread.sleep(1000);
				DriverClass.getdriver().switchTo().alert().accept();
			}
			
			
			System.out.println("SiteUser Authentication is done");
			ExcelUtils.setCellData("Passed", Constant.LoginABCrow5, Constant.Result);
			Log.info("Site User Authenticatio is Done");
			ExcelUtils.setCellData("Passed", Constant.LoginABCrow5, Constant.Result);
			Thread.sleep(15000);
			
			
		} catch (Exception e) {
			Log.error("Site User Authenticatio is not Done" + "\n" + e);
			System.out.println("Site User Authenticatio is not Done");
			ExcelUtils.setCellData("Failed", Constant.LoginABCrow5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Clicked Mutual Funds")
	public void LoginABC_TC07() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginSuccessSnapShot);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);

			try {
				WebElement el1 = wait
						.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"mfheading\"]/a/h4")));
				el1.click();
			} catch (Exception e) {
				WebElement el1 = wait
						.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='mfheading']/a/h4")));
				el1.click();
			}

			Log.info("Clicked Mutual Funds");
			System.out.println("Clicked Mutual Funds ");
			ExcelUtils.setCellData("Passed", Constant.LoginABCrow6, Constant.Result);

		} catch (Exception e) {
			Log.error("Clicked Mutual Funds Failed" + "\n" + e);
			System.out.println("Clicked Mutual Funds Failed ");
			ExcelUtils.setCellData("Failed", Constant.LoginABCrow6, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginFailedSnapShot);
			e.printStackTrace();
		}

	}
	
	@Test(description = "SetDriver")
	public void setDriver() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
