package src.com.WebPagesLogged;

import static org.testng.Assert.assertEquals;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class Goals {
	
	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Goals");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "Goals is clicked")
	public void Goals_TC01() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_e8e6e5b9_f91b_4286_9438_afe832ba38c2_ctl00_InvDashboardScheme_lbtnGoal")));
			//while (!el1.isEnabled())
				el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

			Log.info("Goals Tab is clicked");
			System.out.println("Goals Tab is clicked");
			el1.click();
			ExcelUtils.setCellData("Passed", Constant.Goals1, Constant.Result);
			assertEquals("", DriverClass.getdriver().getTitle(), " Incorrect Page Opened");

		} catch (Exception e) {
			Log.error("Goals Tab is not clicked" + "\n" + e);
			System.out.println("Goald Tab is not clicked");
			ExcelUtils.setCellData("Failed", Constant.Goals1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.GoalsFailedSnapShot);
			e.printStackTrace();
		}

	}
	
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

