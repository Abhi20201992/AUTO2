package src.com.WebPagesLogged;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class Redeem {

	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Redeem");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "Redeem is clicked")
	public void redeem_TC01() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_e8e6e5b9_f91b_4286_9438_afe832ba38c2_ctl00_InvDashboardScheme_lbnRedeem")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Redeem is clicked");
			System.out.println("Redeem is clicked");
			//el1.click();
			ExcelUtils.setCellData("Passed", Constant.redeem1, Constant.Result);

			//AssertJUnit.assertEquals("Pages - Redeem", DriverClass.getdriver().getTitle(), " Incorrect Page Opened");

		} catch (Exception e) {
			Log.error("Redeem is not clicked" + "\n" + e);
			System.out.println("Redeem is not clicked");
			ExcelUtils.setCellData("Failed", Constant.redeem1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RedeemFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Scheme is selected")
	public void redeem_TC02() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_7508598a_d362_4fcb_a3b7_fa15669740ef_ctl00_ddlSchemes")));

			Thread.sleep(1500);
			Select SchemeCat = new Select(DriverClass.getdriver()
					.findElement(By.id("ctl00_m_g_7508598a_d362_4fcb_a3b7_fa15669740ef_ctl00_ddlSchemes")));
			SchemeCat.selectByVisibleText(ExcelUtils.getCellData(Constant.redeem2, Constant.InputData).trim());
			// Frontline Equity Fund -Dividend-Regular Plan

			Thread.sleep(1500);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(Constant.redeem2, TimeUnit.SECONDS);
			Log.info("Scheme is selected");

			System.out.println("Scheme is selected");
			ExcelUtils.setCellData("Passed", Constant.redeem2, Constant.Result);

			//AssertJUnit.assertEquals(SchemeCat.getFirstSelectedOption().getText(),
			//		ExcelUtils.getCellData(Constant.redeem2, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Scheme is not selected" + "\n" + e);
			System.out.println("Scheme is not selected");
			ExcelUtils.setCellData("Failed", Constant.redeem2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RedeemFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "No is Clicked")
	public void redeem_TC03() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_7508598a_d362_4fcb_a3b7_fa15669740ef_ctl00_rdSchDetailsNo")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("No is Clicked");
			System.out.println("No is Clicked");
			ExcelUtils.setCellData("Passed", Constant.redeem3, Constant.Result);

			//AssertJUnit.assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("No is not Clicked" + "\n" + e);
			System.out.println("No is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.redeem3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RedeemFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Units is Clicked")
	public void redeem_TC04() throws Exception {
		try {
			try {
				Thread.sleep(5000);
			} catch (Exception ex) {
				System.out.println(ex.getMessage());
			}
			WebElement element = DriverClass.getdriver().findElement(By.id("ctl00_m_g_7508598a_d362_4fcb_a3b7_fa15669740ef_ctl00_rdschDetailsUnit"));
			JavascriptExecutor executor = (JavascriptExecutor) DriverClass.getdriver();
			executor.executeScript("arguments[0].click();", element);

			Log.error("Units is Clicked" + "\n" );
			System.out.println("Units is Clicked");
			ExcelUtils.setCellData("Passed", Constant.redeem4, Constant.Result);

		} catch (Exception e) {
			Log.error("Units is not Clicked" + "\n" + e);
			System.out.println("Units is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.redeem4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RedeemFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Units/Amount is Entered")
	public void redeem_TC05() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_7508598a_d362_4fcb_a3b7_fa15669740ef_ctl00_txtSchDetailsUnit")));

			el1.clear();
			Thread.sleep(1000);
			el1.sendKeys(ExcelUtils.getCellData(Constant.redeem5, Constant.InputData).trim());
			Thread.sleep(1000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			Log.info("Units/Amount is Entered");
			System.out.println("Transaction number is Entered");
			ExcelUtils.setCellData("Passed", Constant.redeem5, Constant.Result);

			//String text = el1.getAttribute("value");
			//AssertJUnit.assertEquals(text, "10000");

		} catch (Exception e) {
			Log.error("Transaction number is not selected" + "\n" + e);
			System.out.println("Transaction number is not selected");
			ExcelUtils.setCellData("Failed", Constant.redeem5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RedeemFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Bank is Selected")
	public void redeem_TC06() throws Exception {
		for (int i = 0; i < 5; i++) {

			try {
				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
						By.id("ctl00_m_g_7508598a_d362_4fcb_a3b7_fa15669740ef_ctl00_ddlBanks")));
				Thread.sleep(1000);

				Select Name = new Select(el1);
				Name.selectByVisibleText(ExcelUtils.getCellData(Constant.redeem6, Constant.InputData).trim());
				// HDFC Bank Ltd - 00491050029232

				DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				Log.info("Bank is Selected");
				System.out.println("Bank is Selected");
				ExcelUtils.setCellData("Passed", Constant.redeem6, Constant.Result);
				//System.out.println(el1.isSelected());
				//AssertJUnit.assertEquals(Name.getFirstSelectedOption().getText(),
				//		ExcelUtils.getCellData(Constant.redeem6, Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("Bank is not Selected" + "\n" + e);
				System.out.println("Bank is not Selected");
				ExcelUtils.setCellData("Failed", 20, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RedeemFailedSnapShot);
				e.printStackTrace();
			}
		}
	}

	@Test(description = "Checkbox is clicked")
	public void redeem_TC07() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_7508598a_d362_4fcb_a3b7_fa15669740ef_ctl00_chkboxKeyInfo")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Checkbox is clicked");
			System.out.println("Checkbox is clicked");
			ExcelUtils.setCellData("Passed", Constant.redeem7, Constant.Result);
			//System.out.println(el1.isEnabled());
			//AssertJUnit.assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("Checkbox is not clicked" + "\n" + e);
			System.out.println("Checkbox is not clicked");
			ExcelUtils.setCellData("Failed", Constant.redeem7, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RedeemFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Next is Clicked")
	public void redeem_TC08() throws Exception {
		try {
			Thread.sleep(17000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_7508598a_d362_4fcb_a3b7_fa15669740ef_ctl00_lbtnSchDetailNext")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Next is Clicked");
			System.out.println("Next is Clicked");
			ExcelUtils.setCellData("Passed", Constant.redeem8, Constant.Result);
			
			
			
			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			//System.out.println(el1.isEnabled());
			//AssertJUnit.assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("Next is not Clicked" + "\n" + e);
			System.out.println("Next is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.redeem8, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RedeemFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Pop up is Handled")
	public void redeem_TC09() throws Exception {

		try {
			Thread.sleep(1500);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_7508598a_d362_4fcb_a3b7_fa15669740ef_ctl00_divduplicate")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			WebElement el2 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_7508598a_d362_4fcb_a3b7_fa15669740ef_ctl00_btnYespop")));
			el2.click();

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Pop is Handled");
			System.out.println("Pop is Handled");
			ExcelUtils.setCellData("Passed", Constant.redeem9, Constant.Result);
			//System.out.println(el1.isEnabled());
			//AssertJUnit.assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("Pop is not Handled" + "\n" + e);
			System.out.println("Pop is not Handled");
			ExcelUtils.setCellData("Failed", Constant.redeem9, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RedeemFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description="Next is Clicked")
	public void redeem_TC10() throws Exception {

		try {
			Thread.sleep(1500);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ctl00_m_g_7508598a_d362_4fcb_a3b7_fa15669740ef_ctl00_lbtnConfirmDetails")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("\n Next is Clicked");
			System.out.println("\n Next is Clicked");
			ExcelUtils.setCellData("Passed", Constant.redeem10, Constant.Result);
			//System.out.println(el1.isEnabled());
			//AssertJUnit.assertTrue(el1.isEnabled());
			

			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			
			
			JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
			js.executeScript("window.scrollBy(0,-500)");


		} catch (Exception e) {
			Log.error("\n Next is not Clicked" + "\n" + e);
			System.out.println("\n Next is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.redeem10, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(),  Constant.RedeemFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Screen Shot is Taken and saved")
	public void redeem_TC11() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RedeemSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.redeem11, Constant.Result);
			Log.info("Redeem is Successfully Completed,Thank you");
			System.out.println("Redeem is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.redeem11, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RedeemFailedSnapShot);
			e.printStackTrace();

		}

	}

	@Test(description = "SetDriver")
	public void redeem_TC12() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}