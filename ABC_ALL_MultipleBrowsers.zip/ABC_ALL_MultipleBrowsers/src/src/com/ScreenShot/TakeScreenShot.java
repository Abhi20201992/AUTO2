package src.com.ScreenShot;

import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import log4j.Log;

public class TakeScreenShot {

	public static void takeScreenShot(WebDriver webdriver, String fileWithPath) throws Exception {

		try {
			// Convert web driver object to TakeScreenshot
			TakesScreenshot scrShot = ((TakesScreenshot) webdriver);
			// Call getScreenshotAs method to create image file
			File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
			// Move image file to new destination
			File DestFile = new File(fileWithPath);
			// Copy file at destination
			FileUtils.copyFile(SrcFile, DestFile);

	
			Log.info("SnapShot File with Location "+SrcFile+ "is created and Saved with Name and Location as "+DestFile);
			System.out.println("SnapShot File with Location "+SrcFile+ "is created and Saved with Name and Location as "+DestFile);
	
			
			Log.info("\n Screen Shot taking is Success" + "\n");
			System.out.println("\n Screen Shot taking is Success");
	
		} catch (Exception e) {
			Log.info("\n Screen Shot taking is Failed" + "\n" + e);
			System.out.println("\n Screen Shot taking is Failed ");
		}
	}

}
