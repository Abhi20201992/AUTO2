package src.com.ExcelInputOutput;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import log4j.Log;


public class ExcelUtils {
	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFCell Cell;
	private static XSSFRow Row;

	// This method is to set the File path and to open the Excel file, Pass Excel
	// Path and Sheetname as Arguments to this method
	public static void setExcelFile(String Path, String SheetName) throws Exception {
		try {
			// Open the Excel file
			FileInputStream ExcelFile = new FileInputStream(Path);
			// Access the required test data sheet
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			
			
			ExcelWSheet = ExcelWBook.getSheet(SheetName);

			Log.info("Xl Sheet is getting Used here  :"+SheetName);
			System.out.println("Xl Sheet is getting Used here  :"+SheetName);
			
		} catch (Exception e) {
			e.printStackTrace();			
			Log.info("some error occured while setting Excel File :"+e);
			System.out.println("some error occured while setting Excel File :");
			
		}
	}

	// This method is to read the test data from the Excel cell, in this we are
	// passing parameters as Row num and Col num
	public static String getCellData(int RowNum, int ColNum) throws Exception {
		try {
			Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
			
			String CellData;

			
			
			if (Cell.getCellTypeEnum() == CellType.NUMERIC) {
				CellData = NumberToTextConverter.toText(Cell.getNumericCellValue());
			} else {
				CellData = Cell.getStringCellValue();
			}
			
			/*
			if(DateUtil.isCellDateFormatted(Cell)) {
				CellData=Cell.getDateCellValue();
			}*/
			
			
			
			Log.info("String received from Excel is :"+CellData);
			System.out.println("String received from Excel is :"+CellData);
			
			return CellData;
		} catch (Exception e) {
			e.printStackTrace();
			Log.info("String is not received from Excel :"+e);
			System.out.println("String is not received from Excel");
			return "";
			
		}
	}

	// This method is to write in the Excel cell, Row num and Col num are the
	// parameters
	public static void setCellData(String Result, int RowNum, int ColNum) throws Exception {
		try {
			Row = ExcelWSheet.getRow(RowNum);
			Cell = Row.getCell(ColNum,MissingCellPolicy.CREATE_NULL_AS_BLANK);
			
			
			if (Cell == null) {
				Cell = Row.createCell(ColNum);
				Cell.setCellValue(Result);
				
				
				
			} else {
				Cell.setCellValue(Result);
				
			}
			
			Log.info("String entered to Excel for row"+RowNum +"and column" + ColNum +"is:" +Result);
			System.out.println("String entered to Excel for row"+RowNum +"and column" + ColNum +"is:" +Result);
			
			// Constant variables Test Data path and Test Data file name
			FileOutputStream fileOut = new FileOutputStream(Constant.Path_TestData + Constant.File_TestData);
			ZipSecureFile.setMinInflateRatio(-1.0d);
			ExcelWBook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (Exception e) {
			e.printStackTrace();
			Log.info("String  not entered to Excel for row"+RowNum +"and column" + ColNum +"is:" +Result);
			System.out.println("String  not entered to Excel for row"+RowNum +"and column" + ColNum +"is:" +Result);
				
		}
	}

}