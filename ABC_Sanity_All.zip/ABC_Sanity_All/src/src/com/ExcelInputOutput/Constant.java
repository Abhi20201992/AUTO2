package src.com.ExcelInputOutput;

public class Constant {

	public static final String Path_TestData = "E:\\Soft\\Eclip_New\\eclipse-workspace\\ABC_Sanity_All\\ExcelFile\\";
	public static final String File_TestData = "ABC_UI.xlsx";

	public static final String ChromeDriverPath = "E:\\Soft\\Drivers\\Driver2.34\\chromedriver.exe";
	public static String FireFoxDriver="E:\\Soft\\Drivers\\geckodriver.exe";
	public static final String BaseUrl = "https://mfcomb.birlasunlife.com/";
	
	public static final String BrowserAuth = "D:\\smsappAuth64.exe";
	public static String SiteUserAuth = "D:\\SiteUserAuth64.exe";
	public static final String DownloadPath="C:\\Users\\ssos000479\\Downloads\\";
	public static final int Result = 19;
	public static final int InputData = 11;
	public static final int InputData2=12;
	
	
	public static final int browserrow = 12;
	public static final int browserrow1 = 13;
	public static final int browserrow2 = 14;
	public static final int NonLoginPurchase1=12;
	public static final int NonLoginPurchase2=13;
	public static final int NonLoginPurchase3=14;
	public static final int NonLoginPurchase4=15;
	public static final int NonLoginPurchase5=16;
	public static final int NonLoginPurchase6=17;
	public static final int NonLoginPurchase7=18;
	public static final int NonLoginPurchase8=19;
	public static final int NonLoginPurchase9=20;
	public static final int NonLoginPurchase10=21;
	public static final int NonLoginPurchase11=22;
	public static final int NonLoginPurchase12=23;
	public static final int NonLoginPurchase13=24;
	public static final int NonLoginPurchase14=25;
	public static final int NonLoginPurchase15=26;
	public static final int NonLoginPurchase16=27;
	public static final int NonLoginPurchase17=28;
	public static final int NonLoginPurchase18=29;

	public static final int CapitalGainStatement1=12;
	public static final int CapitalGainStatement2=13;
	public static final int CapitalGainStatement3=14;
	public static final int CapitalGainStatement4=15;
	public static final int CapitalGainStatement5=16;
	public static final int Newfolio1=12;
	public static final int Newfolio2=13;
	public static final int Newfolio3=14;
	public static final int Newfolio4=15;
	public static final int Newfolio5=16;
	public static final int Newfolio6=17;
	public static final int Newfolio7=18;
	public static final int Newfolio8=19;
	public static final int Newfolio9=20;
	public static final int Newfolio10=21;
	public static final int Newfolio11=22;
	public static final int Newfolio12=23;
	public static final int Newfolio13=24;
	public static final int Newfolio14=25;
	public static final int Newfolio15=26;
	public static final int Newfolio16=27;
	public static final int Newfolio17=28;
	public static final int Newfolio18=29;
	public static final int Newfolio19=30;
	public static final int Newfolio20=31;
	public static final int Newfolio21=32;
	public static final int Newfolio22=33;
	public static final int Newfolio23=34;
	public static final int Newfolio24=35;
	public static final int Newfolio25=36;
	public static final int Newfolio26=37;
	public static final int Newfolio27=38;
	public static final int Newfolio28=39;
	public static final int Newfolio29=40;
	public static final int Newfolio30=41;
	public static final int Newfolio31=42;
	public static final int Newfolio32=43;
	public static final int Newfolio33=44;
	public static final int Newfolio34=45;
	public static final int Newfolio35=46;
	public static final int Newfolio36=47;
	
	
	public static final int browserrow3=0;
	public static final int browserrow4=0;
	public static final int browserrow5=0;
	public static final int NonLogin1=12;
	public static final int NonLogin2=13;
	public static final int NonLogin3=14;
	public static final int NonLogin4=15;
	public static final int NonLogin5=16;
	public static final int NonLogin6=17;
	public static final int NonLogin7=18;
	public static final int NonLogin8=19;
	public static final int NonLogin9=20;
	public static final int NonLogin10=21;
	public static final int NonLogin11=22;
	public static final int NonLogin12=23;
	public static final int NonLogin13=24;
	public static final int NonLogin14=25;
	
	public static final int switch1 = 12;
	public static final int switch2 = 13;
	public static final int switch3 = 14;
	public static final int switch4 = 15;
	public static final int switch5 = 16;
	public static final int switch6 = 17;
	public static final int switch7 = 18;
	public static final int switch8 = 19;
	public static final int switch9 = 20;
	public static final int switch10 = 21;
	public static final int switch11 = 22;
	public static final int switch13 = 24;
	public static final int switch14 = 25;
	public static final int switch15 = 26;
	public static final int switch16 = 27;
	public static final int switch17 = 28;
	public static final int switch12 = 23;
	public static final int switch18 = 29;
	public static final int switch19 = 30;
	public static final int switch20 = 31;
	
	public static final int loggedPurchase1 = 12;
	public static final int loggedPurchase2 = 13;
	public static final int loggedPurchase3 = 14;
	public static final int loggedPurchase4 = 15;
	public static final int loggedPurchase5 = 16;
	public static final int loggedPurchase6 = 17;
	public static final int loggedPurchase7 = 18;
	public static final int loggedPurchase8 = 19;
	public static final int loggedPurchase9 = 20;
	public static final int loggedPurchase10 = 21;
	public static final int loggedPurchase11 = 22;
	public static final int loggedPurchase12 = 23;
	public static final int loggedPurchase13 = 24;
	public static final int loggedPurchase14 = 25;
	public static final int loggedPurchase15 = 26;
	public static final int loggedPurchase16 = 27;

	public static final int loggedPurchase17 = 27;
	public static final int loggedPurchase18 = 28;

	
	public static final int LoginABCrow = 20;
	public static final int LoginABCrow1 = 21;
	public static final int LoginABCrow2 = 22;
	public static final int LoginABCrow3 = 23;
	public static final int LoginABCrow4 = 24;
	public static final int LoginABCrow5 = 25;
	public static final int LoginABCrow6 = 26;

	public static final int Dashboard1 = 12;
	public static final int Dashboard2 = 13;
	public static final int Dashboard3 = 14;

	public static final int STP1 = 12;
	public static final int STP2 = 13;
	public static final int STP3 = 14;
	public static final int STP4 = 15;
	public static final int STP5 = 16;
	public static final int STP6 = 17;
	public static final int STP7 = 18;
	public static final int STP8 = 19;
	public static final int STP9 = 20;
	public static final int STP10 = 21;
	public static final int STP11 = 22;
	public static final int STP12 = 23;
	public static final int STP13 = 24;
	public static final int STP14 = 25;
	public static final int STP15 = 26;
	public static final int STP16 = 27;
	public static final int STP17 = 28;
	public static final int STP18 = 29;
	public static final int STP19 = 29;
	
	
	public static final int swp1 = 12;
	public static final int swp2 = 13;
	public static final int swp3 = 14;
	public static final int swp4 = 15;
	public static final int swp5 = 16;
	public static final int swp6 = 17;
	public static final int swp7 = 18;
	public static final int swp8 = 19;
	public static final int swp9 = 20;
	public static final int swp10 = 21;
	public static final int swp11 = 22;
	public static final int swp12 = 23;
	public static final int swp13 = 24;
	public static final int swp14 = 25;
	public static final int swp15 = 26;
	public static final int swp16 = 27;
	public static final int swp17 = 28;

	public static final int downloadMySchemes1 = 12;
	public static final int downloadMySchemes2 = 13;
	
	public static final int redeem1 = 12;	
	public static final int redeem2 = 13;
	public static final int redeem3 = 14;	
	public static final int redeem4 = 15;
	public static final int redeem5 = 16;	
	public static final int redeem6 = 17;
	public static final int redeem7 = 18;	
	public static final int redeem8 = 19;
	public static final int redeem9 = 20;	
	public static final int redeem10 = 21;
	public static final int redeem11 = 22;	
	public static final int redeem12 = 23;
	public static final int redeem13 = 24;
	
	public static final int schemeChange1 = 1;

	public static final int logout1 = 12;
	public static final int logout2 = 13;
	
	public static final int requestStatement1 = 12;
	public static final int requestStatement2 = 13;
	public static final int requestStatement3 = 14;
	public static final int requestStatement4 = 15;
	public static final int requestStatement5 = 16;
	public static final int requestStatement6 = 17;
	public static final int requestStatement7 = 18;
	public static final int requestStatement8 = 19;
	public static final int requestStatement9 = 20;
	public static final int requestStatement10 =21;
	public static final int requestStatement11 =22;
	public static final int requestStatement12 =23;
	
		
	
	public static int Relogin1=12;
	public static int Relogin2=13;
	public static int Relogin3=14;
	public static int Relogin4=15;
	public static int Relogin5=16;
	public static int Relogin6=17;
	public static int Relogin7=18;
	
    public static int LoggediSIPNoFirstInstallmentisip1=12;
	public static int LoggediSIPNoFirstInstallmentisip2=13;
	public static int LoggediSIPNoFirstInstallmentisip3=14;
	public static int LoggediSIPNoFirstInstallmentisip4=15;
	public static int LoggediSIPNoFirstInstallmentisip5=16;
	public static int LoggediSIPNoFirstInstallmentisip6=17;
	public static int LoggediSIPNoFirstInstallmentisip7=18;
	public static int LoggediSIPNoFirstInstallmentisip8=19;
	public static int LoggediSIPNoFirstInstallmentisip9=20;
	public static int LoggediSIPNoFirstInstallmentisip10=21;
	public static int LoggediSIPNoFirstInstallmentisip11=22;
	public static int LoggediSIPNoFirstInstallmentisip12=23;
	public static int LoggediSIPNoFirstInstallmentisip13=24;
	public static int LoggediSIPNoFirstInstallmentisip14=25;
	public static int LoggediSIPNoFirstInstallmentisip15=25;
	public static int LoggediSIPNoFirstInstallmentisip16=26;
	public static int LoggediSIPNoFirstInstallmentisip17=27;
	public static int LoggediSIPNoFirstInstallmentisip18=28;
	public static int LoggediSIPNoFirstInstallmentisip19=29;
	public static int LoggediSIPNoFirstInstallmentisip20=30;
	public static int LoggediSIPNoFirstInstallmentisip21=31;

	public static int NonLoginISIP1=12;
	public static int NonLoginISIP2=13;
	public static int NonLoginISIP3=14;
	public static int NonLoginISIP4=15;
	public static int NonLoginISIP5=16;
	public static int NonLoginISIP6=17;
	public static int NonLoginISIP7=18;
	public static int NonLoginISIP8=19;
	public static int NonLoginISIP9=20;
	public static int NonLoginISIP10=21;
	public static int NonLoginISIP11=22;
	public static int NonLoginISIP12=23;
	public static int NonLoginISIP13=24;
	public static int NonLoginISIP14=25;
	public static int NonLoginISIP15=26;
	public static int NonLoginISIP16=27;
	public static int NonLoginISIP17=28;
	public static int NonLoginISIP18=29;
	public static int NonLoginISIP19=30;
	public static int NonLoginISIP20=31;
	public static int NonLoginISIP21=32;
	public static int NonLoginISIP22=33;
	public static int NonLoginISIP23=34;
	public static int NonLoginISIP24=35;
	public static int NonLoginISIP25=36;

	public static int NonLoginCSIP1=12;
	public static int NonLoginCSIP2=13;
	public static int NonLoginCSIP3=14;
	public static int NonLoginCSIP4=15;
	public static int NonLoginCSIP5=16;
	public static int NonLoginCSIP6=17;
	public static int NonLoginCSIP7=18;
	public static int NonLoginCSIP8=19;
	public static int NonLoginCSIP9=20;
	public static int NonLoginCSIP10=21;
	public static int NonLoginCSIP11=22;
	public static int NonLoginCSIP12=23;
	public static int NonLoginCSIP13=24;
	public static int NonLoginCSIP14=25;
	public static int NonLoginCSIP15=26;
	public static int NonLoginCSIP16=27;
	public static int NonLoginCSIP17=28;
	public static int NonLoginCSIP18=29;
	public static int NonLoginCSIP19=30;
	public static int NonLoginCSIP20=31;
	public static int NonLoginCSIP21=32;
	public static int NonLoginCSIP22=33;
	public static int NonLoginCSIP23=34;
	public static int NonLoginCSIP24=35;
	public static int NonLoginCSIP25=36;
	public static int NonLoginCSIP26=37;
	public static int NonLoginCSIP27=38;
	public static int NonLoginCSIP28=39;
	public static int NonLoginCSIP29=40;
	
	public static int NonLoginISIPNoFirstInstallment1=12;
	public static int NonLoginISIPNoFirstInstallment2=13;
	public static int NonLoginISIPNoFirstInstallment3=14;
	public static int NonLoginISIPNoFirstInstallment4=15;
	public static int NonLoginISIPNoFirstInstallment5=16;
	public static int NonLoginISIPNoFirstInstallment6=17;
	public static int NonLoginISIPNoFirstInstallment7=18;
	public static int NonLoginISIPNoFirstInstallment8=19;
	public static int NonLoginISIPNoFirstInstallment9=20;
	public static int NonLoginISIPNoFirstInstallment10=21;
	public static int NonLoginISIPNoFirstInstallment11=22;
	public static int NonLoginISIPNoFirstInstallment12=23;
	public static int NonLoginISIPNoFirstInstallment13=24;
	public static int NonLoginISIPNoFirstInstallment14=25;
	public static int NonLoginISIPNoFirstInstallment15=26;
	public static int NonLoginISIPNoFirstInstallment16=27;
	public static int NonLoginISIPNoFirstInstallment17=28;
	public static int NonLoginISIPNoFirstInstallment18=29;
	public static int NonLoginISIPNoFirstInstallment19=30;
	public static int NonLoginISIPNoFirstInstallment20=31;
	public static int NonLoginISIPNoFirstInstallment21=32;
	public static int NonLoginISIPNoFirstInstallment22=33;
	public static int NonLoginISIPNoFirstInstallment23=34;
	public static int NonLoginISIPNoFirstInstallment24=35;
	public static int NonLoginISIPNoFirstInstallment25=36;
	
	public static int LoggedISIP1=12;
	public static int LoggedISIP2=13;
	public static int LoggedISIP3=14;
	public static int LoggedISIP4=15;
	public static int LoggedISIP5=16;
	public static int LoggedISIP6=17;
	public static int LoggedISIP7=18;
	public static int LoggedISIP8=19;
	public static int LoggedISIP9=20;
	public static int LoggedISIP10=21;
	public static int LoggedISIP11=22;
	public static int LoggedISIP12=23;
	public static int LoggedISIP13=24;
	public static int LoggedISIP14=25;
	public static int LoggedISIP15=26;
	public static int LoggedISIP16=27;
	public static int LoggedISIP17=28;
	public static int LoggedISIP18=29;
	public static int LoggedISIP19=30;
	public static int LoggedISIP20=31;
	public static int LoggedISIP21=32;
	public static int LoggedISIP22=33;
	public static int LoggedISIP23=34;
	public static int LoggedISIP24=35;
	public static int LoggedISIP25=36;
	public static int LoggedISIP26=37;
	public static int LoggedISIP27=38;
	public static int LoggedISIP28=39;
	public static int LoggedISIP29=40;
	
	public static int LoggedISIPNoFirstInstallment1=12;
	public static int LoggedISIPNoFirstInstallment2=13;
	public static int LoggedISIPNoFirstInstallment3=14;
	public static int LoggedISIPNoFirstInstallment4=15;
	public static int LoggedISIPNoFirstInstallment5=16;
	public static int LoggedISIPNoFirstInstallment6=17;
	public static int LoggedISIPNoFirstInstallment7=18;
	public static int LoggedISIPNoFirstInstallment8=19;
	public static int LoggedISIPNoFirstInstallment9=20;
	public static int LoggedISIPNoFirstInstallment10=21;
	public static int LoggedISIPNoFirstInstallment11=22;
	public static int LoggedISIPNoFirstInstallment12=23;
	public static int LoggedISIPNoFirstInstallment13=24;
	public static int LoggedISIPNoFirstInstallment14=25;
	public static int LoggedISIPNoFirstInstallment15=26;
	public static int LoggedISIPNoFirstInstallment16=27;
	public static int LoggedISIPNoFirstInstallment17=28;
	public static int LoggedISIPNoFirstInstallment18=29;
	
	public static int LoginCSIP1=12;
	public static int LoginCSIP2=13;
	public static int LoginCSIP3=14;
	public static int LoginCSIP4=15;
	public static int LoginCSIP5=16;
	public static int LoginCSIP6=17;
	public static int LoginCSIP7=18;
	public static int LoginCSIP8=19;
	public static int LoginCSIP9=20;
	public static int LoginCSIP10=21;
	public static int LoginCSIP11=22;
	public static int LoginCSIP12=23;
	public static int LoginCSIP13=24;
	public static int LoginCSIP14=25;
	public static int LoginCSIP15=26;
	public static int LoginCSIP16=27;
	public static int LoginCSIP17=28;
	public static int LoginCSIP18=29;
	public static int LoginCSIP19=30;
	public static int LoginCSIP20=31;
	public static int LoginCSIP21=32;
	public static int LoginCSIP22=33;
	public static int LoginCSIP23=34;
	public static int LoginCSIP24=35;
	public static int LoginCSIP25=36;
	public static int LoginCSIP26=37;
	public static int LoginCSIP27=38;
	public static int LoginCSIP28=39;
	public static int LoginCSIP29=40;
	public static int LoginCSIP30=41;
	public static int LoginCSIP31=42;
	public static int LoginCSIP32=43;
	public static int LoginCSIP33=44;
	public static int LoginCSIP34=45;
	public static int LoginCSIP35=46;
	public static int LoginCSIP36=47;
	
	public static int LoggedStartASIP1=12;
	public static int LoggedStartASIP2=13;
	public static int LoggedStartASIP3=14;
	public static int LoggedStartASIP4=15;
	public static int LoggedStartASIP5=16;
	public static int LoggedStartASIP6=17;
	public static int LoggedStartASIP7=18;
	public static int LoggedStartASIP8=19;
	public static int LoggedStartASIP9=20;
	public static int LoggedStartASIP10=21;
	public static int LoggedStartASIP11=22;
	public static int LoggedStartASIP12=23;
	public static int LoggedStartASIP13=24;
	public static int LoggedStartASIP14=25;
	public static int LoggedStartASIP15=26;
	public static int LoggedStartASIP16=27;
	public static int LoggedStartASIP17=28;
	public static int LoggedStartASIP18=29;
	public static int LoggedStartASIP19=30;
	public static int LoggedStartASIP20=31;
	public static int LoggedStartASIP21=32;
	public static int LoggedStartASIP22=33;
	public static int LoggedStartASIP23=34;
	public static int LoggedStartASIP24=35;
	public static int LoggedStartASIP25=36;
	public static int LoggedStartASIP26=37;
	
	public static int Goals1=12;
	public static int Goals2=13;
	public static String MyProfileFailedSnapshot="E:\\UITestingSnapShot\\MyProfileFailedSnapshot.jpg";
	public static String MyProfileSuccessSnapshot="E:\\UITestingSnapShot\\MyProfileSuccessSnapshot.jpg";
	public static String ReLoginSuccessClickMFSnapShot="E:\\UITestingSnapShot\\ReLoginSuccessClickMFSnapShot.jpg";

	
	
	
	
	
	
	public static String PurchaseSmartLinkFailedSnapShot="E:\\UITestingSnapShot\\PurchaseSmartLinkFailedSnapShot.jpeg";
	
	
	
	
	
	public final static int TC01=12;
	public final static int TC02=13;
	public final static int TC03=14;
	public final static int TC04=15;
	public final static int TC05=16;
	public final static int TC06=17;
	public final static int TC07=18;
	public final static int TC08=19;
	public final static int TC09=20;
	public final static int TC010=21;
	public final static int TC011=22;
	public final static int TC012=23;
	public final static int TC013=24;
	public final static int TC014=25;
	public final static int TC015=26;
	public final static int TC016=27;
	public final static int TC017=28;
	public final static int TC018=29;
	public final static int TC019=30;
	public final static int TC020=31;
	public final static int TC021=32;
	public final static int TC022=33;
	public final static int TC023=34;
	
	
	public final static int MyProfile1=12;
	public final static int MyProfile2=13;
	public final static int MyProfile3=14;
	public final static int MyProfile4=15;
	public final static int MyProfile5=16;
	public final static int MyProfile6=17;
	public final static int MyProfile7=18;
	public final static int MyProfile8=19;




		
	public final static int csip1=12;
	public final static int csip2=13;
	public final static int csip3=14;
	public final static int csip4=15;
	public final static int csip5=16;
	public final static int csip6=17;
	public final static int csip7=18;
	public final static int csip8=19;
	public final static int csip9=20;
	public final static int csip10=21;
	public final static int csip11=22;
	public final static int csip12=23;
	public final static int csip13=24;
	public final static int csip14=25;
	public final static int csip15=26;
	public final static int csip16=27;
	public final static int csip17=28;
	public final static int csip18=29;
	public final static int csip19=30;
	public final static int csip20=31;
	public final static int csip21=32;
	public final static int csip22=33;
	public final static int csip23=34;
	public final static int csip24=35;
	public final static int csip25=36;
	public final static int csip26=37;
	public final static int csip27=38;
	
	public static final int exitLoadSummary1 = 12;
	public static final int exitLoadSummary2 = 13;
	public static final int exitLoadSummary3 = 14;
	public static final int exitLoadSummary4 = 15;
	public static final int exitLoadSummary5 = 16;
	public static final int exitLoadSummary6 = 17;

	
	public static final int InvestInNewScheme1 = 12;
	public static final int InvestInNewScheme2 = 13;
	public static final int InvestInNewScheme3 = 14;
	public static final int InvestInNewScheme4 = 15;
    public static final int InvestInNewScheme5 = 16;
	public static final int InvestInNewScheme6 = 17;
	public static final int InvestInNewScheme7 = 18;
	public static final int InvestInNewScheme8 = 19;
	public static final int InvestInNewScheme9 = 20;
	public static final int InvestInNewScheme10 =21;
	public static final int InvestInNewScheme11 =22;
	public static final int InvestInNewScheme12 =23;
	public static final int InvestInNewScheme13 =24;
	public static final int InvestInNewScheme14 =25;
	public static final int InvestInNewScheme15 =26;
	public static final int InvestInNewScheme16 =27;
	public static final int InvestInNewScheme17 =28;
	public static final int InvestInNewScheme18 =29;
	public static final int InvestInNewScheme19 =30;
	public static final int InvestInNewScheme20 =31;
	public static final int InvestInNewScheme21 =32;
	public static final int InvestInNewScheme22 =33;
	public static final int InvestInNewScheme23 =34;
	public static final int InvestInNewScheme24 =35;
	public static final int InvestInNewScheme25 =36;
	public static final int InvestInNewScheme26 =37;

	
	public static final String BrowserSuccessSnapShot = "E:\\UITestingSnapShot\\BrowserSuccessSnapshot.jpeg";
	public static final String CapitalGainStatementFailedSnapShot="E:\\UITestingSnapShot\\CapitalGainStatementFailedSnapShot.jpeg";
	public static final String CapitalGainStatementSuccessSnapShot="E:\\UITestingSnapShot\\CapitalGainStatementSuccessSnapShot.jpeg";
	public static final String NewfolioFailedSnapShot="E:\\UITestingSnapShot\\NewfolioFailedSnapShot.jpeg";
	public static final String NewfolioSuccessSnapShot="E:\\UITestingSnapShot\\NewfolioSuccessSnapShot.jpeg";
	public static final String NonLoginPurchaseFailedSnapShot="E:\\UITestingSnapShot\\NonLoginPurchaseSuccessSnapShot.jpeg";
	public static final String NonLoginPurchaseSuccessSnapShot="E:\\UITestingSnapShot\\NonLoginPurchaseFailedSnapShot.jpeg";
	public static final String DownloadMySchemesFailedSnapShot="E:\\UITestingSnapShot\\DownloadMySchemesFailedSnapShot.jpeg";
	public static final String DownloadMySchemesSuccessSnapShot="E:\\UITestingSnapShot\\DownloadMySchemesSuccessSnapShot.jpeg";
	public static final String NonLoginSuccessSnapShot="E:\\UITestingSnapShot\\NonLoginSuccessSnapShot.jpeg";
	public static final String NonLoginFailedSnapShot = "E:\\UITestingSnapShot\\NonLoginFailedSnapShot.jpeg";
	public static final String SwitchFailedSnapShot = "E:\\UITestingSnapShot\\SwitchFailedSnapshot.jpeg";
	public static final String SwitchSuccessSnapShot = "E:\\UITestingSnapShot\\SwitchSuccessSnapshot.jpeg";
	public static final String swpFailedSnapShot = "E:\\UITestingSnapShot\\SWPFailedSnapshot.jpeg";
	public static final String swpSuccessSnapShot = "E:\\UITestingSnapShot\\SwitchSuccessSnapshot.jpeg";
	public static final String LoginFailedSnapShot = "E:\\UITestingSnapShot\\LoginFailedSnapShot.jpeg";
	public static final String LoginSuccessSnapShot = "E:\\UITestingSnapShot\\LoginSuccessSnapShot.jpeg";
	public static final String LoginPurchaseFailedSnapShot = "E:\\UITestingSnapShot\\LoginPurchaseFailedSnapShot.jpeg";
	public static final String LoginPurchaseSuccessSnapShot = "E:\\UITestingSnapShot\\LoginPurchaseSuccessSnapShot.jpeg";
	public static final String FileTOUpload = "E:\\Soft\\Eclip_New\\NonLoggedPurchase\\File_Upload1_64.exe";
	public static final String BrowserFailedSnapShot = "E:\\UITestingSnapShot\\BrowserFailedSnapshot.jpeg";;
	public static final String NewfolioSuccessSnapShot1 = "E:\\UITestingSnapShot\\NewfolioSuccessSnapShot1.jpeg";
	public static final String NewfolioSuccessSnapShot2 = "E:\\UITestingSnapShot\\NewfolioSuccessSnapShot2.jpeg";
	public static final String NewfolioSuccessSnapShot3 = "E:\\UITestingSnapShot\\NewfolioSuccessSnapShot3.jpeg";
	public static final String NewfolioSuccessSnapShot4 = "E:\\UITestingSnapShot\\NewfolioSuccessSnapShot4.jpeg";
	public static final String loggedCSIPFailedSnapShot ="E:\\UITestingSnapShot\\loggedCSIPFailedSnapShot.jpeg";
	public static final String loggedCSIPSuccessSnapShot = "E:\\UITestingSnapShot\\loggedCSIPSuccessSnapShot.jpeg";
	public static final String DashboardFailedSnapShot = "E:\\UITestingSnapShot\\DashbaordFailedSnapShot.jpeg";
	public static final String DashboardSuccessSnapShot = "E:\\UITestingSnapShot\\DashbaordSuccessSnapShot.jpeg";
	public static final String STPFailedSnapShot = "E:\\UITestingSnapShot\\STPFailedSnapShot.jpeg";
	public static final String STPSnapShot = "E:\\UITestingSnapShot\\STPSuccessSnapShot.jpeg";
	public static final String RedeemFailedSnapShot="E:\\UITestingSnapShot\\RedeemFailedSnapShot.jpeg";
	public static final String RedeemSuccessSnapShot="E:\\UITestingSnapShot\\RedeemSuccessSnapShot.jpeg";
	public static final String SchemeChangeFailedSnapShot="E:\\UITestingSnapShot\\SchemeChangeFailedSnapShot.jpeg";
	public static final String SchemeChangeSuccessSnapShot="E:\\UITestingSnapShot\\SchemeChangeSuccessSnapShot.jpeg";
	public static final String LogoutFailedSnapShot="E:\\UITestingSnapShot\\LogoutFailedSnapShot.jpeg";
	public static final String ReLoginFailedSnapShot="E:\\UITestingSnapShot\\ReLoginFailedSnapShot.jpeg";
	public static final String ReLoginSuccessSnapShot="E:\\UITestingSnapShot\\ReLoginSuccessSnapShot.jpeg";
	public static final String LogoutSuccessSnapShot="E:\\UITestingSnapShot\\LogoutSuccessSnapShot.jpeg";
	public static final String LoginStartASIPSuccessSnapShot="E:\\UITestingSnapShot\\LoginStartASIPSuccessSnapShot.jpeg";
	public static final String LoginStartASIPFailedSnapShot="E:\\UITestingSnapShot\\LoginStartASIPFailedSnapShot.jpeg";
	public static final String InvestInNewSchemeFailedSnapShot="E:\\UITestingSnapShot\\InvestInNewSchemeFailedSnapShot.jpeg";
	public static final String InvestInNewSchemeSuccessSnapShot="E:\\UITestingSnapShot\\InvestInNewSchemeSuccessSnapShot.jpeg";
	public static final String GoalsFailedSnapShot="E:\\UITestingSnapShot\\GoalsFailedSnapShot.jpeg";
	public static final String LogincSIPFailedSnapShot="E:\\UITestingSnapShot\\LogincSIPFailedSnapShot.jpeg";
	public static final String LoginiSIPNoFirstInstallmentFailedSnapShot="E:\\UITestingSnapShot\\LoginiSIPNoFirstInstallmentFailedSnapShot.jpeg";
	public static final String LoginiSIPNoFirstInstallmentSuccessSnapShot="E:\\UITestingSnapShot\\LoginiSIPNoFirstInstallmentSuccessSnapShot.jpeg";
	public static final String LogincSIPSuccessSnapShot="E:\\UITestingSnapShot\\LogincSIPSuccessSnapShot.jpeg";
	public static final String NonLoginiSIPNoFirstInstallmentFailedSnapShot="E:\\UITestingSnapShot\\NonLoginiSIPNoFirstInstallmentFailedSnapShot.jpeg";
	public static final String NonLoginiSIPNoFirstInstallmentSuccessSnapShot="E:\\UITestingSnapShot\\NonLoginiSIPNoFirstInstallmentSuccessSnapShot.jpeg";
	public static final String LoginiSIPFailedSnapShot="E:\\UITestingSnapShot\\LoginiSIPFailedSnapShot.jpeg";
	public static final String LoginiSIPSuccessSnapShot="E:\\UITestingSnapShot\\LoginiSIPSuccessSnapShot.jpeg";
	public static final String NonLogincSIPSuccessSnapShot="E:\\UITestingSnapShot\\NonLogincSIPSuccessSnapShot.jpeg";
	public static final String NonLogincSIPFailedSnapShot="E:\\UITestingSnapShot\\NonLogincSIPFailedSnapShot.jpeg";
	public static final String NonLoginiSIPFailedSnapShot="E:\\UITestingSnapShot\\NonLoginiSIPFailedSnapShot.jpeg";
	public static final String NonLoginiSIPSuccessSnapShot="E:\\UITestingSnapShot\\NonLoginiSIPSuccessSnapShot.jpeg";
	public static final String LoggediSIPNoFirstInstallmentisipFailedSnapShot="E:\\UITestingSnapShot\\LoggediSIPNoFirstInstallmentisipFailedSnapShot";
	public static final String LoggediSIPNoFirstInstallmentisipSuccessSnapShot="E:\\UITestingSnapShot\\LoggediSIPNoFirstInstallmentisipSuccessSnapShot";
	public static final String exitloadsummaryFailedSnapShot="E:\\UITestingSnapShot\\exitloadsummaryFailedSnapShot.jpeg";
	public static final String exitloadsummarySuccessSnapShot="E:\\UITestingSnapShot\\exitloadsummarySuccessSnapShot.jpeg";
	public static final String RequestStatementFailedSnapShot="E:\\UITestingSnapShot\\RequestStatementFailedSnapShot.jpeg";
	public static final String RequestStatementSuccessSnapShot="E:\\UITestingSnapShot\\RequestStatementSuccessSnapShot.jpeg";
	
	
	
}