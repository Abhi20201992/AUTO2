package src.com.WebPagesNonLogged;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;
import src.com.WebPagesLogged.DriverClass;

public class Nonlogged_iSIPNoFirstInstallment {
	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "NonLogin ISIPNoFirstInstallment");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "SIP is clicked")
	public void NonLoginISIPNoFirstInstallment_TC01() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_0c1be14d_d39f_4d78_875e_3329816a006b_ctl00_lbtnSIP")));
			//while (!el1.isEnabled())
				el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

			Log.info("SIP is clicked");
			System.out.println("SIP is clicked");
			
			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment1, Constant.Result);
			//assertEquals("Pages - SIPInvestOnline", DriverClass.getdriver().getTitle(), " Incorrect Page Opened");

		} catch (Exception e) {
			Log.error("SIP is not clicked" + "\n" + e);
			System.out.println("SIP is not clicked");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "Folio number is selected")
	public void NonLoginISIPNoFirstInstallment_TC02() throws Exception {

		try {

			Thread.sleep(3000);

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_ddlSchDetailSelFolio")));
			Select folioNumber = new Select(el1);
			
			folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment2, Constant.InputData).trim()); // 1015226610,1014352208
				// 1014352208
     		Log.info("Folio number is selected");
			System.out.println("Folio number is selected");
			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment2, Constant.Result);

			//assertEquals(folioNumber.getFirstSelectedOption().getText(),
			//		ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment2, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Folio is not selected" + "\n" + e);
			System.out.println("Folio is not selected");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();

		}
	}

	@Test(description = "Advisor Details are selected")
	public void NonLoginISIPNoFirstInstallment_TC03() throws Exception {

		
			try {
				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
						By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_ddlAdvDetailAdvisorName")));
				Select folioNumber = new Select(el1);
				folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment3, Constant.InputData).trim()); // 1015226610,1014352208
					// Direct
				Log.info("Advisor Details are selected");
				System.out.println("Advisor Details are selected");
			
				ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment3, Constant.Result);

				//assertEquals(folioNumber.getFirstSelectedOption().getText(),
				//		ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment3, Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("Advisor Details are not selected" + "\n" + e);
				System.out.println("Advisor Details are not selected");
				ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment3, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
				e.printStackTrace();

			}
		}



	@Test(description = "Scheme Catagory is selected")
	public void NonLoginISIPNoFirstInstallment_TC04() throws Exception {
	
			try {

				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
						By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_ddlSchDetailsSchCategory")));

				Select folioNumber = new Select(el1);
				folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment4, Constant.InputData).trim());

				// DEBT
				Log.info("Scheme Catagory is selected");
				System.out.println("Scheme Catagory is selected");
				
				ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment4, Constant.Result);

				//assertEquals(folioNumber.getFirstSelectedOption().getText(),
				//		ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment4, Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("Advisor Details are not selected" + "\n" + e);
				System.out.println("Advisor Details are not selected");
				ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment4, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
				e.printStackTrace();
			}
		}
	

	@Test(description = "Scheme Sub Catagory is selected")
	public void NonLoginISIPNoFirstInstallment_TC05() throws Exception {
	
			try {

				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By
						.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_ddlSchDetailsSchSubCategory")));

				Select folioNumber = new Select(el1);
				folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment5, Constant.InputData).trim());

				// CORPORATE BOND
				Log.info("Scheme Sub Catagory is selected");
				System.out.println("Scheme Sub Catagory is selected");

				try {
					JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
					js.executeScript("window.scrollBy(0,50)");
					js.executeScript("window.scrollBy(0,50)");
				} catch (Exception e) {
					e.printStackTrace();
				}

				ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment5, Constant.Result);

				//assertEquals(folioNumber.getFirstSelectedOption().getText(),
				//		ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment5, Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("Scheme Sub Catagory is not selected" + "\n" + e);
				System.out.println("Scheme Sub Catagory is not selected");
				ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment5, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
				e.printStackTrace();
			}
		}
	

	@Test(description = "Scheme Name is selected")
	public void NonLoginISIPNoFirstInstallment_TC06() throws Exception {

			try {

				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
						By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_ddlSchDetailsFromScheme")));
				Thread.sleep(1000);
				Select folioNumber = new Select(el1);
				folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment6, Constant.InputData).trim());//

				// CORPORATE BOND FUND - GROWTH-DIRECT PLAN

				Log.info("Scheme Name is selected");
				System.out.println("Scheme Name is selected");

				try {
					JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
					js.executeScript("window.scrollBy(0,100)");
				} catch (Exception e) {
					e.printStackTrace();
				}

				ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment6, Constant.Result);

				//assertEquals(folioNumber.getFirstSelectedOption().getText(),
				//		ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment6, Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("Scheme Name is not selected" + "\n" + e);
				System.out.println("Scheme Name is not selected");
				ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment6, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
				e.printStackTrace();
			}
		}

	

	@Test(description = "Scheme option is selected")
	public void NonLoginISIPNoFirstInstallment_TC07() throws Exception {


			try {

				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
						By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_ddlSchDetailsSchOption")));
				Thread.sleep(1000);
				Select folioNumber = new Select(el1);
				folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment7, Constant.InputData).trim());
				// Growth

				Log.info("Scheme option is selected");
				System.out.println("Scheme Name is selected");

				try {
					JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
					js.executeScript("window.scrollBy(0,100)");
				} catch (Exception e) {
					e.printStackTrace();
				}

				ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment7, Constant.Result);

				//assertEquals(folioNumber.getFirstSelectedOption().getText(),
					//	ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment7, Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("Scheme option is not selected" + "\n" + e);
				System.out.println("Scheme option is not selected");
				ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment7, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
				e.printStackTrace();
			}
		}

	

	

	@Test(description = "OTM is clicked")
	public void NonLoginISIPNoFirstInstallment_TC08() throws Exception {

		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_rbtnOtm")));
			el1.click();
			Log.info("OTM is clicked");
			System.out.println("OTM is clicked");

			try {
				JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
				js.executeScript("window.scrollBy(0,100)");
			} catch (Exception e) {
				e.printStackTrace();
			}

			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment8, Constant.Result);
			//assertTrue(el1.isSelected());
		} catch (Exception e) {
			Log.error("OTM is not clicked" + "\n" + e);
			System.out.println("OTM is not clicked");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment8, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "Investment Frequency is selected")
	public void NonLoginISIPNoFirstInstallment_TC09() throws Exception {

		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_ddlInvestfreq")));
			Select folioNumber = new Select(el1);
			
			
			folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment9, Constant.InputData).trim());//
			// 2
			
			Log.info("Investment Frequency is selected");
			System.out.println("Investment Frequency is selected");

			try {
				JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
				js.executeScript("window.scrollBy(0,100)");
			} catch (Exception e) {
				e.printStackTrace();
			}

			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment9, Constant.Result);
			//assertEquals(folioNumber.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment9, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Investment Frequency is not selected" + "\n" + e);
			System.out.println("Investment Frequency is not selected");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment9, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Month is selected")
	public void NonLoginISIPNoFirstInstallment_TC10() throws Exception {

		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_ddlSchDetailsToMonth")));
			Select folioNumber = new Select(el1);
			folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment10, Constant.InputData).trim());

			// 5

			Log.info("Month is selected");
			System.out.println("Month is selected");

			try {
				JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
				js.executeScript("window.scrollBy(0,100)");
			} catch (Exception e) {
				e.printStackTrace();
			}

			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment10, Constant.Result);

			//assertEquals(folioNumber.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment10, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Month is not selectedd" + "\n" + e);
			System.out.println("Month is not selected");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment10, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "Year is selected")
	public void NonLoginISIPNoFirstInstallment_TC11() throws Exception {
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_ddlSchDetailsToYear")));
			Select folioNumber = new Select(el1);
			folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment11, Constant.InputData).trim());
			// 2099

			Log.info("Year is selected");
			System.out.println("Year is selected");

			try {
				JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
				js.executeScript("window.scrollBy(0,100)");
			} catch (Exception e) {
				e.printStackTrace();
			}

			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment11, Constant.Result);

			//assertEquals(folioNumber.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment11, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Year is not selectedd" + "\n" + e);
			System.out.println("Year is not selected");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment11, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Date Value is selected")
	public void NonLoginISIPNoFirstInstallment_TC12() throws Exception {
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_ddlSchDetailsPeriod")));
			Select folioNumber = new Select(el1);
			folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment12, Constant.InputData).trim());
			// 15

			Log.info("Date Value is selected");
			System.out.println("Date Value is selected");
			try {
				JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
				js.executeScript("window.scrollBy(0,100)");
			} catch (Exception e) {
				e.printStackTrace();
			}

			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment12, Constant.Result);

			//assertEquals(folioNumber.getFirstSelectedOption().getText(),
				//	ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment12, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Date Value is not selectedd" + "\n" + e);
			System.out.println("Date Value is not selected");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment12, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "Amount is Entered")
	public void NonLoginISIPNoFirstInstallment_TC13() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_txtSchDetailsInvAmount")));
			Thread.sleep(2000);
			el1.clear();
			Thread.sleep(1000);
			String amt=ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment13, Constant.InputData).trim();
			System.out.println(amt);
			/*try {
			el1.sendKeys(amt);
			}catch(Exception e) {
				el1.sendKeys("1000");
			}*/
			el1.sendKeys(amt);
			// 1000
			Thread.sleep(5000);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Amount is Entered");
			System.out.println("Amount is Entered");
			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment13, Constant.Result);

			//String text = el1.getAttribute("value");
			//assertEquals(text, ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment13, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Amount is not selectedd" + "\n" + e);
			System.out.println("Amount is not selected");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment13, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}
	}

	

	
	@Test(description = "Checkbox is Clicked")
	public void NonLoginISIPNoFirstInstallment_TC14() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_chkKeyInfo")));
			//while (!el1.isSelected())
				el1.click();

			Log.info("Checkbox is Clicked");
			System.out.println("Checkbox is Clicked");
			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment14, Constant.Result);

			//assertTrue(el1.isSelected());
		} catch (Exception e) {
			Log.error("Checkbox is not selectedd" + "\n" + e);
			System.out.println("Checkbox is not selected");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment14, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Next is Entered")
	public void NonLoginISIPNoFirstInstallment_TC15() throws Exception {

		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_lbtnInvDetailNext")));
			el1.click();

			Log.info("Next is Clicked");
			System.out.println("Next is Clicked");
			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment15, Constant.Result);

			

			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			//assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("Next is not selectedd" + "\n" + e);
			System.out.println("Next is not selected");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment15, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Next is Entered")
	public void NonLoginISIPNoFirstInstallment_TC16() throws Exception {

		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_lbtnBankDetailsNext")));
			//while (!el1.isEnabled())
				el1.click();

			Log.info("Next is Clicked");
			System.out.println("Next is Clicked");
			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment16, Constant.Result);



			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Next is not selectedd" + "\n" + e);
			System.out.println("Next is not selected");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment16, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}
	}

	/*@Test(description = "OTM is Clicked")
	public void NonLoginISIPNoFirstInstallment_TC17() throws Exception {

		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_lbtnPayOtm")));
			//while (!el1.isSelected())
				el1.click();

			Log.info("OTM is Clicked");
			System.out.println("OTM is Clicked");
			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment17, Constant.Result);
			assertTrue(el1.isSelected());
		} catch (Exception e) {
			Log.error("OTM is not selected" + "\n" + e);
			System.out.println("OTM is not selected");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment17, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Bank is selected")
	public void NonLoginISIPNoFirstInstallment_TC18() throws Exception {

		for (int i = 0; i < 3; i++) {
			try {

				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
						By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_ddlOtmDetailBankName")));

				
				Thread.sleep(1000);
				Select Name = new Select(el1);
				Name.selectByVisibleText(ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment18, Constant.InputData).trim()); // 
				Log.info("Bank is selected");
				System.out.println("Bank is selected");
				try {
					JavascriptExecutor js = (JavascriptExecutor) DriverClass.getdriver();
					js.executeScript("window.scrollBy(0,100)");
				} catch (Exception e) {
					e.printStackTrace();
				}
               //The Ratnakar Bank Ltd-1003710010008315
				ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment18, Constant.Result);

				assertEquals(Name.getFirstSelectedOption().getText(),
						ExcelUtils.getCellData(Constant.NonLoginISIPNoFirstInstallment18, Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("Bank  is not selected" + "\n" + e);
				System.out.println("Bank  is not selected");
				ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment18, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
				e.printStackTrace();
			}
		}
	}

	@Test(description = "Next is clicked")
	public void NonLoginISIPNoFirstInstallment_TC19() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_lbtnPaymantViewNext")));
			//while (!el1.isEnabled())
				el1.click();

			Log.info("Next is Clicked");
			System.out.println("Next is Clicked");
			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment19, Constant.Result);

			assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Next is not clicked" + "\n" + e);
			System.out.println("Next is not clicked");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment19, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}

	}*/

	@Test(description = "confirm is clicked")
	public void NonLoginISIPNoFirstInstallment_TC17() throws Exception {

		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_d9015e74_70f9_44ad_8265_6b38c2c5d5fb_ctl00_iSIP1_lbtnConfirmDetailsNext")));
			//while (!el1.isEnabled())
				el1.click();

			Log.info("Confirm is Clicked");
			System.out.println("Confirm is Clicked");
			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment17, Constant.Result);

			

			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			//assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Confirm is not clicked" + "\n" + e);
			System.out.println("Confirm is not clicked");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment17, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Screen Shot is Taken and saved")
	public void NonLoginISIPNoFirstInstallment_TC18() throws Exception {
		try {
			
			System.out.println(DriverClass.getdriver().getTitle());
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.NonLoginISIPNoFirstInstallment18, Constant.Result);
			Log.info("Non-Logged SIP is Successfully Completed,Thank you");
			System.out.println("Non-Logged SIP is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.NonLoginISIPNoFirstInstallment18, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.NonLoginiSIPNoFirstInstallmentFailedSnapShot);
			e.printStackTrace();

		}

	}

	@Test(description = "SetDriver")
	public void NonLoginISIPNoFirstInstallment_TC19() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
