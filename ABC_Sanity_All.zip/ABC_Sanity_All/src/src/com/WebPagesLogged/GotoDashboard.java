package src.com.WebPagesLogged;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class GotoDashboard {
	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Dashboard");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "Dashboard is Clicked")
	public void GotoDashboard_TC01() throws Exception {

		try {
			Thread.sleep(1500);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait
					.until(ExpectedConditions.presenceOfElementLocated(By.id("ctl00_liTopNavigation_GZ_ID")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("\n Dashboard is Clicked");
			System.out.println("\n Dashboard is Clicked");
			ExcelUtils.setCellData("Passed", Constant.Dashboard1, Constant.Result);
			//System.out.println(el1.isEnabled());
			//assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("\n Dashboard is not Clicked" + "\n" + e);
			System.out.println("\n Dashboard  is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Dashboard1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.DashboardFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "My Dashboard is Clicked")
	public void GotoDashboard_TC02() throws Exception {

		try {
			Thread.sleep(1500);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_liTopNavigation_rptDashboardMenu_ctl00_dashboardMenuLink")));
			el1.click();
			
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("\n My Dashboard is Clicked");
			System.out.println("\nMy Dashboard is Clicked");
			ExcelUtils.setCellData("Passed", Constant.Dashboard2, Constant.Result);
			
			
			
			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			
			//System.out.println(el1.isEnabled());
			//assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("\n My Dashboard is not Clicked" + "\n" + e);
			System.out.println("\n My Dashboard  is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.Dashboard2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.DashboardFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Screen Shot is Taken and saved")
	public void GotoDashboard_TC03() throws Exception {

		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.DashboardSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.Dashboard3, Constant.Result);
			Log.info("My Dashboard return Successfully Completed,Thank you");
			System.out.println("My Dashboard return is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.Dashboard3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.DashboardFailedSnapShot);
			e.printStackTrace();

		}

	}

	@Test(description = "SetDriver")
	public void GotoDashboard_TC04() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
