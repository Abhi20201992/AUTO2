package src.com.WebPagesLogged;

import org.testng.annotations.Test;

public class BrowserStop  {

	@Test
	public static void closeBrowser() {
		DriverClass.getdriver().close();
	}
}
