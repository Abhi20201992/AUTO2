package src.com.WebPagesLogged;


import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class LoggedPurchase{

	// public static void loggedPurchaseOperation() throws Exception {
	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Login Purchase");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description="Purchase is clicked")
	public void LoggedPurchase_TC01() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_e8e6e5b9_f91b_4286_9438_afe832ba38c2_ctl00_InvDashboardScheme_lbnPurchase")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Purchase is clicked");
			System.out.println("Purchase is clicked");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase1, Constant.Result);

			//assertEquals("Pages - AdditionalPurchase",DriverClass.getdriver().getTitle()," Incorrect Page Opened");
			//System.out.println(el1.isEnabled());
			//assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("Purchase is not clicked" + "\n" + e);
			System.out.println("Purchase is not clicked");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description="Folio is Selected")
	public void LoggedPurchase_TC02() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1=wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_ddlSchDetailsSelFolio")));

			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			
			Select folioNumber = new Select(DriverClass.getdriver().findElement(By.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_ddlSchDetailsSelFolio")));
		
			folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.loggedPurchase2, Constant.InputData).trim());
						
			Log.info("Folio is Selected");
			System.out.println("Folio is Selected");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase2, Constant.Result);
			
			//assertEquals(ExcelUtils.getCellData(Constant.loggedPurchase2, Constant.InputData).trim(),folioNumber.getFirstSelectedOption().getText());
			//System.out.println(el1.isSelected());
			//assertTrue(el1.isSelected());

		} catch (Exception e) {
			Log.error("Folio is not selected" + "\n" + e);
			System.out.println("Folio is not selected");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description="Advisor is Selected")
	public void LoggedPurchase_TC03() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_ddlAdvDetailAdvisorName")));
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Select advisor = new Select(el1);

			advisor.selectByVisibleText(
						ExcelUtils.getCellData(Constant.loggedPurchase3, Constant.InputData).trim());
			Log.info("Advisor is Selected");
			System.out.println("Advisor is Selected");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase3, Constant.Result);
			//assertEquals(ExcelUtils.getCellData(Constant.loggedPurchase3,Constant.InputData).trim(),advisor.getFirstSelectedOption().getText());
			//System.out.println(el1.isSelected());
			//assertTrue(el1.isSelected());

		} catch (Exception e) {
			Log.error("Advisor is Selected" + "\n" + e);
			System.out.println("Advisor is not Selected");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description="Scheme Catagory is selected")
	public void LoggedPurchase_TC04() throws Exception {
		
			try {
				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(
						"ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_ddlSchDetailsSchCategory")));

				Thread.sleep(1500);
				Select SchemeCat = new Select(DriverClass.getdriver().findElement(By.id(
						"ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_ddlSchDetailsSchCategory")));
				
				SchemeCat.selectByVisibleText(
						ExcelUtils.getCellData(Constant.loggedPurchase4, Constant.InputData).trim());

				Thread.sleep(1500);
				
				DriverClass.getdriver().manage().timeouts().implicitlyWait(Constant.loggedPurchase4, TimeUnit.SECONDS);
				Log.info("Scheme Catagory is selected");
				System.out.println("Scheme Catagory is selected");
				ExcelUtils.setCellData("Passed", Constant.loggedPurchase4, Constant.Result);
				//System.out.println(el1.isSelected());
				//assertTrue(el1.isSelected());
				//assertEquals(ExcelUtils.getCellData(Constant.loggedPurchase4,Constant.InputData).trim(),SchemeCat.getFirstSelectedOption().getText());
				
			} catch (Exception e) {
				Log.error("Scheme Catagory is not selected" + "\n" + e);
				System.out.println("Scheme Catagory is not selected");
				ExcelUtils.setCellData("Failed", Constant.loggedPurchase4, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
				e.printStackTrace();
			}
		}
	

	
	
	@Test(description = "Scheme sub Catagory is selected")
	public void LoggedPurchase_TC05() throws Exception {
		
			try {
				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(
						"ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_ddlSchDetailsSubSchCategory")));

				Thread.sleep(1500);
				Select SchemeCat = new Select(DriverClass.getdriver().findElement(By.id(
						"ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_ddlSchDetailsSubSchCategory")));
				SchemeCat.selectByVisibleText(
						ExcelUtils.getCellData(Constant.loggedPurchase5, Constant.InputData).trim());

				Thread.sleep(1500);
				DriverClass.getdriver().manage().timeouts().implicitlyWait(Constant.NonLoginPurchase4,
						TimeUnit.SECONDS);
				Log.info("Scheme sub Catagory is selected");
				System.out.println("Scheme Catagory is selected");
				ExcelUtils.setCellData("Passed", Constant.loggedPurchase5, Constant.Result);
				// System.out.println(el1.isSelected());
				// assertTrue(el1.isSelected());
				//assertEquals(ExcelUtils.getCellData(Constant.loggedPurchase5, Constant.InputData).trim(),SchemeCat.getFirstSelectedOption().getText());

			} catch (Exception e) {
				Log.error("Scheme sub Catagory is not selected" + "\n" + e);
				System.out.println("Scheme sub Catagory is not selected");
				ExcelUtils.setCellData("Failed", Constant.loggedPurchase5, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
				e.printStackTrace();
			}
		}

	
	@Test(description="Scheme details is selected")
	public void LoggedPurchase_TC06() throws Exception {
		
			try {
				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
						By.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_ddlSchDetailsScheme")));

				Thread.sleep(1500);
				Select Name = new Select(el1);
				Name.selectByVisibleText(ExcelUtils.getCellData(Constant.loggedPurchase6, Constant.InputData).trim());//
				DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				System.out.println(el1);
				Log.info("Scheme details is selected");
				System.out.println("Scheme details is selected");
				ExcelUtils.setCellData("Passed", Constant.loggedPurchase6, Constant.Result);
				//System.out.println(el1.isSelected());
				//assertTrue(el1.isSelected());
			    //assertEquals(ExcelUtils.getCellData(Constant.loggedPurchase6,Constant.InputData).trim(),Name.getFirstSelectedOption().getText());
				
				
			} catch (Exception e) {
				Log.error("Scheme details is not selected" + "\n" + e);
				System.out.println("Scheme details is not selected");
				ExcelUtils.setCellData("Failed", Constant.loggedPurchase6, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
				e.printStackTrace();
			}
		}
	

	@Test(description = "Scheme Option is selected")
	public void LoggedPurchase_TC07() throws Exception {

		for (int i = 0; i < 3; i++) {
			try {
				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By
						.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_ddlSchDetailsSchOption")));
				Thread.sleep(1500);
				Select Name = new Select(el1);
				Name.selectByVisibleText(ExcelUtils.getCellData(Constant.loggedPurchase7, Constant.InputData).trim());
				DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				Log.info("Scheme Option is selected");
				System.out.println("Scheme Option is selected");
				ExcelUtils.setCellData("Passed", Constant.loggedPurchase7, Constant.Result);
				// System.out.println(el1.isSelected());
				// assertTrue(el1.isSelected());
				// AssertJUnit.assertEquals(Name.getFirstSelectedOption().getText(),ExcelUtils.getCellData(Constant.loggedPurchase7,Constant.InputData).trim());

			} catch (Exception e) {
				Log.error("Re-investment is not selected" + "\n" + e);
				System.out.println("Re-investment is not selected");
				ExcelUtils.setCellData("Failed", Constant.loggedPurchase7, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
				e.printStackTrace();
			}
		}
	}

	@Test(description="Amount is Entered")
	public void LoggedPurchase_TC08() throws Exception {
			try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_txtSchDetailsInvAmount")));
			/*
			 * el1.clear(); Thread.sleep(1000); String
			  System.out.println(Input); el1.sendKeys(Input);
			 * Thread.sleep(2000); el1.clear(); Thread.sleep(1000); el1.sendKeys(Input);
			 * Thread.sleep(1000);
			 */
			//String Input=ExcelUtils.getCellData(Constant.loggedPurchase7,Constant.InputData).trim();
			//JavascriptExecutor jse = (JavascriptExecutor) driver;
			//jse.executeScript("arguments[0].value='1000';", el1);
			Thread.sleep(2000); 
			el1.clear();
			el1.sendKeys(ExcelUtils.getCellData(Constant.loggedPurchase8, Constant.InputData).trim());
			Thread.sleep(2000); 
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Amount is Entered");
			System.out.println("Amount is Entered");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase8, Constant.Result);
			
			//String text =el1.getAttribute("value"); 
			//AssertJUnit.assertEquals(ExcelUtils.getCellData(Constant.loggedPurchase8, Constant.InputData),text);
			
			
			
			
		} catch (Exception e) {
			Log.error("Amount is not Entered" + "\n" + e);
			System.out.println("Amount is not Entered");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase8, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description="NEFT is Clicked")
	public void LoggedPurchase_TC09() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_lbtnPayNEFTRTGS")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("NEFT is Clicked");
			System.out.println("NEFT is Clicked");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase9, Constant.Result);
			//System.out.println(el1.isEnabled());
			//AssertJUnit.assertTrue(el1.isEnabled());
			
			
		} catch (Exception e) {
			Log.error("NEFT is not Clicked" + "\n" + e);
			System.out.println("NEFT is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase9, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}


	@Test(description="Bank is Selected")
	public void LoggedPurchase_TC10() throws Exception {
		

			try {
				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id(
						"ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_ddlPaymentDetailNeftBankName")));

				Thread.sleep(1000);
				Select Name = new Select(el1);
				
				Name.selectByVisibleText(
							ExcelUtils.getCellData(Constant.loggedPurchase10, Constant.InputData).trim());

				
				
				DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				Log.info("Bank is Selected");
				System.out.println("Bank is Selected");
				ExcelUtils.setCellData("Passed", Constant.loggedPurchase10, Constant.Result);
				System.out.println(el1.isSelected());
			    assertEquals(ExcelUtils.getCellData(Constant.loggedPurchase10,Constant.InputData).trim(),Name.getFirstSelectedOption().getText());
				

			} catch (Exception e) {
				Log.error("Bank is not Selected" + "\n" + e);
				System.out.println("Bank is not Selected");
				ExcelUtils.setCellData("Failed", Constant.loggedPurchase10, Constant.Result);
				TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
				e.printStackTrace();
			}
		}
	


	@Test(description="Transaction number is Entered")
	public void LoggedPurchase_TC11() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_txtTransactionNumber")));
			/*
			 * String Input=ExcelUtils.getCellData(Constant.loggedPurchase10,
			 * Constant.InputData).trim(); System.out.println(Input); el1.sendKeys(Input);
			 * el1.sendKeys(Input); Thread.sleep(2000); el1.clear(); Thread.sleep(1000);
			 * el1.sendKeys(Input); Thread.sleep(1000);
			 */
			//String Input=ExcelUtils.getCellData(Constant.loggedPurchase10,Constant.InputData).trim();
			//JavascriptExecutor jse = (JavascriptExecutor) driver;
			//jse.executeScript("arguments[0].value='112233';", el1);
			Thread.sleep(2000); 
			el1.clear();
			Thread.sleep(1000); 
			el1.sendKeys(ExcelUtils.getCellData(Constant.loggedPurchase11, Constant.InputData).trim());
			Thread.sleep(2000); 
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Transaction number is Entered");
			System.out.println("Transaction number is Entered");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase11, Constant.Result);
			//String text = el1.getAttribute(Input);	
			//assertEquals(text, ExcelUtils.getCellData(Constant.loggedPurchase10, Constant.InputData).trim());
			//String text =el1.getAttribute("value"); 
			//assertEquals(ExcelUtils.getCellData(Constant.loggedPurchase11, Constant.InputData).trim(),text);
			
			//System.out.println(el1.getText());
			//assertEquals(el1.getText(), ExcelUtils.getCellData(Constant.loggedPurchase10, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Transaction number is not selected" + "\n" + e);
			System.out.println("Transaction number is not selected");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase11, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description="Upload is clicked")
	public void LoggedPurchase_TC12() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_uplPopUpImage")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Upload is clicked");
			System.out.println("Upload is clicked");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase12, Constant.Result);
			System.out.println(el1.isEnabled());
			//assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("Upload is not clicked" + "\n" + e);
			System.out.println("Upload is not clicked");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase12, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description="File is getting uploaded")
	public void LoggedPurchase_TC13() throws Exception {
		try {

			Runtime.getRuntime().exec(Constant.FileTOUpload);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("File is getting uploaded");
			System.out.println("File is getting uploaded");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase13, Constant.Result);

		} catch (Exception e) {
			Log.error("File is not getting uploaded" + "\n" + e);
			System.out.println("Upload is not clicked");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase13, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description="Checkbox is Clicked")
	public void LoggedPurchase_TC14() throws Exception {
		try {
			Thread.sleep(17000);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_chkKeyInfo")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Checkbox is Clicked");
			System.out.println("Checkbox is Clicked");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase14, Constant.Result);
			//System.out.println(el1.isEnabled());
			//AssertJUnit.assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("Checkbox is not Clicked" + "\n" + e);
			System.out.println("Checkbox is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase14, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description="KYC is Clicked")
	public void LoggedPurchase_TC15() throws Exception {

		try {
			Thread.sleep(1500);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_chkKYC")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("KYC is Clicked");
			System.out.println("KYC is Clicked");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase15, Constant.Result);
			//System.out.println(el1.isEnabled());
			//AssertJUnit.assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("KYC is not Clicked" + "\n" + e);
			System.out.println("KYC is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase15, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}


	@Test(description="Next is Clicked")
	public void LoggedPurchase_TC16() throws Exception {

		try {
			Thread.sleep(1500);
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_547b3231_223c_403f_a7eb_a215eeefca61_ctl00_Purchase1_lbtnInvDetailNext")));
			el1.click();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("\n Next is Clicked");
			System.out.println("\n Next is Clicked");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase16, Constant.Result);
			
			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			//System.out.println(el1.isEnabled());
			//AssertJUnit.assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("\n Next is not Clicked" + "\n" + e);
			System.out.println("\n Next is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase16, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}


	@Test(description="Alert is Accepted",enabled = false)
	public void LoggedPurchase_TC17() throws Exception {

		try {
			Alert alert = DriverClass.getdriver().switchTo().alert();
			DriverClass.getdriver().switchTo().alert();
			alert.getText();
			alert.accept();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Alert is Accepted");
			System.out.println("Alert is Accepted");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase17, Constant.Result);
			System.out.println(alert.getText());
			//AssertJUnit.assertEquals("",alert.getText());

		} catch (Exception e) {
			Log.error("Alert is not Accepted" + "\n" + e);
			System.out.println("Alert is not Accepted");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase17, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description="Screen Shot is Taken and saved")
	public void LoggedPurchase_TC18() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.loggedPurchase18, Constant.Result);
			Log.info("Logged Purchase is Successfully Completed,Thank you");
			System.out.println("Logged Purchase is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.loggedPurchase18, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.LoginPurchaseFailedSnapShot);
			e.printStackTrace();

		}		

	}
	
	
	@Test(description="Set Driver")
	public void LoggedPurchase_TC19() throws Exception {
	

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
