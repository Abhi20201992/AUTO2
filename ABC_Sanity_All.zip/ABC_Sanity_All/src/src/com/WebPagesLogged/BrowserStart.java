package src.com.WebPagesLogged;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class BrowserStart {

	@Test
	public static void openBrowser() throws Exception {
		DOMConfigurator.configure("log4j.xml");
		System.out.println("Chrome is Starting");
		Log.info("Chrome is Starting");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
		System.setProperty("webdriver.chrome.driver", Constant.ChromeDriverPath);

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "BrowserStart");

		try {
			// DriverClass.getdriver() = new ChromeDriver();

			DriverClass.getdriver().manage().deleteAllCookies();
			System.out.println("Cookies deleted");
			Log.info("Cookies deleted");

			DriverClass.getdriver().manage().window().maximize();
			ExcelUtils.setCellData("Passed", Constant.browserrow, Constant.Result);
			System.out.println("Browser Window is Maximized");
			Log.info("Browser Window is Maximized");

		} catch (Exception e) {
			e.printStackTrace();
			ExcelUtils.setCellData("Failed", Constant.browserrow, Constant.Result);
			Log.error("Browser Window is Maximize is Failed" + "\n" + e);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.BrowserFailedSnapShot);

		}

		try {
			Runtime.getRuntime().exec(Constant.BrowserAuth);
			ExcelUtils.setCellData("Passed", Constant.browserrow1, Constant.Result);
			System.out.println("Browser Authentication is performed");
			Log.info("Browser Authentication is Done");
		} catch (Exception e) {
			e.printStackTrace();
			ExcelUtils.setCellData("Failed", Constant.browserrow1, Constant.Result);
			Log.error("Browser Window is authentication is not done" + "\n" + e);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.BrowserFailedSnapShot);

		}

		try {
			DriverClass.getdriver().get(Constant.BaseUrl);
			ExcelUtils.setCellData("Passed", Constant.browserrow2, Constant.Result);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			//System.out.println(DriverClass.getdriver().getTitle());
			//System.out.println(DriverClass.getdriver().getTitle() == "Best Invesment Options | Wealth Creation | Tax Saving & Regular Income Plans � Birla Sun Life Mutual Fund");
			System.out.println("Base URL is launched in browser");
			Log.info("Base URL is launched in browser");
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.BrowserSuccessSnapShot);
		} catch (Exception e) {
			e.printStackTrace();
			ExcelUtils.setCellData("Failed", Constant.browserrow2, Constant.Result);
			Log.error("Base URL is launched in browser");
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.BrowserFailedSnapShot);
		}

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}