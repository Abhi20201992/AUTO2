package src.com.WebPagesLogged;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;


public class RequestStatement {

	// public static void loggedPurchaseOperation() throws Exception {
	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "RequestStatement");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "request Statement is clicked")
	public void requestStatement_TC01() throws Exception {
	
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ctl00_m_g_e8e6e5b9_f91b_4286_9438_afe832ba38c2_ctl00_InvDashboardScheme_lbnRequestStatement")));
			
			el1.click();
			Thread.sleep(3000);
			
			Log.info("request Statement is clicked");
			System.out.println("request Statement is clicked");
			ExcelUtils.setCellData("Passed", Constant.requestStatement1, Constant.Result);
			//assertEquals("Pages - AccountStatement",DriverClass.getdriver().getTitle()," Incorrect Page Opened");

		} catch (Exception e) {
			
			Log.error("request Statement is not clicked" + "\n" + e);
			System.out.println("request Statement is not clicked");
			ExcelUtils.setCellData("Failed", Constant.requestStatement1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementFailedSnapShot);
			e.printStackTrace();
		}
	 }
	
	@Test(description = "Folio is Selected")
	public void requestStatement_TC02() throws Exception {
	
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
				wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_5f1ce09a_7737_44ca_9498_3d71ff8212ae_ctl00_ddlFolioNo")));
					
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			
			Select folioNumber = new Select(DriverClass.getdriver().findElement(By.id("ctl00_m_g_5f1ce09a_7737_44ca_9498_3d71ff8212ae_ctl00_ddlFolioNo")));
						
			String folioIndex =ExcelUtils.getCellData(Constant.requestStatement2, Constant.InputData2).trim();
			int folioIndex1 = Integer.parseInt(folioIndex);
		
			try {
				folioNumber.selectByVisibleText(ExcelUtils.getCellData(Constant.requestStatement2, Constant.InputData).trim());
			} catch (Exception e) {
				e.printStackTrace();
				folioNumber.selectByIndex(folioIndex1);
			}

			Log.info("Folio is Selected");
			System.out.println("Folio is Selected");
			ExcelUtils.setCellData("Passed", Constant.requestStatement2, Constant.Result);
			//assertEquals(ExcelUtils.getCellData(Constant.requestStatement2, Constant.InputData).trim(),folioNumber.getFirstSelectedOption().getText());

		} catch (Exception e) {
			Log.error("Folio is not selected" + "\n" + e);
			System.out.println("Folio is not selected");
			ExcelUtils.setCellData("Failed", Constant.requestStatement2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementFailedSnapShot);
			e.printStackTrace();
		}
	  }
	

	@Test(description = "Scheme is Selected")
	public void requestStatement_TC03() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_5f1ce09a_7737_44ca_9498_3d71ff8212ae_ctl00_ddlSchemes")));

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		   
			String advisorIndex =ExcelUtils.getCellData(Constant.requestStatement3, Constant.InputData2).trim();		
			int advisorIndex1 = Integer.parseInt(advisorIndex);
			
			Select advisor = new Select(el1);

			try {
				advisor.selectByVisibleText(ExcelUtils.getCellData(Constant.requestStatement3, Constant.InputData).trim());
			} catch (Exception e) {
				e.printStackTrace();
				advisor.selectByIndex(advisorIndex1);
			}
			
			//0
			Log.info("Scheme is Selected");
			System.out.println("Scheme is Selected");
			ExcelUtils.setCellData("Passed", Constant.requestStatement3, Constant.Result);

			// System.out.println("****************==========*********"+advisor.getFirstSelectedOption().getText());
			//assertEquals(ExcelUtils.getCellData(Constant.requestStatement3, Constant.InputData).trim(),advisor.getFirstSelectedOption().getText());
			// System.out.println(el1.isSelected());
			// assertTrue(el1.isSelected());

		} catch (Exception e) {
			Log.error("Scheme is not Selected" + "\n" + e);
			System.out.println("Scheme is not Selected");
			ExcelUtils.setCellData("Failed", Constant.requestStatement3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Report Type Selected")
	public void requestStatement_TC04() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_5f1ce09a_7737_44ca_9498_3d71ff8212ae_ctl00_ddlRptType")));

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			
			String NameIndex =ExcelUtils.getCellData(Constant.requestStatement4, Constant.InputData2).trim();		
			int NameIndex1 = Integer.parseInt(NameIndex);
			
			
			Select Name = new Select(el1);
			
			try {
				Name.selectByVisibleText(ExcelUtils.getCellData(Constant.requestStatement4, Constant.InputData).trim());
			} catch (Exception e) {
				e.printStackTrace();
				Name.selectByIndex(NameIndex1);

			}

			Log.info("Report Type Selected");
			System.out.println("Report Type Selected");
			ExcelUtils.setCellData("Passed", Constant.requestStatement4, Constant.Result);

			//assertEquals(ExcelUtils.getCellData(Constant.requestStatement4, Constant.InputData).trim(),Name.getFirstSelectedOption().getText());
			// System.out.println(el1.isSelected());
			// assertTrue(el1.isSelected());

		} catch (Exception e) {
			Log.info("Report Type is not Selected");
			System.out.println("Report Type is not Selected");
			ExcelUtils.setCellData("Failed", Constant.requestStatement4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Broker info Selected ")
	public void requestStatement_TC05() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_5f1ce09a_7737_44ca_9498_3d71ff8212ae_ctl00_ddlBrokerInfo")));
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
			String NameIndex =ExcelUtils.getCellData(Constant.requestStatement5, Constant.InputData2).trim();		
			int NameIndex1 = Integer.parseInt(NameIndex);
			
			Select Name = new Select(el1);
			
			try {
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.requestStatement5, Constant.InputData).trim());
			}catch(Exception e) {
				e.printStackTrace();
				Name.selectByIndex(NameIndex1);
			}
			
			
			// Yes

			Log.info("Broker info Selected ");
			System.out.println("Broker info Selected ");
			ExcelUtils.setCellData("Passed", Constant.requestStatement5, Constant.Result);

			//assertEquals(ExcelUtils.getCellData(Constant.requestStatement5, Constant.InputData).trim(),Name.getFirstSelectedOption().getText());
			// System.out.println(el1.isSelected());
			// assertTrue(el1.isSelected());

		} catch (Exception e) {
			Log.info("Broker info is not Selected ");
			System.out.println("Broker info is not Selected ");
			ExcelUtils.setCellData("Failed", Constant.requestStatement5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Financial year is clicked")
	public void requestStatement_TC06() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);

			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_5f1ce09a_7737_44ca_9498_3d71ff8212ae_ctl00_rbFinYear")));
			el1.click();
			Thread.sleep(3000);
			Log.info("Financial year Selected");
			System.out.println("Financial year Selected");
			ExcelUtils.setCellData("Passed", Constant.requestStatement6, Constant.Result);

		    //assertTrue(el1.isSelected());
		} catch (Exception e) {
			Log.error("request Statement is not clicked" + "\n" + e);
			System.out.println("request Statement is not clicked");
			ExcelUtils.setCellData("Failed", Constant.requestStatement6, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "ALL Years Selected")
	public void requestStatement_TC07() throws Exception {
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);

			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_5f1ce09a_7737_44ca_9498_3d71ff8212ae_ctl00_ddlYear")));
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			String NameIndex =ExcelUtils.getCellData(Constant.requestStatement7, Constant.InputData2).trim();		
			int NameIndex1 = Integer.parseInt(NameIndex);	
			
			Select Name = new Select(el1);
		
			try {
			Name.selectByVisibleText(ExcelUtils.getCellData(Constant.requestStatement7, Constant.InputData).trim());
			}catch(Exception e) {
				e.printStackTrace();
				Name.selectByIndex(NameIndex1);
			}
			
			Log.info("ALL Years Selected");
			System.out.println("ALL Years Selected");
			ExcelUtils.setCellData("Passed", Constant.requestStatement7, Constant.Result);
			//AssertJUnit.assertEquals(ExcelUtils.getCellData(Constant.requestStatement7, Constant.InputData).trim(),Name.getFirstSelectedOption().getText());

		} catch (Exception e) {

			Log.error("ALL Years is not Selected" + "\n" + e);
			System.out.println("ALL Years is not Selected");
			ExcelUtils.setCellData("Failed", Constant.requestStatement7, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementFailedSnapShot);
			e.printStackTrace();

		}
	}

	@Test(description = "pdf is downloading")
	public void requestStatement_TC08() throws Exception {
	
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_5f1ce09a_7737_44ca_9498_3d71ff8212ae_ctl00_lbtnDownload")));
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			
			el1.click();
			
			Thread.sleep(8000);
			
			try {
			Alert alert = DriverClass.getdriver().switchTo().alert();
			DriverClass.getdriver().switchTo().alert();
			alert.accept();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			Log.info("pdf is downloading");
			System.out.println("pdf is downloading");
			ExcelUtils.setCellData("Passed", Constant.requestStatement8, Constant.Result);

			//assertTrue(isFileDownloaded(Constant.DownloadPath, "mailmerge.xls"), "Failed to download Expected document");
			
		
		} catch (Exception e) {

			Log.error("pdf is downloading" + "\n" + e);
			System.out.println("pdf is not downloading");
			ExcelUtils.setCellData("Failed", Constant.requestStatement8, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementFailedSnapShot);
			e.printStackTrace();

		}

	}


	
	@Test(description = "Excel is  downloading")
	public void requestStatement_TC09() throws Exception {
	
		try {
			
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);


			
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_5f1ce09a_7737_44ca_9498_3d71ff8212ae_ctl00_lbtnExcel")));
			
			el1.click();
			
			Thread.sleep(8000);
			Log.info("Excel is  downloading");
		    System.out.println("Excel is  downloading");
			ExcelUtils.setCellData("Passed", Constant.requestStatement9, Constant.Result);
		} catch (Exception e) {
			Log.error("Excel is not downloading" + "\n" + e);
			System.out.println("Excel is not downloading");
			ExcelUtils.setCellData("Failed", Constant.requestStatement9, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementFailedSnapShot);
		    e.printStackTrace();

		}
	}


	@Test(description = "Alert is Accepted", enabled = true)
	public void requestStatement_TC10() throws Exception {

		try {
			Alert alert = DriverClass.getdriver().switchTo().alert();
			DriverClass.getdriver().switchTo().alert();
			alert.getText();
			alert.accept();
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Log.info("Alert is Accepted");
			System.out.println("Alert is Accepted");
			ExcelUtils.setCellData("Passed", Constant.requestStatement10, Constant.Result);
			//System.out.println(alert.getText());
			//AssertJUnit.assertEquals(alert.getText(), "");

		} catch (Exception e) {
			Log.error("Alert is not Accepted" + "\n" + e);
			System.out.println("Alert is not Accepted");
			ExcelUtils.setCellData("Failed", Constant.requestStatement10, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementFailedSnapShot);
			e.printStackTrace();
		}
	}
	
	
	
	
	@Test(description="Screen Shot is Taken and saved")
	public void requestStatement_TC11() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.requestStatement11, Constant.Result);
			Log.info("Request Statement Testing is Successfully Completed,Thank you");
			System.out.println("Request Statement Testing is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.requestStatement11, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.RequestStatementFailedSnapShot);
			e.printStackTrace();

		}

	}
	
	
	@Test(description = "SetDriver")
	public void requestStatement_TC12() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}