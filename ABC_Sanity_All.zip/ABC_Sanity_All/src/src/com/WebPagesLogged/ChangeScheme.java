package src.com.WebPagesLogged;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class ChangeScheme {

	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Change Scheme");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description="Scheme Change is clicked")
	public void schemeChange_TC01() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_e8e6e5b9_f91b_4286_9438_afe832ba38c2_ctl00_InvDashboardScheme_gvSchemeSummary_ctl05_RadioButton1")));
			el1.click();
			Thread.sleep(3000);
			Log.info("different scheme is clicked");
			System.out.println("different scheme  is clicked");
			ExcelUtils.setCellData("Passed", Constant.schemeChange1, Constant.Result);
			
			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(),Constant.SchemeChangeSuccessSnapShot);
			
		} catch (Exception e) {
			Log.error("different scheme is not clicked" + "\n" + e);
			System.out.println("different scheme is not clicked");
			ExcelUtils.setCellData("Failed", Constant.schemeChange1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(),Constant.SchemeChangeFailedSnapShot);
			e.printStackTrace();
		}
	}


}
