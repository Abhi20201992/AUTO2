package src.com.WebPagesLogged;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import src.com.ExcelInputOutput.Constant;

public class DriverClass {
	private static WebDriver driver;


	public static WebDriver getdriver() {
		if (driver == null) {
			System.setProperty("webdriver.chrome.driver", Constant.ChromeDriverPath);
			driver = new ChromeDriver();
			//System.setProperty("webdriver.gecko.driver", Constant.FireFoxDriver);
			//driver=new FirefoxDriver();
			return driver;
		} else {
			return driver;
		}
	}

	public static void setDriver(WebDriver driver) {
		DriverClass.driver = driver;
	}

}