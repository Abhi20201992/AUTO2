package src.com.WebPagesLogged;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class MyProfile {

	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "MyProfile");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "Accounts is clicked")
	public void MyProfile_TC01() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id=\"ctl00_liTopNavigation_IndLoggedInMenu\"]/li[1]/a")));
			el1.click();

			System.out.println("Accounts is clicked");
			Log.info("Accounts is clicked");
			ExcelUtils.setCellData("Passed", Constant.MyProfile1, Constant.Result);

		} catch (Exception e) {
			Log.error("Accounts is not clicked");
			System.out.println("Accounts is not clicked");
			ExcelUtils.setCellData("Failed", Constant.MyProfile1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.MyProfileFailedSnapshot);
			e.printStackTrace();

		}
	}

	@Test(description = "My Profile is clicked")
	public void MyProfile_TC02() throws Exception {

		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//*[@id=\"ctl00_liTopNavigation_IndLoggedInMenu\"]/li[1]/ul/li[3]/a")));
			el1.click();

			Log.info("My Profile is clicked");
			System.out.println("My Profile is clicked");
			ExcelUtils.setCellData("Passed", Constant.MyProfile2, Constant.Result);

		} catch (Exception e) {
			Log.error("My Profile is not clicked");
			System.out.println("My Profile is not  clicked");
			ExcelUtils.setCellData("Failed", Constant.MyProfile2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.MyProfileFailedSnapshot);
			e.printStackTrace();

		}
	}

	@Test(description = "Checkbox is clicked")
	public void MyProfile_TC03() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_0941be8f_f05f_412f_99ed_cabd4ce73902_ctl00_InvProfileDetails_CheckBox1")));
			el1.click();

			Log.info("Checkbox is clicked");
			System.out.println("Checkbox is clicked");
			ExcelUtils.setCellData("Passed", Constant.MyProfile3, Constant.Result);

		} catch (Exception e) {
			Log.error("Checkbox is not clicked");
			System.out.println("Checkbox is not clicked");
			ExcelUtils.setCellData("Failed", Constant.MyProfile3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.MyProfileFailedSnapshot);
			e.printStackTrace();

		}

	}

	@Test(description = "Emailid is entered")
	public void MyProfile_TC04() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_0941be8f_f05f_412f_99ed_cabd4ce73902_ctl00_InvProfileDetails_txtEmail")));
			el1.clear();
			el1.sendKeys(ExcelUtils.getCellData(Constant.MyProfile4, Constant.InputData).trim());

			Log.info("Emailid is entered");
			System.out.println("Emailid is entered");
			ExcelUtils.setCellData("Passed", Constant.MyProfile4, Constant.Result);

		} catch (Exception e) {

			Log.error("Emailid is not entered");
			System.out.println("Emailid is not entered");
			ExcelUtils.setCellData("Failed", Constant.MyProfile4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.MyProfileFailedSnapshot);
			e.printStackTrace();

		}
	}

	@Test(description = "Phone Number is entered")
	public void MyProfile_TC05() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_0941be8f_f05f_412f_99ed_cabd4ce73902_ctl00_InvProfileDetails_txtMobileValue")));
			el1.clear();
			el1.sendKeys(ExcelUtils.getCellData(Constant.MyProfile5, Constant.InputData).trim());

			Log.info("Phone Number is entered");
			System.out.println("Phone Number is entered");
			ExcelUtils.setCellData("Passed", Constant.MyProfile5, Constant.Result);

		} catch (Exception e) {
			Log.info("Phone Number is not  entered");
			System.out.println("Phone Number is not entered");
			ExcelUtils.setCellData("Failed", Constant.MyProfile5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.MyProfileFailedSnapshot);
			e.printStackTrace();

		}
	}

	@Test(description = "Save is Clicked")
	public void MyProfile_TC06() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_0941be8f_f05f_412f_99ed_cabd4ce73902_ctl00_InvProfileDetails_btnSave")));
			el1.click();

			Log.info("Save is Clicked");
			System.out.println("Save is Clicked");
			ExcelUtils.setCellData("Passed", Constant.MyProfile6, Constant.Result);

		} catch (Exception e) {
			Log.error("Save is not  Clicked");
			System.out.println("Save is not  Clicked");
			ExcelUtils.setCellData("Failed", Constant.MyProfile6, Constant.Result);

			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.MyProfileFailedSnapshot);
			e.printStackTrace();

		}
	}

	@Test(description = "Alert is accepted")
	public void MyProfile_TC07() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			Alert alert = wait.until(ExpectedConditions.alertIsPresent());
			alert.accept();

			Log.info("alert is accepted");
			System.out.println("alert is accepted");
			ExcelUtils.setCellData("Passed", Constant.MyProfile7, Constant.Result);

		} catch (Exception e) {
			Log.info("alert is not accepted");
			System.out.println("alert is not accepted");
			ExcelUtils.setCellData("Failed", Constant.MyProfile7, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.MyProfileFailedSnapshot);
			e.printStackTrace();

		}
	}

	@Test(description = "Screen Shot is Taken and saved")
	public void MyProfile_TC08() throws Exception {

		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.MyProfileSuccessSnapshot);

			System.out.println("Screen Shot is Taken and saved");
			Log.info("My Profile Updation is Successfully Completed,Thank you");
			System.out.println("My Profile Updation is Successfully Completed,Thank you");
			ExcelUtils.setCellData("Passed", Constant.MyProfile8, Constant.Result);

		} catch (Exception e) {
			Log.error("Some Error Occured");
			System.out.println("Some Error Occured");
			ExcelUtils.setCellData("Failed", Constant.MyProfile8, Constant.Result);

			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.MyProfileFailedSnapshot);
			System.out.println(e);

		}

	}

	@Test(description = "SetDriver")
	public void MyProfile_TC09() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
