package src.com.WebPagesLogged;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class ExitLoadSummary {

	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "ExitloadSummary");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "Exit load Summary  clicked")
	public void exitLoadSummary_TC01() throws Exception {
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("lbnExitLoadreport")));
			
				el1.click();
			
			Thread.sleep(5000);
            
			System.out.println("Exit load Summary  clicked");
			Log.info("Exit load Summary  clicked");
			ExcelUtils.setCellData("Passed", Constant.exitLoadSummary1, Constant.Result);
			//assertTrue(el1.isEnabled());
		} catch (Exception e) {
			Log.error("Exit load Summary is not clicked" + "\n" + e);
			System.out.println("Exit load Summary is not clicked");
			ExcelUtils.setCellData("Failed", Constant.exitLoadSummary1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.exitloadsummaryFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Frame is switched")
	public void exitLoadSummary_TC02() throws Exception {
		try {
 
			Thread.sleep(10000);
			
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);

			DriverClass.getdriver().switchTo()
					.frame(wait.until(ExpectedConditions.presenceOfElementLocated(By.id("TB_iframeContent"))));
			DriverClass.getdriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

			System.out.println("Frame is switched");
			Log.info("Frame is switched");
			ExcelUtils.setCellData("Passed", Constant.exitLoadSummary2, Constant.Result);
			//assertTrue(wait.until(ExpectedConditions.presenceOfElementLocated(By.id("TB_iframeContent"))).isEnabled());
		} catch (Exception e) {
			Log.error("Frame is not clicked" + "\n" + e);
			System.out.println("Frame is not clicked");
			ExcelUtils.setCellData("Failed", Constant.exitLoadSummary2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.exitloadsummaryFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Pdf is getting downloaded")
	public void exitLoadSummary_TC03() throws Exception {

		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("btnPDF")));
			//while (!el1.isEnabled()) {
				el1.click();
			//}

			Thread.sleep(6000);
			System.out.println("Pdf is getting downloaded");
			Log.info("Pdf is getting downloaded");
			ExcelUtils.setCellData("Passed", Constant.exitLoadSummary3, Constant.Result);

		} catch (Exception e) {
			Log.error("Pdf is not downloaded" + "\n" + e);
			System.out.println("Pdf is not downloaded");
			ExcelUtils.setCellData("Failed", Constant.exitLoadSummary3, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.exitloadsummaryFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Excel is getting downloaded")
	public void exitLoadSummary_TC04() throws Exception {

		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("btnExport"))).click();

			Thread.sleep(6000);
			System.out.println("Excel is getting downloaded");
			Log.info("Excel is getting downloaded");
			ExcelUtils.setCellData("Passed", Constant.exitLoadSummary4, Constant.Result);

		} catch (Exception e) {
			Log.error("Excel is not downloaded" + "\n" + e);
			System.out.println("Excel is not downloaded");
			ExcelUtils.setCellData("Failed", Constant.exitLoadSummary4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.exitloadsummaryFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "Screen Shot is Taken and saved")
	public void exitLoadSummary_TC05() throws Exception {
		try {
			
			try {
				WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.exitloadsummarySuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.exitLoadSummary5, Constant.Result);
			Log.info("ExitLoadSummary is Successfully Completed,Thank you");
			System.out.println("Logged CSIP is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.exitLoadSummary5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.exitloadsummaryFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Close window")
	public void exitLoadSummary_TC06() throws Exception {
		try {

			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);

			WebElement el1 = wait.until(
					ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div/div[1]/span[2]")));
			
				el1.click();
			

			ExcelUtils.setCellData("Passed", Constant.exitLoadSummary6, Constant.Result);
			Log.info("Button close is clicked");
			System.out.println("Button close is clicked");
		} catch (Exception e) {
			Log.error("Button close is not clicked" + "\n" + e);
			System.out.println("Button close is not clicked");
			ExcelUtils.setCellData("Failed", Constant.exitLoadSummary6, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.exitloadsummaryFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "SetDriver")
	public void exitLoadSummary_TC07() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
