package src.com.WebPagesLogged;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;

public class SWP {

	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");
		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "SWP");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test(description = "SWP is clicked")
	public void swp_TC01() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_e8e6e5b9_f91b_4286_9438_afe832ba38c2_ctl00_InvDashboardScheme_lbnSWP")));
			el1.click();
			Thread.sleep(2000);
			Log.info("SWP is clicked");
			System.out.println("SWP is clicked");
			ExcelUtils.setCellData("Passed", Constant.swp1, Constant.Result);
			// assertEquals("Pages - SWP", DriverClass.getdriver().getTitle(),
			// "Incorrect Page Opened,Script is getting failed");

		} catch (Exception e) {
			Log.error("SWP is not clicked" + "\n" + e);
			System.out.println("SWP is not clicked");
			ExcelUtils.setCellData("Failed", Constant.swp1, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Scheme Name is selected")
	public void swp_TC02() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsFromScheme")));
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			Select advisor = new Select(DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsFromScheme")));
			advisor.selectByVisibleText(ExcelUtils.getCellData(Constant.swp2, Constant.InputData).trim());
			// Frontline Equity Fund -Dividend-Regular Plan
			Log.info("Scheme Name is Selected");
			System.out.println("Scheme Name is Selected");
			ExcelUtils.setCellData("Passed", Constant.swp2, Constant.Result);
			// assertEquals(advisor.getFirstSelectedOption().getText(),
			// ExcelUtils.getCellData(Constant.swp2, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("From Scheme is not selected" + "\n" + e);
			System.out.println("From Scheme is not selected");
			ExcelUtils.setCellData("Failed", Constant.swp2, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "Frequency is selected")
	public void swp_TC03() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsFrequency")));
			Select fromScheme = new Select(el1);
			fromScheme.selectByVisibleText(ExcelUtils.getCellData(Constant.swp3, Constant.InputData).trim());

			// Monthly (minimum 6 months)
			Log.info("Frequency is selected");
			System.out.println("Frequency is selected");
			ExcelUtils.setCellData("Passed", Constant.swp3, Constant.Result);

			// assertEquals(fromScheme.getFirstSelectedOption().getText(),
			// ExcelUtils.getCellData(Constant.swp3, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Frequency is not Selected" + "\n" + e);
			System.out.println("Frequency is not Selected");
			ExcelUtils.setCellData("Failed", Constant.swp5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Type is selected")
	public void swp_TC04() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsSchOption")));
			Select SchOption = new Select(DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsSchOption")));
			SchOption.selectByVisibleText(ExcelUtils.getCellData(Constant.swp4, Constant.InputData).trim());// Fixed
			// Fixed
			Log.info("Type is selected");
			System.out.println("Type is selected");
			ExcelUtils.setCellData("Passed", Constant.swp4, Constant.Result);
			// assertEquals(SchOption.getFirstSelectedOption().getText(),
			// ExcelUtils.getCellData(Constant.swp4, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Scheme Option is not selected" + "\n" + e);
			System.out.println("Scheme Option is not selected");
			ExcelUtils.setCellData("Failed", Constant.swp4, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "Amount is Entered")
	public void swp_TC05() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_txtSchDetailsAmountPer")));
			el1.clear();
			Thread.sleep(2000);

			el1.sendKeys(ExcelUtils.getCellData(Constant.swp5, Constant.InputData).trim());
			Thread.sleep(2000);

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Thread.sleep(1500);
			Log.info("Amount is Entered");
			System.out.println("Amount is Entered");
			ExcelUtils.setCellData("Passed", Constant.swp5, Constant.Result);

			// String text = el1.getAttribute("value");
			// assertEquals(text, "40000");

		} catch (Exception e) {
			Log.error("Amount is not Entered" + "\n" + e);
			System.out.println("Amount is not Entered");
			ExcelUtils.setCellData("Failed", Constant.swp5, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "From Month is selected")
	public void swp_TC06() throws Exception {

		try {
			DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsFromMonth"));
			DriverClass.getdriver().manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
			Select month = new Select(DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsFromMonth")));
			month.selectByVisibleText(ExcelUtils.getCellData(Constant.swp6, Constant.InputData).trim());
			// May
			Log.info("From Month is selected");
			System.out.println("From Month is selected");

			ExcelUtils.setCellData("Passed", Constant.swp6, Constant.Result);
			// assertEquals(month.getFirstSelectedOption().getText(),
			// ExcelUtils.getCellData(Constant.swp6, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Month is not selected" + "\n" + e);
			System.out.println("Month is not selected");
			ExcelUtils.setCellData("Failed", Constant.swp6, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "From Year is selected")
	public void swp_TC07() throws Exception {
		try {
			DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsFromYear"));
			DriverClass.getdriver().manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
			
			String Index=ExcelUtils.getCellData(Constant.swp7, Constant.InputData2).trim();
			int Index1=Integer.parseInt(Index);
			
			Select year = new Select(DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsFromYear")));
		
			try {
			year.selectByVisibleText(ExcelUtils.getCellData(Constant.swp7, Constant.InputData).trim());
			}catch(Exception e) {
				e.printStackTrace();
			    year.selectByIndex(Index1);
			}
			Log.info("From Year is selected");
			System.out.println("From year is selected");

			ExcelUtils.setCellData("Passed", Constant.swp7, Constant.Result);
			// assertEquals(year.getFirstSelectedOption().getText(),"2019");
			// ExcelUtils.getCellData(Constant.swp7, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Year is not selected" + "\n" + e);
			System.out.println("Year is not selected");
			ExcelUtils.setCellData("Failed", Constant.swp7, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "To Month is selected")
	public void swp_TC08() throws Exception {

		try {
			DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsToMonth"));
			DriverClass.getdriver().manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
			Select month = new Select(DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsToMonth")));
			month.selectByVisibleText(ExcelUtils.getCellData(Constant.swp8, Constant.InputData).trim());
			// May
			Log.info("Month is selected");
			System.out.println("Month is selected");
			ExcelUtils.setCellData("Passed", Constant.swp8, Constant.Result);
			// assertEquals(month.getFirstSelectedOption().getText(),
			// ExcelUtils.getCellData(Constant.swp6, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Month is not selected" + "\n" + e);
			System.out.println("Month is not selected");
			ExcelUtils.setCellData("Failed", Constant.swp8, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "To Year is selected")
	public void swp_TC09() throws Exception {
		try {
			DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsToYear"));
			DriverClass.getdriver().manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
			Select year = new Select(DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsToYear")));
			year.selectByVisibleText(ExcelUtils.getCellData(Constant.swp9, Constant.InputData).trim());
			// 2019
			Log.info("Year is selected");
			System.out.println("year is selected");

			ExcelUtils.setCellData("Passed", Constant.swp9, Constant.Result);
			// assertEquals(year.getFirstSelectedOption().getText(),"2019");
			// ExcelUtils.getCellData(Constant.swp7, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Year is not selected" + "\n" + e);
			System.out.println("Year is not selected");
			ExcelUtils.setCellData("Failed", Constant.swp9, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Date is selected")
	public void swp_TC10() throws Exception {
		try {
			DriverClass.getdriver()
					.findElement(By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsDate"));
			DriverClass.getdriver().manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
			Select year = new Select(DriverClass.getdriver()
					.findElement(By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlSchDetailsDate")));
			year.selectByVisibleText(ExcelUtils.getCellData(Constant.swp10, Constant.InputData).trim());
			// 2019
			Log.info("Date is selected");
			System.out.println("Date is selected");// 28th

			ExcelUtils.setCellData("Passed", Constant.swp10, Constant.Result);
			// assertEquals(year.getFirstSelectedOption().getText(),
			// ExcelUtils.getCellData(Constant.swp8, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Date is not selected" + "\n" + e);
			System.out.println("Date is not selected");
			ExcelUtils.setCellData("Failed", Constant.swp10, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "checkKeyInfo is not Clicked")
	public void swp_TC11() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_chkKeyInfo")));
			el1.click();
			Thread.sleep(2000);

			Log.info("checkKeyInfo is Clicked");
			System.out.println("checkKeyInfo is Clicked");
			ExcelUtils.setCellData("Passed", Constant.swp11, Constant.Result);
			// assertTrue(el1.isSelected());

		} catch (Exception e) {
			Log.error("checkKeyInfo is not Clicked" + "\n" + e);
			System.out.println("checkKeyInfo is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.swp11, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Next is Clicked")
	public void swp_TC12() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_lbtnWithdrawlDetailNext")));
			el1.click();
			Thread.sleep(3000);

			Log.info("Next is Clicked");
			System.out.println("Next is Clicked");
			ExcelUtils.setCellData("Passed", Constant.swp12, Constant.Result);
			// assertTrue(el1.isSelected());

		} catch (Exception e) {
			Log.error("Next is not Clicked" + "\n" + e);
			System.out.println("Next is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.swp12, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Advisor is selected")
	public void swp_TC13() throws Exception {
		try {
			DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlAdvDetailAdvisorName"));
			DriverClass.getdriver().manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
			Select year = new Select(DriverClass.getdriver().findElement(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_ddlAdvDetailAdvisorName")));
			year.selectByVisibleText(ExcelUtils.getCellData(Constant.swp13, Constant.InputData).trim());
			// 2019
			Log.info("Advisor is selected");
			System.out.println("Advisor is selected");// 28th

			ExcelUtils.setCellData("Passed", Constant.swp13, Constant.Result);
			// assertEquals(year.getFirstSelectedOption().getText(),
			// ExcelUtils.getCellData(Constant.swp8, Constant.InputData).trim());

		} catch (Exception e) {
			Log.error("Date is not selected" + "\n" + e);
			System.out.println("Date is not selected");
			ExcelUtils.setCellData("Failed", Constant.swp13, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "ARN Code is Entered")
	public void swp_TC14() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_txtAdvDetailARN")));
			el1.clear();
			Thread.sleep(2000);

			el1.sendKeys(ExcelUtils.getCellData(Constant.swp14, Constant.InputData).trim());
			Thread.sleep(2000);

			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Thread.sleep(1500);
			Log.info("ARN Code is  Entered");
			System.out.println("ARN Code is  Entered");
			ExcelUtils.setCellData("Passed", Constant.swp14, Constant.Result);

			// String text = el1.getAttribute("value");
			// assertEquals(text, "40000");

		} catch (Exception e) {
			Log.error("ARN Code is  Entered" + "\n" + e);
			System.out.println("ARN Code is  not Entered");
			ExcelUtils.setCellData("Failed", Constant.swp14, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Next is Clicked")
	public void swp_TC15() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_lbtnAdvDetailNext")));
			el1.click();
			Thread.sleep(3000);

			Log.info("Next is Clicked");
			System.out.println("Next is Clicked");
			ExcelUtils.setCellData("Passed", Constant.swp15, Constant.Result);
			// assertTrue(el1.isSelected());

			

			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
		} catch (Exception e) {
			Log.error("Next is not Clicked" + "\n" + e);
			System.out.println("Next is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.swp15, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Confirm is Clicked")
	public void swp_TC16() throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions.presenceOfElementLocated(
					By.id("ctl00_m_g_c5333b05_15d4_43bd_a8b2_5a870cb2c243_ctl00_SWP1_lbtnConfirmDetailsConfirm")));
			el1.click();
			Thread.sleep(3000);

			Log.info("Confirm is Clicked");
			System.out.println("Confirm is Clicked");
			ExcelUtils.setCellData("Passed", Constant.switch16, Constant.Result);
			//assertTrue(el1.isSelected());

			

			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
		} catch (Exception e) {
			Log.error("Confirm is not Clicked" + "\n" + e);
			System.out.println("Confirm is not Clicked");
			ExcelUtils.setCellData("Failed", Constant.switch16, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.SwitchFailedSnapShot);
			e.printStackTrace();
		}
	}

	@Test(description = "Screen Shot is Taken and saved")
	public void swp_TC17() throws Exception {
		try {
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpSuccessSnapShot);
			DriverClass.getdriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println("Screen Shot is Taken and saved");
			ExcelUtils.setCellData("Passed", Constant.switch17, Constant.Result);
			Log.info("swp is Successfully Completed,Thank you");
			System.out.println("swp is Successfully Completed,Thank you");
		} catch (Exception e) {
			Log.error("Some error occured , not successfull" + "\n" + e);
			System.out.println("Some error occured , not successfull");
			ExcelUtils.setCellData("Failed", Constant.switch17, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.swpFailedSnapShot);
			e.printStackTrace();
		}

	}

	@Test(description = "SetDriver")
	public void swp_TC18() throws Exception {

		try {
			DriverClass.setDriver(DriverClass.getdriver());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
