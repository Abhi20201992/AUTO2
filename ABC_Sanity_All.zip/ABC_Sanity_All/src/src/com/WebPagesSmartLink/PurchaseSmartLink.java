package src.com.WebPagesSmartLink;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import log4j.Log;
import src.com.ExcelInputOutput.Constant;
import src.com.ExcelInputOutput.ExcelUtils;
import src.com.ScreenShot.TakeScreenShot;
import src.com.WebPagesLogged.DriverClass;

public class PurchaseSmartLink {
	
	@BeforeClass
	public void beforeTest() throws Exception {
		DOMConfigurator.configure("log4j.xml");
		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Purchase Smart Link");
	}

	@AfterClass
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
	}
	
	@Test(description = "Clicked on Smart Link")
	public void purchaseSmartLink_TC01() throws Exception {
		try {
			
			DriverClass.getdriver().manage().deleteAllCookies();

			DriverClass.getdriver().manage().window().maximize();

			Runtime.getRuntime().exec(Constant.BrowserAuth);

			DriverClass.getdriver().get(ExcelUtils.getCellData(Constant.TC01, Constant.InputData));
			
			Thread.sleep(3000);
			Log.info("Clicked on Smart Link");
			System.out.println("Clicked on Smart Link");
			ExcelUtils.setCellData("Passed", Constant.TC01, Constant.Result);
		    //assertTrue(el1.isEnabled());

		} catch (Exception e) {
			Log.error("Not Clicked on Smart Link" + "\n" + e);
			System.out.println("Not Clicked on Smart Link");
			ExcelUtils.setCellData("Failed", Constant.TC01, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.PurchaseSmartLinkFailedSnapShot);
			e.printStackTrace();
		}
	}
	
	
	@Test(description = "Generate OTP is clicked")
	public void purchaseSmartLink_TC02() throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(DriverClass.getdriver(), 20);
			WebElement el1 = wait.until(ExpectedConditions
					.presenceOfElementLocated(By.id("ctl00_m_g_cb367d0a_b222_4a95_aeee_07da16beb54f_ctl00_btnSubmit")));

			el1.click();
			Thread.sleep(3000);

			
			try {
			    wait.until(ExpectedConditions.alertIsPresent());
				DriverClass.getdriver().switchTo().alert().accept();
				System.out.println("\n Alert appeared, accepted here");
			    Log.info("\n Alert appeared accepted here");
			}catch(Exception e) {
				System.out.println("No Alert Present....Proceeding Further");
			}
			
			
			Log.info("Generate OTP is clicked");
			System.out.println("Generate OTP is clicked");
			ExcelUtils.setCellData("Passed", Constant.TC02, Constant.Result);
			// assertEquals("Pages - AccountStatement",DriverClass.getdriver().getTitle(),"
			// Incorrect Page Opened");

		} catch (Exception e) {

			Log.error("Generate OTP is not clicked" + "\n" + e);
			System.out.println("Generate OTP is not clicked");
			ExcelUtils.setCellData("Failed", Constant.TC01, Constant.Result);
			TakeScreenShot.takeScreenShot(DriverClass.getdriver(), Constant.PurchaseSmartLinkFailedSnapShot);
			e.printStackTrace();
		}
	}
	
	
	

}
