package src.com.Lib.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Set;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;

import log4j.Log;

public class RestExecutor {
	private HttpClient client;
	private String url;

	// Constructor for RestExecutor // @param url

	public RestExecutor(String url) {
		client = HttpClientBuilder.create().build();
		this.url = url;
	}

	// Executes POST req and returns response json. @param path @param headers

	public void post(HashMap<String, String> headers, String jsonContent, String contentType) {
		HttpPost post = new HttpPost(url);
		RestResponse resResponse = new RestResponse();
		StringBuffer responseString = new StringBuffer();

		try {
			if (headers != null) {
				Set<String> keys = headers.keySet();
				for (String key : keys) {
					post.addHeader(key, headers.get(key));
				}
			}

			// Setting the json content and content type.

			StringEntity input = new StringEntity(jsonContent);
			input.setContentType(contentType);
			post.setEntity(input);

			long startTime = System.currentTimeMillis();
			HttpResponse response = client.execute(post);
			long elapsedTime = System.currentTimeMillis() - startTime;

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			String line = "";
			while ((line = rd.readLine()) != null) {
				responseString.append(line);
			}
			resResponse.setResponseBody(responseString.toString());
			resResponse.setResponseCode(response.getStatusLine().getStatusCode());
			resResponse.setResponseMessage(response.getStatusLine().getReasonPhrase());
			resResponse.setResponseTime(elapsedTime);

			Header[] rheaders = response.getAllHeaders();
			for (Header header : rheaders) {
				resResponse.setHeader(header.getName(), header.getValue());
			}
		} catch (Exception e) {
			e.printStackTrace(); // handle
		} finally {
			// Release the connection.
			post.releaseConnection();
			System.out.println("\n Connection is released");
			Log.info("\n Connection is released");
		}

	}

}
