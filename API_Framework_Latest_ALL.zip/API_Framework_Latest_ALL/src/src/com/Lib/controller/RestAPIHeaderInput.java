package src.com.Lib.controller;

import java.util.HashMap;
import log4j.Log;
import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;

public class RestAPIHeaderInput {
	public static HashMap<String, String> restHeaderInput(int iTestRow) throws Exception {

		HashMap<String, String> map = new HashMap<>();
		try {
			String One = ExcelUtils.getCellData(iTestRow, Constant.Col_Checksum).trim();
			String Two = ExcelUtils.getCellData(iTestRow, Constant.Col_ChecksumValue).trim();
			String Three = ExcelUtils.getCellData(iTestRow, Constant.Col_Datetimestamp).trim();
			String Fourth = ExcelUtils.getCellData(iTestRow, Constant.Col_DatetimestampValue).trim();

			map.put(One, Two);
			map.put(Three, Fourth);

			System.out.print("Checksum to be given as header is :" + map);
			Log.info("Checksum to be given as header is :" + map);
		} catch (Exception e) {

			Log.error("\n" + "Getting Error in Headers" + "\n" + e);
			System.out.println("\n" + "Getting Error in Headers");
			e.printStackTrace();
		}

		return map;
	}
}
