package src.com.Lib.controller;

import java.util.HashMap;

public class RestResponse {

	private static int responseCode;
	private static String responseBody;
	private static HashMap<String, String> headers;
	private static String responseMessage;
	private static long responseTime;
	

	public RestResponse() {
		headers = new HashMap<String, String>();
	}

	public static int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		RestResponse.responseCode = responseCode;
	}

	public static String getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(String responseBody) {
		RestResponse.responseBody = responseBody;
	}

	public static HashMap<String, String> getHeaders() {
		return headers;
	}

	public static String getHeader(String name) {
		return headers.get(name);
	}

	public void setHeader(String name, String value) {
		RestResponse.headers.put(name, value);
	}

	public static String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		RestResponse.responseMessage = responseMessage;
	}

	public static long getRestResponseTime() {

		return responseTime;
	}

	public void setResponseTime(long responseTime) {
		RestResponse.responseTime = responseTime;
	}

}
