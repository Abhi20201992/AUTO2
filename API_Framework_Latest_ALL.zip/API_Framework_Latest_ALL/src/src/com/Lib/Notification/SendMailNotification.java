package src.com.Lib.Notification;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import log4j.Log;
import src.com.Lib.ExcelInputOutput.Constant;

public class SendMailNotification {

	public static void mailSend(String messageTosend) {
		String to = Constant.MailTo;
		String from = Constant.MailFrom;
		String host = Constant.smtpHost;// or IP address
		String subject = Constant.subject;

		// Get the session object
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		Session session = Session.getDefaultInstance(properties);

		// compose the message
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setSubject(subject);
			//message.setText("\n Hi");
			//message.setText("\n This is automation testing messege ");
			message.setText(messageTosend);
			//message.setText("\n (Note-This is automatic generated email during Automation Excecution)");
			//message.setText("\n\n Regards,\nQA Team ");
		
			// Send message
			Transport.send(message);

			Log.info("Message body in mail is sent as " + message);
			System.out.println("Message body in mail is sent as " + message);

		} catch (MessagingException mex) {
			Log.error("Mail sending is Failed " + "due to" + mex);
			System.out.println("Mail sending is Failed");
			mex.printStackTrace();
		}
	}

}
