package src.com.Lib.ExcelInputOutput;

public class Constant {

	public static final String Path_TestData = System.getProperty("user.dir")+"\\ExcelTestCasesInputFiles\\";
	//public static final String File_TestData = "APITesting.xlsx";
	public static String File_TestData ;
	
	
	public static String getfile_TestData() {
		return File_TestData;
	}	
	
	
	public static String setfile_TestData(String FileNameWithExtn) {
		return Constant.File_TestData=FileNameWithExtn;
	}
	
	
	
	//Email Notification Constants
	public static final String MailTo="vishal.sharma2@adityabirlacapital.com,kumarRaja.arja@adityabirlacapital.com,abhijay.ghadyale@adityabirlacapital.com,sayantan.chatterjee@adityabirlacapital.com";
	public static final String MailFrom="Automation_Testing_Team@adityabirlacapital.com";
	public static final String smtpHost="smtp.bsli.com";
	public static final String subject = "Automation Status(automatically generated email)";
	
	
	
	// Test Data Sheet Columns
	public static final int Col_TestCaseName = 0;
	public static final int Col_APIName = 1;
	public static final int Col_TestCaseId = 2;
	public static final int Col_TestCaseDescription = 3;
	public static final int Col_Checksum = 10;
	public static final int Col_ChecksumValue = 11;
	public static final int Col_Datetimestamp = 12;
	public static final int Col_DatetimestampValue = 13;
	public static final int Col_URL = 14;
	public static final int Col_JsonInput = 18;
	public static final int Col_ExpectedResponseCode = 19;
	public static final int Col_ExpectedResponseMessage = 20;
	public static final int Col_ExpectedHeaders = 21;
	public static final int Col_ExpectedResponseBody = 22;
	public static final int Col_ExpectedCode = 23;
	public static final int Col_ActualResponseCode = 28;
	public static final int Col_ActualResponseMessage = 29;
	public static final int Col_ActualHeaders = 30;
	public static final int Col_ActualResponseBody = 31;
	public static final int Col_ActualResponseTime = 32;
	public static final int Col_Result = 36;

}