package src.com.Lib.test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.util.HashMap;

import org.apache.http.client.ClientProtocolException;

import log4j.Log;
import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.Notification.SendMailNotification;
import src.com.Lib.controller.RestAPIHeaderInput;
import src.com.Lib.controller.RestExecutor;
import src.com.Lib.controller.RestResponse;

public class APIOperation {



	public static void post_apiOperationNoHeaderRegression(int iTestRow) throws Exception, ClientProtocolException {
		try {
			
			String APIName = ExcelUtils.getCellData(iTestRow, Constant.Col_APIName).trim();

			Log.info("# API Testing for " + APIName + " having Test Case ID as "
					+ ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId) + " is Started ");
			final String URL = ExcelUtils.getCellData(iTestRow, Constant.Col_URL).trim();
			RestExecutor executor;
			// Initialize RestExecutor object using the end point URL
			executor = new RestExecutor(URL);
			String TestCaseID = ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId).trim();
			
			Log.info("\n" + APIName + "\n" + TestCaseID);
			

			String input = ExcelUtils.getCellData(iTestRow, Constant.Col_JsonInput);
			// Log.info(input);

			executor.post(null, input, "application/json");
			Log.info("URL is posted with json");

			Log.info("\n" + RestResponse.getResponseCode());
			ExcelUtils.setCellData(String.valueOf(RestResponse.getResponseCode()), iTestRow,
					Constant.Col_ActualResponseCode);
			Log.info("Response Code is received");

			Log.info("\n" + RestResponse.getResponseMessage());
			ExcelUtils.setCellData(RestResponse.getResponseMessage(), iTestRow, Constant.Col_ActualResponseMessage);
			Log.info("Response Message is received");

			Log.info("\n" + RestResponse.getHeaders());
			ExcelUtils.setCellData(RestResponse.getHeaders().toString(), iTestRow, Constant.Col_ActualHeaders);
			Log.info("Response Headers are received");

			Log.info("\n" + RestResponse.getResponseBody());
			ExcelUtils.setCellData(RestResponse.getResponseBody(), iTestRow, Constant.Col_ActualResponseBody);
			Log.info("Response Body is received");

			boolean obj0 = (ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseCode))
					.equals((ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseCode)));

			boolean obj1 = (ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseMessage))
					.equals(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseMessage));

			String stringCmp = ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedCode);
			Log.info(stringCmp);

			boolean obj3 = (ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseBody)).contains(stringCmp);

			Log.info("Result of Comparing Expected ResponseCode with Actual Response Code is" + obj0);
			Log.info("Result of Comparing Expected Message with Actual Response Message is" + obj1);
			Log.info("Result of Do ExpectedCode is present in  Actual Response Body is" + obj3);

			if (obj0) {
				Log.info("\n" + "status code is as expected");
				Log.info("Status code is verified");
			}
			if (obj1) {
				Log.info("\n" + "Response message is as expected");
				Log.info("Response message is verified");
			}
			if (obj3) {
				Log.info("\n" + "Response body is as expected");
				Log.info("Response body is verified");
			} else {
				Log.info("\n" + "Response body is NOT as expected");
				Log.info("Response body is verified,nOT AS eXPECTED ");

			}
			if (obj0 && obj1 && obj3) {
				ExcelUtils.setCellData("Passed", iTestRow, Constant.Col_Result);
				Log.info("\n" + "Result is entered as Passed");
				Log.info("Result is entered as Passed");
			} else {
				ExcelUtils.setCellData("Failed", iTestRow, Constant.Col_Result);
				Log.info("\n" + "Result is entered as failed");
				Log.info("Result is entered as failed");
				SendMailNotification.mailSend("Hi,\n\n Error occured in API  "+ APIName +"\n\n Test Case ID \n"+ TestCaseID +"\n\n Url of API as \n "+ URL +"\n \n Input Json is \n"+ input +"\n \n Output Received (code and body)\n"+ RestResponse.getResponseCode() +"\n \n"+ RestResponse.getResponseBody().toString() +"\n \n But Expected Response body is:\n" + ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseBody));
			}

			ExcelUtils.setCellData(String.valueOf(RestResponse.getRestResponseTime()), iTestRow,
					Constant.Col_ActualResponseTime);
			Log.info("\n" + String.valueOf(RestResponse.getRestResponseTime()) + "  Milliseconds");

			Log.info("API Testing for " + APIName + ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId)
					+ "is Done");
			
			assertEquals((ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseCode)),
					(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseCode)));
			assertEquals((ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseMessage)),
					(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseMessage)));
			assertThat((ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseBody)), containsString(stringCmp));
			
			Log.info("\n" + "---------------------------************---------------------------------------------------------------");
			Log.info("\n" + "---------------------------************---------------------------------------------------------------");
		} catch (Exception e) {
			Log.error("\n" + "Getting Error " + "\n as" + e);
			Log.info("\n" + "---------------------------************---------------------------------------------------------------");
			Log.info("\n" + "---------------------------************---------------------------------------------------------------");
			e.printStackTrace();
		}
	}

	public static void post_apiOperationWithHeaderRegression(int iTestRow) throws Exception, ClientProtocolException {

		String APIName = ExcelUtils.getCellData(iTestRow, Constant.Col_APIName).trim();
		Log.info("# API Testing for " + APIName + " having Test Case ID as "
				+ ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId) + " is Started ");
	
		final String URL = ExcelUtils.getCellData(iTestRow, Constant.Col_URL).trim();

		RestExecutor executor;
		// Initialize RestExecutor object using the end point URL

		executor = new RestExecutor(URL);

		String TestCaseID = ExcelUtils.getCellData(iTestRow, 2).trim();
		Log.info("\n" + APIName + "\n" + TestCaseID);

		String input = ExcelUtils.getCellData(iTestRow, Constant.Col_JsonInput);
		// Log.info(input);

		HashMap<String, String> headers = RestAPIHeaderInput.restHeaderInput(iTestRow);
		executor.post(headers, input, "application/json");
		Log.info("URL is posted with json");

		Log.info("\n" + RestResponse.getResponseCode());
		ExcelUtils.setCellData(String.valueOf(RestResponse.getResponseCode()), iTestRow,
				Constant.Col_ActualResponseCode);
		Log.info("Response Code is received");

		Log.info("\n" + RestResponse.getResponseMessage());
		ExcelUtils.setCellData(RestResponse.getResponseMessage(), iTestRow, Constant.Col_ActualResponseMessage);
		Log.info("Response Message is received");

		Log.info("\n" + RestResponse.getHeaders());
		ExcelUtils.setCellData(RestResponse.getHeaders().toString(), iTestRow, Constant.Col_ActualHeaders);
		Log.info("Response Headers are received");

		Log.info("\n" + RestResponse.getResponseBody());
		ExcelUtils.setCellData(RestResponse.getResponseBody(), iTestRow, Constant.Col_ActualResponseBody);
		Log.info("Response Body is received");

		boolean obj0 = (ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseCode))
				.equals((ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseCode)));

		boolean obj1 = (ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseMessage))
				.equals(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseMessage));

		String stringCmp = ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedCode);
		Log.info(stringCmp);

		boolean obj3 = (ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseBody)).contains(stringCmp);

		Log.info("Result of Comparing Expected ResponseCode with Actual Response Code is" + obj0);
		Log.info("Result of Comparing Expected Message with Actual Response Message is" + obj1);
		Log.info("Result of Do ExpectedCode is present in  Actual Response Body is" + obj3);

		if (obj0) {
			Log.info("\n" + "status code is as expected");
			Log.info("Status code is verified");
		}
		if (obj1) {
			Log.info("\n" + "Response message is as expected");
			Log.info("Response message is verified");
		}
		if (obj3) {
			Log.info("\n" + "Response body is as expected");
			Log.info("Response body is verified");
		} else {
			Log.info("\n" + "Response body is NOT as expected");
			Log.info("Response body is verified,nOT AS eXPECTED ");

		}
		if (obj0 && obj1 && obj3) {
			ExcelUtils.setCellData("Passed", iTestRow, Constant.Col_Result);
			Log.info("\n" + "Result is entered as Passed");
			Log.info("Result is entered as Passed");
		} else {
			ExcelUtils.setCellData("Failed", iTestRow, Constant.Col_Result);
			Log.info("\n" + "Result is entered as failed");
			Log.info("Result is entered as failed");
			SendMailNotification.mailSend("Hi,\n\n Error occured in API  "+ APIName +"\n\n Test Case ID \n"+ TestCaseID +"\n\n Url of API as \n "+ URL +"\n \n Headers are as: \n"+ headers +"\n \n Input Json is \n"+ input +"\n \n Output Received (code and body)\n"+ RestResponse.getResponseCode() +"\n \n"+ RestResponse.getResponseBody().toString() +"\n \n But Expected Response body is:\n" + ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseBody));

		}

		ExcelUtils.setCellData(String.valueOf(RestResponse.getRestResponseTime()), iTestRow,
				Constant.Col_ActualResponseTime);
		Log.info("\n" + String.valueOf(RestResponse.getRestResponseTime()) + "  Milliseconds");

		Log.info("API Testing for " + APIName + ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId) + "is Done");
		
		assertEquals((ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseCode)),
				(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseCode)));
		assertEquals((ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseMessage)),
				(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseMessage)));
		assertThat((ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseBody)), containsString(stringCmp));
		Log.info("\n" + "---------------------------************---------------------------------------------------------------");
		Log.info("\n" + "---------------------------************---------------------------------------------------------------");
	}

	public static void post_apiOperationNoHeaderSanity(int iTestRow) throws Exception, ClientProtocolException {
		try {
			String APIName = ExcelUtils.getCellData(iTestRow, Constant.Col_APIName).trim();
			Log.info("# API Testing for " + APIName + " having Test Case ID as "
					+ ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId) + " is Started ");
			
			final String URL = ExcelUtils.getCellData(iTestRow, Constant.Col_URL).trim();

			RestExecutor executor;
			// Initialize RestExecutor object using the end point URL

			executor = new RestExecutor(URL);

			String TestCaseID = ExcelUtils.getCellData(iTestRow, 2).trim();
			Log.info("\n" + APIName + "\n" + TestCaseID);

			String input = ExcelUtils.getCellData(iTestRow, Constant.Col_JsonInput);
			// Log.info(input);

			executor.post(null, input, "application/json");
			Log.info("URL is posted with json");

			Log.info("\n" + RestResponse.getResponseCode());
			ExcelUtils.setCellData(String.valueOf(RestResponse.getResponseCode()), iTestRow,
					Constant.Col_ActualResponseCode);
			Log.info("Response Code is received");

			Log.info("\n" + RestResponse.getResponseMessage());
			ExcelUtils.setCellData(RestResponse.getResponseMessage(), iTestRow, Constant.Col_ActualResponseMessage);
			Log.info("Response Message is received");

			Log.info("\n" + RestResponse.getHeaders());
			ExcelUtils.setCellData(RestResponse.getHeaders().toString(), iTestRow, Constant.Col_ActualHeaders);
			Log.info("Response Headers are received");

			Log.info("\n" + RestResponse.getResponseBody());
			ExcelUtils.setCellData(RestResponse.getResponseBody(), iTestRow, Constant.Col_ActualResponseBody);
			Log.info("Response Body is received");

			ExcelUtils.setCellData(String.valueOf(RestResponse.getRestResponseTime()), iTestRow,
					Constant.Col_ActualResponseTime);
			Log.info("\n" + String.valueOf(RestResponse.getRestResponseTime()) + "  Milliseconds");

			Log.info("API Testing for " + APIName + ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId)
					+ "is Done");
			Log.info("\n" + "---------------------------************---------------------------------------------------------------");
			Log.info("\n" + "---------------------------************---------------------------------------------------------------");	
			} catch (Exception e) {
			Log.error("\n" + "API Code is getting Error " + "\n" + e);
			Log.info("\n" + "API Code is getting Error ");
			e.printStackTrace();
		}

	}

	

	public static void post_apiOperationWithHeaderSanity(int iTestRow) throws Exception, ClientProtocolException {
		try {
			String APIName = ExcelUtils.getCellData(iTestRow, Constant.Col_APIName).trim();
			Log.info("# API Testing for " + APIName + " having Test Case ID as "
					+ ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId) + " is Started ");
			
			final String URL = ExcelUtils.getCellData(iTestRow, Constant.Col_URL).trim();

			RestExecutor executor;
			// Initialize RestExecutor object using the end point URL

			executor = new RestExecutor(URL);

			String TestCaseID = ExcelUtils.getCellData(iTestRow, 2).trim();
			Log.info("\n" + APIName + "\n" + TestCaseID);

			String input = ExcelUtils.getCellData(iTestRow, Constant.Col_JsonInput);
			// Log.info(input);

			HashMap<String, String> headers = RestAPIHeaderInput.restHeaderInput(iTestRow);
			executor.post(headers, input, "application/json");
			Log.info("URL is posted with json");

			Log.info("\n" + RestResponse.getResponseCode());
			ExcelUtils.setCellData(String.valueOf(RestResponse.getResponseCode()), iTestRow,
					Constant.Col_ActualResponseCode);
			Log.info("Response Code is received");

			Log.info("\n" + RestResponse.getResponseMessage());
			ExcelUtils.setCellData(RestResponse.getResponseMessage(), iTestRow, Constant.Col_ActualResponseMessage);
			Log.info("Response Message is received");

			Log.info("\n" + RestResponse.getHeaders());
			ExcelUtils.setCellData(RestResponse.getHeaders().toString(), iTestRow, Constant.Col_ActualHeaders);
			Log.info("Response Headers are received");

			Log.info("\n" + RestResponse.getResponseBody());
			ExcelUtils.setCellData(RestResponse.getResponseBody(), iTestRow, Constant.Col_ActualResponseBody);
			Log.info("Response Body is received");

			ExcelUtils.setCellData(String.valueOf(RestResponse.getRestResponseTime()), iTestRow,
					Constant.Col_ActualResponseTime);
			Log.info("\n" + String.valueOf(RestResponse.getRestResponseTime()) + "  Milliseconds");

			Log.info("API Testing for " + APIName + ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId)
					+ "is Done");
			Log.info("\n" + "---------------------------************---------------------------------------------------------------");
			Log.info("\n" + "---------------------------************---------------------------------------------------------------");} catch (Exception e) {
			Log.error("\n" + "API Code is getting Error " + "\n" + e);
			Log.info("\n" + "API Code is getting Error ");
			e.printStackTrace();
		}
	}

	public static void post_apiOperationWithHeaderRegressionLargeOutput(int iTestRow)
			throws Exception, ClientProtocolException {
		try {
			String APIName = ExcelUtils.getCellData(iTestRow, Constant.Col_APIName).trim();
			Log.info("# API Testing for " + APIName + " having Test Case ID as "
					+ ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId) + " is Started ");
			final String URL = ExcelUtils.getCellData(iTestRow, Constant.Col_URL).trim();

			RestExecutor executor;
			// Initialize RestExecutor object using the end point URL

			executor = new RestExecutor(URL);

			String TestCaseID = ExcelUtils.getCellData(iTestRow, 2).trim();
			Log.info("\n" + APIName + "\n" + TestCaseID);

			String input = ExcelUtils.getCellData(iTestRow, Constant.Col_JsonInput);
			// Log.info(input);

			HashMap<String, String> headers = RestAPIHeaderInput.restHeaderInput(iTestRow);
			executor.post(headers, input, "application/json");
			Log.info("URL is posted with json");

			Log.info("\n" + RestResponse.getResponseCode());
			ExcelUtils.setCellData(String.valueOf(RestResponse.getResponseCode()), iTestRow,
					Constant.Col_ActualResponseCode);
			Log.info("Response Code is received");

			Log.info("\n" + RestResponse.getResponseMessage());
			ExcelUtils.setCellData(RestResponse.getResponseMessage(), iTestRow, Constant.Col_ActualResponseMessage);
			Log.info("Response Message is received");

			Log.info("\n" + RestResponse.getHeaders());
			ExcelUtils.setCellData(RestResponse.getHeaders().toString(), iTestRow, Constant.Col_ActualHeaders);
			Log.info("Response Headers are received");

			Log.info("\n" + RestResponse.getResponseBody());
			// ExcelUtils.setCellData(RestResponse.getResponseBody(), iTestRow,
			// Constant.Col_ActualResponseBody);
			Log.info("Response Body is received");

			boolean obj0 = (ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseCode))
					.equals((ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseCode)));

			boolean obj1 = (ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseMessage))
					.equals(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseMessage));

			String stringCmp = ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedCode);
			Log.info(stringCmp);

			boolean obj3 = (RestResponse.getResponseBody().contains(stringCmp));

			Log.info("Result of Comparing Expected ResponseCode with Actual Response Code is" + obj0);
			Log.info("Result of Comparing Expected Message with Actual Response Message is" + obj1);
			Log.info("Result of Do ExpectedCode is present in  Actual Response Body is" + obj3);

			if (obj0) {
				Log.info("\n" + "status code is as expected");
				Log.info("Status code is verified");
			}
			if (obj1) {
				Log.info("\n" + "Response message is as expected");
				Log.info("Response message is verified");
			}
			if (obj3) {
				Log.info("\n" + "Response body is as expected");
				Log.info("Response body is verified");
			} else {
				Log.info("\n" + "Response body is NOT as expected");
				Log.info("Response body is verified,nOT AS eXPECTED ");

			}
			if (obj0 && obj1 && obj3) {
				ExcelUtils.setCellData("Passed", iTestRow, Constant.Col_Result);
				Log.info("\n" + "Result is entered as Passed");
				Log.info("Result is entered as Passed");
			} else {
				ExcelUtils.setCellData("Failed", iTestRow, Constant.Col_Result);
				Log.info("\n" + "Result is entered as failed");
				Log.info("Result is entered as failed");
				SendMailNotification.mailSend("Hi,\n\n Error occured in API  "+ APIName +"\n\n Test Case ID \n"+ TestCaseID +"\n\n Url of API as \n "+ URL +"\n \n Headers are as: \n"+ headers +"\n \n Input Json is \n"+ input +"\n \n Output Received (code and body)\n"+ RestResponse.getResponseCode() +"\n \n"+ RestResponse.getResponseBody().toString() +"\n \n But Expected Response body is:\n" + ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseBody));

			}

			ExcelUtils.setCellData(String.valueOf(RestResponse.getRestResponseTime()), iTestRow,
					Constant.Col_ActualResponseTime);
			Log.info("\n" + String.valueOf(RestResponse.getRestResponseTime()) + "  Milliseconds");

			Log.info("API Testing for " + APIName + ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId)
					+ "is Done");
			

			assertEquals((ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseCode)),
					(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseCode)));
			assertEquals((ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseMessage)),
					(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseMessage)));
			assertThat((RestResponse.getResponseBody()), containsString(stringCmp));

			Log.info("\n" + "---------------------------************---------------------------------------------------------------");
			Log.info("\n" + "---------------------------************---------------------------------------------------------------");
		} catch (Exception e) {
			Log.error("\n" + "API Code is getting Error " + "\n" + e);
			Log.info("\n" + "API Code is getting Error ");
			e.printStackTrace();
		}
	}

	public static void post_apiOperationNoHeaderRegressionLargeOutput(int iTestRow)
			throws Exception, ClientProtocolException {
		try {
			String APIName = ExcelUtils.getCellData(iTestRow, Constant.Col_APIName).trim();

			Log.info("# API Testing for " + APIName + " having Test Case ID as "
					+ ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId) + " is Started ");
			final String URL = ExcelUtils.getCellData(iTestRow, Constant.Col_URL).trim();

			RestExecutor executor;
			// Initialize RestExecutor object using the end point URL

			executor = new RestExecutor(URL);

			String TestCaseID = ExcelUtils.getCellData(iTestRow, 2).trim();
			Log.info("\n" + APIName + "\n" + TestCaseID);

			String input = ExcelUtils.getCellData(iTestRow, Constant.Col_JsonInput);
			// Log.info(input);

			executor.post(null, input, "application/json");
			Log.info("URL is posted with json");

			Log.info("\n" + RestResponse.getResponseCode());
			ExcelUtils.setCellData(String.valueOf(RestResponse.getResponseCode()), iTestRow,
					Constant.Col_ActualResponseCode);
			Log.info("Response Code is received");

			Log.info("\n" + RestResponse.getResponseMessage());
			ExcelUtils.setCellData(RestResponse.getResponseMessage(), iTestRow, Constant.Col_ActualResponseMessage);
			Log.info("Response Message is received");

			Log.info("\n" + RestResponse.getHeaders());
			ExcelUtils.setCellData(RestResponse.getHeaders().toString(), iTestRow, Constant.Col_ActualHeaders);
			Log.info("Response Headers are received");

			Log.info("\n" + RestResponse.getResponseBody());
			// ExcelUtils.setCellData(RestResponse.getResponseBody(), iTestRow,
			// Constant.Col_ActualResponseBody);
			Log.info("Response Body is received");

			boolean obj0 = (ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseCode))
					.equals((ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseCode)));

			boolean obj1 = (ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseMessage))
					.equals(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseMessage));

			String stringCmp = ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedCode);
			Log.info(stringCmp);

			boolean obj3 = (RestResponse.getResponseBody().contains(stringCmp));

			Log.info("Result of Comparing Expected ResponseCode with Actual Response Code is" + obj0);
			Log.info("Result of Comparing Expected Message with Actual Response Message is" + obj1);
			Log.info("Result of Do ExpectedCode is present in  Actual Response Body is" + obj3);

			if (obj0) {
				Log.info("\n" + "status code is as expected");
				Log.info("Status code is verified");
			}
			if (obj1) {
				Log.info("\n" + "Response message is as expected");
				Log.info("Response message is verified");
			}
			if (obj3) {
				Log.info("\n" + "Response body is as expected");
				Log.info("Response body is verified");
			} else {
				Log.info("\n" + "Response body is NOT as expected");
				Log.info("Response body is verified,nOT AS eXPECTED ");

			}
			if (obj0 && obj1 && obj3) {
				ExcelUtils.setCellData("Passed", iTestRow, Constant.Col_Result);
				Log.info("\n" + "Result is entered as Passed");
				Log.info("Result is entered as Passed");
			} else {
				ExcelUtils.setCellData("Failed", iTestRow, Constant.Col_Result);
				Log.info("\n" + "Result is entered as failed");
				Log.info("Result is entered as failed");
				SendMailNotification.mailSend("Hi,\n\n Error occured in API  "+ APIName +"\n\n Test Case ID \n"+ TestCaseID +"\n\n Url of API as \n "+ URL +"\n \n Input Json is \n"+ input +"\n \n Output Received (code and body)\n"+ RestResponse.getResponseCode() +"\n \n"+ RestResponse.getResponseBody().toString() +"\n \n But Expected Response body is:\n" + ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseBody));

			}

			ExcelUtils.setCellData(String.valueOf(RestResponse.getRestResponseTime()), iTestRow,
					Constant.Col_ActualResponseTime);
			Log.info("\n" + String.valueOf(RestResponse.getRestResponseTime()) + "  Milliseconds");

			Log.info("API Testing for " + APIName + ExcelUtils.getCellData(iTestRow, Constant.Col_TestCaseId)
					+ "is Done");
			
			assertEquals((ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseCode)),
					(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseCode)));
			assertEquals((ExcelUtils.getCellData(iTestRow, Constant.Col_ExpectedResponseMessage)),
					(ExcelUtils.getCellData(iTestRow, Constant.Col_ActualResponseMessage)));
			assertThat((RestResponse.getResponseBody()), containsString(stringCmp));

			Log.info("\n" + "---------------------------************---------------------------------------------------------------");
			Log.info("\n" + "---------------------------************---------------------------------------------------------------");
		} catch (Exception e) {
			Log.error("\n" + "Getting Error " + "\n as" + e);
			e.printStackTrace();
		}
	}
}