package src.com.API.LiquidAppModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SaveOTMRegistrationDetails {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("LiquidApp.xlsx"), "LiquidApp");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })

	public void SaveOTMRegistrationDetails_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(460);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(461);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(462);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(463);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(464);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(465);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(466);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(467);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(468);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(469);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(470);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(471);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(472);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(473);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(474);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(475);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(476);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(477);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(478);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(479);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(480);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(481);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(482);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(483);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(484);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_26() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(485);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_27() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(486);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_28() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(487);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_29() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(488);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void SaveOTMRegistrationDetails_TC_30() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(489);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
