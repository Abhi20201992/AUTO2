package src.com.API.LiquidAppModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class ValidateInvestor {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("LiquidApp.xlsx"), "LiquidApp");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })

	public void ValidateInvestor_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(163);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(164);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(165);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(166);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(167);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(168);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(169);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(170);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(171);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(172);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(173);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(174);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(175);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(176);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(177);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(178);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(179);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateInvestor_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(180);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
