package src.com.API.LiquidAppModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class ValidateEmailIdAndPAN {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("LiquidApp.xlsx"), "LiquidApp");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })

	public void ValidateEmailIdAndPAN_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(97);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(98);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(99);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(100);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(101);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(102);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(103);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(104);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(105);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(106);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(107);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(108);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(109);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void ValidateEmailIdAndPAN_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(110);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
