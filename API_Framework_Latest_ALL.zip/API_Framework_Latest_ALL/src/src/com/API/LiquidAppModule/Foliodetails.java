package src.com.API.LiquidAppModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class Foliodetails {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("LiquidApp.xlsx"), "LiquidApp");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })

	public void Foliodetails_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(360);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void Foliodetails_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(361);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void Foliodetails_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(362);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void Foliodetails_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(363);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void Foliodetails_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(364);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void Foliodetails_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(365);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void Foliodetails_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(366);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void Foliodetails_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(367);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void Foliodetails_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(368);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test

	public void Foliodetails_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(369);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
