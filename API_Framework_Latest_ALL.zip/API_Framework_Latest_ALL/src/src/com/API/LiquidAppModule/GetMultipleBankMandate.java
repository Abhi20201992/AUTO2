package src.com.API.LiquidAppModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetMultipleBankMandate {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("LiquidApp.xlsx"), "LiquidApp");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })

	public void GetMultipleBankMandate_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(390);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetMultipleBankMandate_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(391);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetMultipleBankMandate_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(392);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetMultipleBankMandate_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(393);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetMultipleBankMandate_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(394);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetMultipleBankMandate_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(395);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetMultipleBankMandate_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(396);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetMultipleBankMandate_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(397);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetMultipleBankMandate_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(398);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetMultipleBankMandate_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(399);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
