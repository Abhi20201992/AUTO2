package src.com.API.LiquidAppModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetTransationForFolioNo {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("LiquidApp.xlsx"), "LiquidApp");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })

	public void GetTransationForFolioNo_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(265);
			;
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetTransationForFolioNo_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(266);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetTransationForFolioNo_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(267);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetTransationForFolioNo_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(268);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetTransationForFolioNo_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(269);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetTransationForFolioNo_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(270);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetTransationForFolioNo_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(271);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetTransationForFolioNo_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(272);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetTransationForFolioNo_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(273);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetTransationForFolioNo_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(274);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void GetTransationForFolioNo_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(275);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
