package src.com.API.Group;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class DeleteGroup {
	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Group.xlsx"), "Group");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void getSchemeHistoricalReturn_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(74);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHistoricalReturn_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(75);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHistoricalReturn_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(76);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHistoricalReturn_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(77);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHistoricalReturn_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(78);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHistoricalReturn_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(79);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHistoricalReturn_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(83);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHistoricalReturn_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(84);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHistoricalReturn_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(85);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHistoricalReturn_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(86);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHistoricalReturn_TC_41() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(87);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHistoricalReturn_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(88);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
