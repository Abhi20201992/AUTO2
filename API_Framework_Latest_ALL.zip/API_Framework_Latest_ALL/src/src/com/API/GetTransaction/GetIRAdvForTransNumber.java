package src.com.API.GetTransaction;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetIRAdvForTransNumber {

	@BeforeMethod(groups= {"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("GetTransaction.xlsx"),
				"GetTransaction");
	}

	@Test(timeOut = 20000,groups= {"Sanity", "Regression"})
	public void getIRAdvForTransNumber_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(42);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void getIRAdvForTransNumber_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(43);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void getIRAdvForTransNumber_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(44);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void getIRAdvForTransNumber_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(45);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void getIRAdvForTransNumber_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(46);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void getIRAdvForTransNumber_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(47);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
