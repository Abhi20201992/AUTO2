package src.com.API.GetTransaction;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetAdvPurchaseTran {
	@BeforeMethod(groups= {"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("GetTransaction.xlsx"), "GetTransaction");
	}

	@Test(timeOut = 20000,groups= {"Sanity", "Regression"})
	public void getAdvPurchaseTran_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(158);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(timeOut = 20000,groups= { "Regression"})
	
	public void getAdvPurchaseTran_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(159);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getAdvPurchaseTran_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(160);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getAdvPurchaseTran_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(161);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(enabled = false)
	public void getAdvPurchaseTran_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(162);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(enabled = false)
	public void getAdvPurchaseTran_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(163);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
