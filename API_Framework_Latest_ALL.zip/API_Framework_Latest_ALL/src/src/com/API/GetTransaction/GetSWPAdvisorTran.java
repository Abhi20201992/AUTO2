package src.com.API.GetTransaction;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetSWPAdvisorTran {
	@BeforeMethod(groups= {"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("GetTransaction.xlsx"),
				"GetTransaction");
	}

	@Test(timeOut = 20000,groups= {"Sanity", "Regression"})
	public void getSWPAdvisorTran_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(84);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void getSWPAdvisorTran_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(85);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void getSWPAdvisorTran_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(86);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void getSWPAdvisorTran_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(87);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void getSWPAdvisorTran_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(88);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void getSWPAdvisorTran_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(89);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void getSWPAdvisorTran_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(90);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void getSWPAdvisorTran_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(91);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void getSWPAdvisorTran_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(92);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void getSWPAdvisorTran_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(93);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void getSWPAdvisorTran_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(94);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
