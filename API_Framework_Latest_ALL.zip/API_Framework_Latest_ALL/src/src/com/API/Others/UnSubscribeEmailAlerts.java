package src.com.API.Others;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class UnSubscribeEmailAlerts {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Others.xlsx"), "Others");
		
	}
		
	

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void unSubscribeEmailAlerts_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(458);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void unSubscribeEmailAlerts_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(459);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void unSubscribeEmailAlerts_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(460);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void unSubscribeEmailAlerts_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(461);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void unSubscribeEmailAlerts_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(462);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void unSubscribeEmailAlerts_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(463);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void unSubscribeEmailAlerts_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(464);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void unSubscribeEmailAlerts_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(465);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void unSubscribeEmailAlerts_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(466);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void unSubscribeEmailAlerts_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(467);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void unSubscribeEmailAlerts_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(468);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
