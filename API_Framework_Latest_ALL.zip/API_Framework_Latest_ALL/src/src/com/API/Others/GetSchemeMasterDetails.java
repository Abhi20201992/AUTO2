package src.com.API.Others;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetSchemeMasterDetails {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Others.xlsx"), "Others");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })

	public void getSchemeMasterDetails_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(125);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(126);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(127);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(128);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(129);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(130);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(131);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(132);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(133);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(134);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(135);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(136);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(137);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(138);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(139);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(140);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(141);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(142);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(143);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(144);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(145);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(146);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(147);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getSchemeMasterDetails_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(148);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
