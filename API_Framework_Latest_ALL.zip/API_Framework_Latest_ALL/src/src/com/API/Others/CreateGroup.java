package src.com.API.Others;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class CreateGroup {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Others.xlsx"), "Others");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void createGroup_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(383);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(384);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(385);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(386);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(387);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(388);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(389);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(390);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(391);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(392);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(393);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(394);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(395);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(396);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(397);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(398);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(399);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(400);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(401);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void createGroup_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(402);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
