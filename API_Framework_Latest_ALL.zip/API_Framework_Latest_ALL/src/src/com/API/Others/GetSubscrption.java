package src.com.API.Others;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetSubscrption {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Others.xlsx"), "Others");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void getSubscrption_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(550);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSubscrption_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(551);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSubscrption_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(552);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSubscrption_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(553);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSubscrption_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(554);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSubscrption_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(555);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSubscrption_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(556);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSubscrption_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(557);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSubscrption_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(558);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSubscrption_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(559);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void getSubscrption_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(560);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}