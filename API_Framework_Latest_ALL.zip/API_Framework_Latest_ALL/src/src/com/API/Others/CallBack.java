package src.com.API.Others;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class CallBack {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Others.xlsx"), "Others");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})

	public void callBack_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(235);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void callBack_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(236);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void callBack_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(237);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void callBack_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(238);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void callBack_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(239);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void callBack_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(240);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void callBack_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(241);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void callBack_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(242);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void callBack_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(243);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void callBack_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(244);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void callBack_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(245);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(enabled = false)
	public void callBack_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(246);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	@Test(timeOut=20000)
	public void callBack_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(247);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
