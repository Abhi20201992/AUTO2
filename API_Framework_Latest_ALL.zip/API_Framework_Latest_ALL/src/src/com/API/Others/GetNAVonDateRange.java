package src.com.API.Others;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetNAVonDateRange {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Others.xlsx"), "Others");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })

	public void getNAVonDateRange_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(198);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(199);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(200);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(201);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(202);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(203);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(204);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(205);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(206);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(207);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(208);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(209);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(210);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(211);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(212);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(213);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(214);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getNAVonDateRange_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(215);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
