package src.com.API.Others;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class UnSubscribeMobileAlerts {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Others.xlsx"), "Others");

	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void unsubscribeMobileAlerts_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(520);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void unsubscribeMobileAlerts_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(521);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void unsubscribeMobileAlerts_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(522);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void unsubscribeMobileAlerts_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(523);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void unsubscribeMobileAlerts_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(524);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void unsubscribeMobileAlerts_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(525);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void unsubscribeMobileAlerts_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(526);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void unsubscribeMobileAlerts_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(527);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void unsubscribeMobileAlerts_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(528);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void unsubscribeMobileAlerts_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(529);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void unsubscribeMobileAlerts_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(530);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
