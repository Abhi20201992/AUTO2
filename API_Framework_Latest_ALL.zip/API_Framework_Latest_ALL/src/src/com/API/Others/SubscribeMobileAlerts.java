package src.com.API.Others;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SubscribeMobileAlerts {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Others.xlsx"), "Others");

	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void subscribeMobileAlerts_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(488);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(489);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(490);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(491);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(492);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(493);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(494);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(495);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(496);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(497);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void subscribeMobileAlerts_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(498);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(499);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(500);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(501);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void subscribeMobileAlerts_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(502);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}