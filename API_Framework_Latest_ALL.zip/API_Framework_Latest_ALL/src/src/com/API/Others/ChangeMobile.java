package src.com.API.Others;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class ChangeMobile {
	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Others.xlsx"), "Others");

	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void changeMobile_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(580);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void changeMobile_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(581);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void changeMobile_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(582);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void changeMobile_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(583);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void changeMobile_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(584);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void changeMobile_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(585);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void changeMobile_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(586);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void changeMobile_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(587);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void changeMobile_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(588);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void changeMobile_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(589);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void changeMobile_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(590);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void changeMobile_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(591);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void changeMobile_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(592);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
