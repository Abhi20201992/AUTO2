package src.com.API.Others;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class PostQuery {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Others.xlsx"), "Others");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void postQuerty_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(301);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(302);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(303);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(304);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(305);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(306);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(307);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(308);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(309);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(310);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(311);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(312);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(313);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(314);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(315);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void postQuerty_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(316);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
