package src.com.API.ReportModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class IFAFinancialTransReport {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Report.xlsx"), "Report");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})

	public void ifaFinancialTransReport_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(154);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(155);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(156);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(157);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(158);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(159);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(160);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(161);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(162);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(163);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(enabled = false)
	public void ifaFinancialTransReport_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(164);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(165);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(166);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(167);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(168);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(169);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(170);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(171);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(172);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(173);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(174);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(175);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(176);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaFinancialTransReport_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(177);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
