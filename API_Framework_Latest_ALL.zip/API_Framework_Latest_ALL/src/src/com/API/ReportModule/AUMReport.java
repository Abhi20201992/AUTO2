package src.com.API.ReportModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class AUMReport {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Report.xlsx"), "Report");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})

	public void AUMReport_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(50);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(51);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(52);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(53);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(54);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(55);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(56);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(57);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(58);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(59);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(enabled = false)
	public void AUMReport_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(60);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(61);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(62);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(63);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(64);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(65);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(66);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(67);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(68);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void AUMReport_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(69);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
