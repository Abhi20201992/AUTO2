package src.com.API.ReportModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class IFATransactionReport {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Report.xlsx"), "Report");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})

	public void ifaTransactionReport_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(107);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(108);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(109);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(110);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(111);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(112);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(113);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(114);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(115);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(116);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(enabled = false)
	public void ifaTransactionReport_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(117);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(118);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(119);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(120);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(121);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(122);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(123);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(124);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(125);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(126);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(127);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(128);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(129);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(130);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(131);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_26() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(132);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_27() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(133);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void ifaTransactionReport_TC_28() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(134);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
