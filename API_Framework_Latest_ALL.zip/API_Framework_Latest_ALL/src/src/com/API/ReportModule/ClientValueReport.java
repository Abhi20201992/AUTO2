package src.com.API.ReportModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class ClientValueReport {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Report.xlsx"), "Report");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})

	public void clientValueReport_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(199);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(200);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(201);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(202);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(203);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(204);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(205);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(206);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(207);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(208);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(enabled = false)
	public void clientValueReport_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(209);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(210);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(211);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void clientValueReport_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(212);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
