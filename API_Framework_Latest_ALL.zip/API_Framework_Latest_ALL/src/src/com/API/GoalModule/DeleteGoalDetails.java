package src.com.API.GoalModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class DeleteGoalDetails {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Goal.xlsx"), "Goal");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })

	public void DeleteGoalDetails_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(125);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(126);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(127);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(128);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(129);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(130);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(131);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(132);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(133);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(134);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(135);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(136);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(137);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void DeleteGoalDetails_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(138);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
