package src.com.API.SaveAdvisor;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SavePrePurchaseMultiRequest {
	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("SaveAdvisor.xlsx"),"SaveAdvisor");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void savePrePurchaseMultiRequest_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(335);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(336);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(337);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(338);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(339);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(340);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(341);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(342);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(343);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(344);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(345);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(346);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(347);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(348);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(349);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(350);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(351);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(352);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(353);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(354);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(355);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(356);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(357);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void savePrePurchaseMultiRequest_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(358);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

}
