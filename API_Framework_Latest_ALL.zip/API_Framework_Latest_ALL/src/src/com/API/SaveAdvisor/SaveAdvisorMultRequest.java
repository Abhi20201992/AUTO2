package src.com.API.SaveAdvisor;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SaveAdvisorMultRequest {
	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("SaveAdvisor.xlsx"),"SaveAdvisor");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void saveAdvisorMultRequest_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(675);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(676);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(677);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(678);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(679);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(680);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(681);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(682);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(683);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(684);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(685);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(686);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(687);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(688);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(689);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(690);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(691);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(692);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(693);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(694);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(695);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(696);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(697);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(698);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(699);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_26() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(700);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_27() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(701);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_28() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(702);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_29() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(703);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_30() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(704);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_31() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(705);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_32() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(706);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_33() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(707);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorMultRequest_TC_34() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(708);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
