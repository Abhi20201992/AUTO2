package src.com.API.SaveAdvisor;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SaveAdvisorRequest {
	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("SaveAdvisor.xlsx"),"SaveAdvisor");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void saveAdvisorRequest_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(575);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(576);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(577);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(578);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(579);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(580);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(581);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(582);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(583);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(584);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(585);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(586);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(587);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(588);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(589);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(590);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(591);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(592);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(593);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(594);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(595);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(596);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(597);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(598);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(599);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_26() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(600);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_27() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(601);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_28() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(602);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_29() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(603);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_30() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(604);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveAdvisorRequest_TC_31() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(605);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
