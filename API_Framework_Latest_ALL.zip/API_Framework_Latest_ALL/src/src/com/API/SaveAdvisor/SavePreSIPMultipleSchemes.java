package src.com.API.SaveAdvisor;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SavePreSIPMultipleSchemes {
	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("SaveAdvisor.xlsx"), "SaveAdvisor");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void savePreSIPMultipleSchemes_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(143);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(144);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(145);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(146);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(147);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(148);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(149);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(150);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(151);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(152);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(153);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(154);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(155);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void savePreSIPMultipleSchemes_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(156);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(157);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(158);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(159);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(160);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(161);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(162);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(163);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(164);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void savePreSIPMultipleSchemes_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(165);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(166);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(167);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_26() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(168);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_27() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(169);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_28() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(170);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_29() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(171);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_30() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(172);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void savePreSIPMultipleSchemes_TC_31() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(173);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_32() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(174);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_33() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(175);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void savePreSIPMultipleSchemes_TC_34() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(176);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_35() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(177);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_36() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(178);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void savePreSIPMultipleSchemes_TC_37() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(179);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void savePreSIPMultipleSchemes_TC_38() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(180);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_39() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(181);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_40() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(182);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_41() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(183);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_42() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(184);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_43() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(185);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_44() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(186);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_45() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(187);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_46() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(188);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_47() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(189);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_48() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(190);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_49() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(191);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_50() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(192);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_51() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(193);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_52() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(194);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_53() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(195);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_54() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(196);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_55() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(197);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_56() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(198);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_57() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(199);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_58() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(200);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_59() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(201);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void savePreSIPMultipleSchemes_TC_60() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(202);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_61() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(203);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_62() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(204);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_63() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(205);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_64() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(206);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_65() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(207);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_66() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(208);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_67() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(209);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_68() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(210);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void savePreSIPMultipleSchemes_TC_69() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(211);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_70() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(212);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_71() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(213);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_72() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(214);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_73() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(215);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_74() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(216);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_75() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(217);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_76() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(218);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_77() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(219);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_78() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(220);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_79() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(221);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_80() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(222);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_81() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(223);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_82() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(224);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_83() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(225);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_84() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(226);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_85() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(227);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_86() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(228);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_87() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(229);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_88() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(230);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_89() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(231);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_90() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(232);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_91() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(233);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void savePreSIPMultipleSchemes_TC_92() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(234);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_93() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(235);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_94() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(236);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_95() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(237);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_96() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(238);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_97() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(239);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_98() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(240);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_99() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(241);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_100() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(242);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void savePreSIPMultipleSchemes_TC_101() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(243);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
