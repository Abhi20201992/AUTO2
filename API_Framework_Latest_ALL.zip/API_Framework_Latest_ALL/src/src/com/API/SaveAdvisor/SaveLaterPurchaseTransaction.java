package src.com.API.SaveAdvisor;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SaveLaterPurchaseTransaction {
	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("SaveAdvisor.xlsx"),"SaveAdvisor");
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(638);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(639);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(640);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(641);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(642);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(643);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(644);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(645);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(646);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(647);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(648);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(649);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(650);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(651);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(652);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(653);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(654);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(655);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveLaterPurchaseTransaction_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(656);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
