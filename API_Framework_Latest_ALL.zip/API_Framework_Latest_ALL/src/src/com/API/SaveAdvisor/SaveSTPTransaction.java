package src.com.API.SaveAdvisor;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SaveSTPTransaction {
	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("SaveAdvisor.xlsx"),"SaveAdvisor");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void saveSTPTransaction_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(86);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(87);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(88);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(89);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(90);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(91);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(92);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(93);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(94);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(95);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(96);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(97);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(98);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(99);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(100);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(101);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(102);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(103);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(104);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(105);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(106);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(107);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(108);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(109);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(110);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_26() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(111);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_27() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(112);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_28() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(113);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_29() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(114);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_30() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(115);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_31() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(116);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_32() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(117);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_33() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(118);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_34() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(119);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_35() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(120);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_36() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(121);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_37() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(122);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_38() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(123);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_39() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(124);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveSTPTransaction_TC_40() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(125);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	

}
