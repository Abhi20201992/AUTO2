package src.com.API.EmpanelmentModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class UpdateEmpanelmentData {

	@BeforeMethod(groups= {"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("EmpanelmentModule.xlsx"), "Empanelment");
	}

	@Test(timeOut = 20000,groups= {"Sanity", "Regression"})
	
	public void updateEmpanelmentData_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(119);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(120);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(121);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(122);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(123);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(124);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(125);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(126);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(127);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(128);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(129);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(130);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(131);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(132);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(133);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(134);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(135);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(136);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(137);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(138);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(139);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(140);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(141);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(142);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void updateEmpanelmentData_TC_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(143);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
