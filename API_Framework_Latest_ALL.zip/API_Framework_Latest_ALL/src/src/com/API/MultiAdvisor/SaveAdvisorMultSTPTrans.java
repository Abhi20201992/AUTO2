package src.com.API.MultiAdvisor;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SaveAdvisorMultSTPTrans {

	@BeforeMethod(groups = { "Sanity", "Regression" })

	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("MultiAdvisor.xlsx"),
				"SaveAdvisorMultSTPTrans");

	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void saveAdvisorMultSTPTrans_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(13);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(14);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(15);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(16);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(17);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(18);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationNoHeaderRegression(19);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationNoHeaderRegression(20);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(21);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(22);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(23);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(24);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(25);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(26);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(27);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(28);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(29);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(30);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//
	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(31);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(32);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(33);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(34);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(35);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(36);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(37);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_26() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(38);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_27() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(39);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_28() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(40);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_29() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(41);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_30() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(42);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_31() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(43);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_32() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(44);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_33() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(45);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_34() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(46);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_35() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(47);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_36() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(48);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void saveAdvisorMultSTPTrans_TC_37() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(49);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_38() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(50);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_39() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(51);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_40() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(52);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_41() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(53);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_42() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(54);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_43() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(55);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_44() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(56);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_45() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(57);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_46() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(58);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_47() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(59);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_48() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(60);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_49() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(61);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_50() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(62);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_51() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(63);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_52() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(64);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_53() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(65);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_54() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(66);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_55() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(67);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_56() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(68);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_57() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(69);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_58() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(70);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_59() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(71);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_60() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(72);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_61() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(73);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_62() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(74);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_63() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(75);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_64() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(76);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_65() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(77);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_66() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(78);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_67() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(79);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_68() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(80);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_69() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(81);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_70() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(82);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_71() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(83);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_72() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(84);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_73() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(85);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_74() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(86);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_75() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(87);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_76() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(88);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_77() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(89);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_78() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(90);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_79() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(91);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_80() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(92);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_81() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(93);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_82() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(94);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvisorMultSTPTrans_TC_83() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(95);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
