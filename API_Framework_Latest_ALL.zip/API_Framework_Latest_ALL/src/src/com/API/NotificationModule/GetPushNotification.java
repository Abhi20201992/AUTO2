package src.com.API.NotificationModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetPushNotification {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("NotificationModule.xlsx"),
				"Notification");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void GetPushNotification_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(13);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	
	public void GetPushNotification_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(14);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(15);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(16);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(17);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(18);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(19);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(20);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(21);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(22);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void GetPushNotification_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(23);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(24);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(25);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(26);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void GetPushNotification_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(27);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
