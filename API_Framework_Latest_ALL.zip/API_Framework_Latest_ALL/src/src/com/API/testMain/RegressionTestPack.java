package src.com.API.testMain;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import src.com.API.Dashboard.GetTransactionDetailsOfIFA;
import src.com.API.Dashboard.GetTransactionDetailsOfIFAOffline;
import src.com.API.Dashboard.IFAChartTrend;
import src.com.API.Dashboard.InvestmentReport;
import src.com.API.Dashboard.InvestorReport;
import src.com.API.Dashboard.SIPBookReport;
import src.com.API.Dashboard.SalesReportOfIFA;
import src.com.API.EmpanelmentModule.GetAdvEmpanelCityMaster;
import src.com.API.EmpanelmentModule.GetAdvEmpanelStateMaster;
import src.com.API.EmpanelmentModule.SaveEmpanelmentData;
import src.com.API.GetTransaction.GetAccountStatementByFolio;
import src.com.API.GetTransaction.GetAdvPurchaseTran;
import src.com.API.GetTransaction.GetAdvSIPTran;
import src.com.API.GetTransaction.GetAdvSwitchTrans;
import src.com.API.GetTransaction.GetCustomerDetailsByFolio;
import src.com.API.GetTransaction.GetIRAdvForTransNumber;
import src.com.API.GetTransaction.GetIRDetailsForFolio;
import src.com.API.GetTransaction.GetSTPAdvisorTran;
import src.com.API.GetTransaction.GetSWPAdvisorTran;
import src.com.API.Investor.GetCustomerListofBroker;
import src.com.API.Investor.GetLinkedCustomerofBroker;
import src.com.API.LiquidAppModule.ForgotUserName;
import src.com.API.LiquidAppModule.GetInvestorAuthentication;
import src.com.API.LiquidAppModule.GetTransationForFolioNo;
import src.com.API.LiquidAppModule.LogoutUser;
import src.com.API.LiquidAppModule.ValidateARNNO;
import src.com.API.LiquidAppModule.ValidateEmailIdAndPAN;
import src.com.API.LiquidAppModule.ValidateFATCA;
import src.com.API.LiquidAppModule.ValidateInvestor;
import src.com.API.LoginModule.AuthenticateIFAwithEUIN;
import src.com.API.LoginModule.GenerateAuthCode;
import src.com.API.LoginModule.LogoutIFAUser;
import src.com.API.LoginModule.RegisterIFAwithEUIN;
import src.com.API.LoginModule.UnsubscribeIFA;
import src.com.API.LoginModule.UpdateIFAWithEuinPassword;
import src.com.API.LoginModule.ValidateIFA;
import src.com.API.LoginModule.validateIFAWithEUIN;
import src.com.API.Note.DeleteNoteAndReminder;
import src.com.API.Note.GetNoteAndReminder;
import src.com.API.Note.SaveNotesMasterList;
import src.com.API.NotificationModule.GetPushNotification;
import src.com.API.NotificationModule.UpdateNotificationDetailsRead;
import src.com.API.Others.CallBack;
import src.com.API.Others.CheckAadharAvailable;
import src.com.API.Others.GetAccountStatement;
import src.com.API.Others.GetBranchMasterList;
import src.com.API.Others.GetBrokerInformationDetails;
import src.com.API.Others.GetCountryList;
import src.com.API.Others.GetMasterDataByType;
import src.com.API.Others.GetNAVonDateRange;
import src.com.API.Others.GetSchemeMasterDetails;
import src.com.API.Others.PostQuery;
import src.com.API.Others.SentCallBack;
import src.com.API.RegistrationModule.BranchBasedOnLocationRequest;
import src.com.API.RegistrationModule.CheckKYCStatus;
import src.com.API.RegistrationModule.GenerateOTP;
import src.com.API.RegistrationModule.GetBranchDetail;
import src.com.API.RegistrationModule.GetFPurchaseBrachCity;
import src.com.API.RegistrationModule.GetFPurchaseBranch;
import src.com.API.RegistrationModule.GetIfscPurchasebankDetails;
import src.com.API.RegistrationModule.GetStateCityList;
import src.com.API.RegistrationModule.NewFolioCreation;
import src.com.API.RegistrationModule.UpdateFatca;
import src.com.API.RegistrationModule.ValidateAadharno;
import src.com.API.RegistrationModule.ValidateAdharOTP;
import src.com.API.RegistrationModule.ValidatePan;
import src.com.API.ReportModule.AUMReport;
import src.com.API.ReportModule.ClientValueReport;
import src.com.API.ReportModule.IFABrokPerformanceReport;
import src.com.API.ReportModule.IFABrokerageReport;
import src.com.API.ReportModule.IFAFinancialTransReport;
import src.com.API.ReportModule.IFATransactionReport;
import src.com.API.Transaction.GetFPurchaseBanks;
import src.com.API.Transaction.GetISIPBankBranch;
import src.com.API.Transaction.GetISIPBankCity;
import src.com.API.Transaction.GetISIPBanks;
import src.com.API.Transaction.GetMultiRedemptionDetails;
import src.com.API.Transaction.GetMultiSTPDetails;
import src.com.API.Transaction.GetMultiSWPDetails;
import src.com.API.Transaction.InvestorListOfIFA;
import src.com.API.Transaction.SaveAdvRedeemAdvice;
import src.com.API.Transaction.SaveAdvSwitchAdvice;
import src.com.API.Transaction.SaveAdvSwitchAdviceMultiple;
import src.com.API.Transaction.SaveSWPAdvisorTran;
import src.com.API.Transaction.SaveSWPTransaction;
import src.com.API.Transaction.SendAdviseToInvestor;

@RunWith(Suite.class)	
@Suite.SuiteClasses({
	
 //LoginModule
 validateIFAWithEUIN.class,
 AuthenticateIFAwithEUIN.class,
 UpdateIFAWithEuinPassword.class,
 GenerateAuthCode.class,
 ValidateIFA.class,
 RegisterIFAwithEUIN.class,
 LogoutIFAUser.class,
 UnsubscribeIFA.class,
 
 // Dashboard
 GetTransactionDetailsOfIFA.class,
 GetTransactionDetailsOfIFAOffline.class,
 IFAChartTrend.class,
 InvestmentReport.class,
 InvestorReport.class,
 SalesReportOfIFA.class,
 SIPBookReport.class,
 
 //GetTransaction
 GetAccountStatementByFolio.class,
 GetAdvPurchaseTran.class,
 GetAdvSIPTran.class,
 GetAdvSwitchTrans.class,
 GetCustomerDetailsByFolio.class,
 GetIRAdvForTransNumber.class,
 GetIRDetailsForFolio.class,
 GetSTPAdvisorTran.class,
 GetSWPAdvisorTran.class,
 
 //Investor
 GetCustomerListofBroker.class,
 GetLinkedCustomerofBroker.class,
 
 //LiquidAppModule
 ForgotUserName.class,
 GetInvestorAuthentication.class,
 GetTransationForFolioNo.class,
 LogoutUser.class,
 ValidateARNNO.class,
 ValidateEmailIdAndPAN.class,
 ValidateFATCA.class,
 ValidateInvestor.class,
 
 //NotificationModule
 GetPushNotification.class,
 UpdateNotificationDetailsRead.class,
 
 //Others
 CallBack.class,
 CheckAadharAvailable.class,
 GetAccountStatement.class,
 GetBranchMasterList.class,
 GetBrokerInformationDetails.class,
 GetCountryList.class,
 GetMasterDataByType.class,
 GetNAVonDateRange.class,
 GetSchemeMasterDetails.class,
 PostQuery.class,
 SentCallBack.class,
 
 //RegistrationModule
 BranchBasedOnLocationRequest.class,
 CheckKYCStatus.class,
 GenerateOTP.class,
 GetBranchDetail.class,
 GetFPurchaseBrachCity.class,
 GetFPurchaseBranch.class,
 GetIfscPurchasebankDetails.class,
 GetStateCityList.class,
 NewFolioCreation.class,
 UpdateFatca.class,
 ValidateAadharno.class,
 ValidateAdharOTP.class,
 ValidatePan.class,
 
 //ReportModule
 AUMReport.class,
 ClientValueReport.class,
 IFABrokerageReport.class,
 IFABrokPerformanceReport.class,
 IFAFinancialTransReport.class,
 IFATransactionReport.class,
 
 //Transaction
 GetFPurchaseBanks.class,
 GetISIPBankBranch.class,
 GetISIPBankCity.class,
 GetISIPBanks.class,
 GetMultiRedemptionDetails.class,
 GetMultiSTPDetails.class,
 GetMultiSWPDetails.class,
 InvestorListOfIFA.class,
 SaveAdvRedeemAdvice.class,
 SaveAdvSwitchAdvice.class,
 SaveSWPAdvisorTran.class,
 SaveSWPTransaction.class,
 SendAdviseToInvestor.class,
 SaveAdvSwitchAdviceMultiple.class,
 
 //EmpanelmentModule
 GetAdvEmpanelCityMaster.class,
 GetAdvEmpanelStateMaster.class,
 SaveEmpanelmentData.class,
 
 //Note
 GetNoteAndReminder.class,
 SaveNotesMasterList.class,
 DeleteNoteAndReminder.class,
 
})		

public class RegressionTestPack {				
			// This class remains empty, it is used only as a holder for the above annotations		
}