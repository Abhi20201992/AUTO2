package src.com.API.testMain;

import org.apache.http.client.ClientProtocolException;

public class SanityTestMain {

	public static void main(String args[]) throws ClientProtocolException, Exception {

		/*ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData,"Sanity");
		for(int i=1;i<50;i++) {
	     	
			APIOperation.apiOperationNoHeaderSanity(i);
		    
		}*/
		 Runtime.getRuntime().gc();
		 
		
	}
}
