package src.com.API.testMain;

public class HeapSizeExample {

    public static void main(String[] args) {
    	// get the runtime object associated with the current Java application
    			Runtime runtime = Runtime.getRuntime();
    			
    			long freeMemory = runtime.freeMemory();
    			System.out.println("Free memory in JVM (bytes): " + freeMemory);
    			
    			// Runs the garbage collector. Calling this method suggests that the Java virtual machine expend 
    		    // effort toward recycling unused objects in order to make memory they occupy available for reuse
    			runtime.gc();
    			
    			freeMemory = runtime.freeMemory();
    			System.out.println("Free memory in JVM (bytes): " + freeMemory);
    			
    }
}