package src.com.API.LoginModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class ValidateIFA {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Login.xlsx"), "Login");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void ValidateIFA_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(209);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(210);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(211);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(212);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(213);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(214);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(215);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(216);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(217);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(218);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(219);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(220);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(221);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(222);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(223);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(224);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(225);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void ValidateIFA_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(226);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}