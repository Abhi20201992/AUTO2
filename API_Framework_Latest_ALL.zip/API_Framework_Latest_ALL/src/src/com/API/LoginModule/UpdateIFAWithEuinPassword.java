package src.com.API.LoginModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class UpdateIFAWithEuinPassword {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Login.xlsx"), "Login");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void updateIFAWithEuinPassword_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(90);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(91);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(92);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(93);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(94);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(95);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(96);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(97);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(98);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(99);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(100);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(101);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(102);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(103);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(104);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(105);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(106);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(107);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(108);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void updateIFAWithEuinPassword_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(109);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}