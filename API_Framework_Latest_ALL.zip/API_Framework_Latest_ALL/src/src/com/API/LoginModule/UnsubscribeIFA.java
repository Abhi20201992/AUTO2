package src.com.API.LoginModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class UnsubscribeIFA {
	
	@BeforeMethod(groups = { "Sanity", "Regression" })
		public void beforeMethod() throws Exception {
			DOMConfigurator.configure("log4j.xml");

			ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Login.xlsx"), "Login");
		}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
		public void UnsubscribeIFA_TC_01() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(280);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
	@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_02() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(281);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_03() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(282);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_04() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(283);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_05() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(284);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_06() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(285);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_07() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(286);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_08() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(287);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_09() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(288);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_10() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(289);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_11() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(290);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_12() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(291);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_13() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(292);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_14() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(293);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_15() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(294);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_16() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(295);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_17() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(296);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_18() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(297);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		@Test(timeOut = 20000, groups = { "Regression" })
		public void UnsubscribeIFA_TC_19() throws Exception {
			try {
				APIOperation.post_apiOperationWithHeaderRegression(298);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		

}

