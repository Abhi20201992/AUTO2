package src.com.API.LoginModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class RegisterIFAwithEUIN {
	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Login.xlsx"), "Login");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void registerIFAwithEUIN_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(130);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(131);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(132);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_04() throws Exception {

		try {
			APIOperation.post_apiOperationWithHeaderRegression(133);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(134);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(135);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(136);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(137);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(138);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_10() throws Exception {

		try {
			APIOperation.post_apiOperationWithHeaderRegression(139);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(140);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(141);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(142);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(143);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(144);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(145);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(146);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(147);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(timeOut = 20000, groups = { "Regression" })
	public void registerIFAwithEUIN_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(148);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
