package src.com.API.ProductModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetSchemeHolding {

	
	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Product.xlsx"), "Product");
	}
	
	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	
	public void GetSchemeHolding_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(62);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	@Test(timeOut = 20000,groups ={"Regression"})
	
	public void GetSchemeHolding_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(63);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

@Test(timeOut = 20000,groups ={"Regression"})

public void GetSchemeHolding_TC_03() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(64);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void GetSchemeHolding_TC_04() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(65);
	} catch (Exception e) {
		e.printStackTrace();
	}

}



@Test(timeOut = 20000,groups ={"Regression"})

public void GetSchemeHolding_TC_06() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(67);
	} catch (Exception e) {
		e.printStackTrace();
	}

}
}
