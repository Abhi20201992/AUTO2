package src.com.API.ProductModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetSchemeHistoricalReturn {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Product.xlsx"), "Product");
	}
	
	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	
	public void GetSchemeHistoricalReturn_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(80);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	@Test(timeOut = 20000,groups ={"Regression"})
	
	public void GetSchemeHistoricalReturn_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(81);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

@Test(timeOut = 20000,groups ={"Regression"})

public void GetSchemeHistoricalReturn_TC_03() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(82);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void GetSchemeHistoricalReturn_TC_04() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(83);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void GetSchemeHistoricalReturn_TC_05() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(84);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void GetSchemeHistoricalReturn_TC_06() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(85);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void GetSchemeHistoricalReturn_TC_07() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(86);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void GetSchemeHistoricalReturn_TC_08() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(87);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void GetSchemeHistoricalReturn_TC_09() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(88);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

}
