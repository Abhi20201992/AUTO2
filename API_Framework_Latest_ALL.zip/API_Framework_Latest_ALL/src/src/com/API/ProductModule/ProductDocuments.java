package src.com.API.ProductModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class ProductDocuments {

	
	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Product.xlsx"), "Product");
	}
	
	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	
	public void ProductDocuments_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(42);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	@Test(timeOut = 20000,groups ={"Regression"})
	
	public void ProductDocuments_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(43);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

@Test(timeOut = 20000,groups ={"Regression"})

public void ProductDocuments_TC_03() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(44);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void ProductDocuments_TC_04() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(45);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void ProductDocuments_TC_05() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(46);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void ProductDocuments_TC_06() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(47);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void ProductDocuments_TC_07() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(48);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void ProductDocuments_TC_08() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(49);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void ProductDocuments_TC_09() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(50);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void ProductDocuments_TC_10() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(51);
	} catch (Exception e) {
		e.printStackTrace();
	}

}

@Test(timeOut = 20000,groups ={"Regression"})

public void ProductDocuments_TC_11() throws Exception {
	try {
		APIOperation.post_apiOperationWithHeaderRegression(52);
	} catch (Exception e) {
		e.printStackTrace();
	}

}
}
