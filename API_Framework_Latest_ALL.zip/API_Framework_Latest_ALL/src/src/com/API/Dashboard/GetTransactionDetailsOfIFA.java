package src.com.API.Dashboard;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetTransactionDetailsOfIFA {

	@BeforeMethod(groups= {"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Dashboard.xlsx"),"Dashboard");
	}

	@Test(timeOut = 20000,groups= {"Sanity", "Regression"})
	public void getTransactionDetailsOfIFA_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(13);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(14);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(15);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(16);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(17);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(18);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(19);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(20);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(21);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(22);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(23);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(24);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(25);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(26);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(27);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(28);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(29);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(30);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(31);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups= { "Regression"})
	public void getTransactionDetailsOfIFA_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(32);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
