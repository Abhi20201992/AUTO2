package src.com.API.Dashboard;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetSchemeHistoricalReturn {
	@BeforeMethod(groups ={"Sanity", "Regression"})
	
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Dashboard.xlsx"),"Dashboard");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	
	public void getSchemeHistoricalReturn_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(233);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	
	public void getSchemeHistoricalReturn_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(234);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void getSchemeHistoricalReturn_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(235);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void getSchemeHistoricalReturn_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(236);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void getSchemeHistoricalReturn_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(237);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void getSchemeHistoricalReturn_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(238);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void getSchemeHistoricalReturn_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(239);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void getSchemeHistoricalReturn_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(240);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test(timeOut = 20000,groups ={"Regression"})
	public void getSchemeHistoricalReturn_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(241);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
