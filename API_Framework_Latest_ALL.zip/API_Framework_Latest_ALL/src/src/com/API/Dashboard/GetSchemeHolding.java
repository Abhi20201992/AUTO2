package src.com.API.Dashboard;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetSchemeHolding {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Dashboard.xlsx"), "Dashboard");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void getSchemeHolding_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(214);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHolding_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(215);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHolding_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(216);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHolding_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(217);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHolding_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(218);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getSchemeHolding_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(219);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
