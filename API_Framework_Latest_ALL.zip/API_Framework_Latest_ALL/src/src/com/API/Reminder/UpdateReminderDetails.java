package src.com.API.Reminder;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class UpdateReminderDetails {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Reminder.xlsx"), "Reminder");

	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void updateReminderDetails_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(99);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(100);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(101);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(102);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(103);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(104);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(105);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(106);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(107);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(108);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(109);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(110);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(111);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(112);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(113);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(114);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(115);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(116);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(117);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(118);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(119);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(120);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(121);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(122);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(123);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_26() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(124);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_27() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(125);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_28() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(126);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void updateReminderDetails_29() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(127);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}