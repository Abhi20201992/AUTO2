package src.com.API.Reminder;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SaveReminderDetails {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Reminder.xlsx"), "Reminder");

	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void saveReminderDetails_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(49);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(50);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(51);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(52);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(53);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(54);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(55);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(56);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(57);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(58);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(59);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(60);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(61);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(62);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(63);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(64);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(65);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(66);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(67);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(68);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(69);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(70);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(71);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(72);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(73);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_26() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(74);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_27() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(75);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_28() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(76);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_29() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(77);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_30() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(78);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void saveReminderDetails_31() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(79);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
