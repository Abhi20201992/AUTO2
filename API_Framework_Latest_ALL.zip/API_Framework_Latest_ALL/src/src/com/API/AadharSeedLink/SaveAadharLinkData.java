package src.com.API.AadharSeedLink;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SaveAadharLinkData {

	@BeforeMethod(groups= {"Sanity", "Regression"})
	
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("AadharSeedLink.xlsx"), "AadharSeedLink");
	}

	@Test(timeOut=20000,groups= {"Sanity", "Regression"})
	
	public void saveAadharLinkData_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(103);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(104);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(105);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(106);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(107);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(108);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(109);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(110);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(111);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(112);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(113);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(114);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(115);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(116);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(117);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(118);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(119);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(120);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(121);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(122);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(123);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(124);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(125);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(126);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut=20000,groups= {"Regression"})
	public void saveAadharLinkData_TC_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(127);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
