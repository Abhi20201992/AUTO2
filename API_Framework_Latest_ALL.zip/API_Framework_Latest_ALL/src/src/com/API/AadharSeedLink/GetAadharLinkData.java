package src.com.API.AadharSeedLink;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetAadharLinkData {

	@BeforeMethod(groups = { "Sanity", "Regression" })

	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("AadharSeedLink.xlsx"),
				"AadharSeedLink");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void getAadharLinkData_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(73);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getAadharLinkData_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(74);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getAadharLinkData_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(75);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getAadharLinkData_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(76);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getAadharLinkData_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(77);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getAadharLinkData_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(78);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAadharLinkData_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(79);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getAadharLinkData_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(80);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getAadharLinkData_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(81);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })

	public void getAadharLinkData_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(82);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(enabled=false, groups = { "Regression" })

	public void getAadharLinkData_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(83);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
