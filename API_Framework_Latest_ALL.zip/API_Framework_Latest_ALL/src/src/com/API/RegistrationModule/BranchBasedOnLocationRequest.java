package src.com.API.RegistrationModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class BranchBasedOnLocationRequest {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("RegistrationModule.xlsx"), "Registration");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})

	public void branchBasedOnLocationRequest_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(184);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(185);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(186);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(187);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(188);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(189);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(190);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(191);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(192);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(193);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(194);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(195);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(196);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(197);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void branchBasedOnLocationRequest_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(198);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
