package src.com.API.RegistrationModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetBranchDetail {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("RegistrationModule.xlsx"), "Registration");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})

	public void getBranchDetail_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(218);

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(219);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(220);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(221);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(222);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(223);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(224);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(225);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(226);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(227);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(228);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(229);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(230);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(231);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getBranchDetail_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(232);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}