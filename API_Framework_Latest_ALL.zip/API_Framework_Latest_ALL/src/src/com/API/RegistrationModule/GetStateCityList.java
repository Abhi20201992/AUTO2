package src.com.API.RegistrationModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetStateCityList {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("RegistrationModule.xlsx"), "Registration");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})

	public void getStateCityList_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(88);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getStateCityList_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(89);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getStateCityList_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(90);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getStateCityList_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(91);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getStateCityList_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(92);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getStateCityList_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(93);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getStateCityList_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(94);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getStateCityList_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(95);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getStateCityList_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(96);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getStateCityList_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(97);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
