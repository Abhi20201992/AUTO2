package src.com.API.RegistrationModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetFPurchaseBranch {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("RegistrationModule.xlsx"), "Registration");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})

	public void getFPurchaseBranch_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(149);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(150);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(151);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(152);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(153);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(154);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(155);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(156);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(157);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(158);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(159);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(160);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(161);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(162);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(163);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void getFPurchaseBranch_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(164);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
