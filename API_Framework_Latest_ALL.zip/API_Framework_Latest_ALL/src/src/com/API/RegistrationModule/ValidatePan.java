package src.com.API.RegistrationModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class ValidatePan {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("RegistrationModule.xlsx"),
				"Registration");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})

	public void validatePan_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(405);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(406);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(407);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(408);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(409);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(410);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(411);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(412);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(413);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(414);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(415);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(416);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(417);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(418);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(419);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(timeOut = 20000,groups ={"Regression"})

	public void validatePan_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(420);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(enabled = false)
	public void validatePan_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(421);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
