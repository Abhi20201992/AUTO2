package src.com.API.RegistrationModule;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class NewFolioCreation {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("RegistrationModule.xlsx"),
				"Registration");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void newFolioCreation_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(441);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(442);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(443);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(444);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(445);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(446);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(447);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(448);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(449);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(450);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(451);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(452);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(453);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(454);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(455);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(456);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(457);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(458);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(459);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(460);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(461);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(462);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(463);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_24() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(464);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_25() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(465);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_26() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(466);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_27() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(467);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_28() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(468);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_29() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(469);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_30() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(470);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_31() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(471);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_32() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(472);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_33() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(473);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_34() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(474);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_35() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(475);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_36() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(476);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_37() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(477);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_38() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(478);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_39() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(479);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_40() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(480);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_41() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(481);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_42() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(482);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_43() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(483);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_44() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(484);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_45() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(485);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_46() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(486);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_47() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(487);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_48() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(488);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_49() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(489);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_50() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(490);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_51() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(491);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_52() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(492);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_53() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(493);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_54() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(494);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_55() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(495);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_56() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(496);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_57() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(497);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_58() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(498);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_59() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(499);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_60() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(500);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_61() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(501);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_62() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(502);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_63() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(503);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_64() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(504);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_65() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(505);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_66() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(506);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_67() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(507);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_68() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(508);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_69() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(509);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_70() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(510);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_71() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(511);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_72() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(512);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_73() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(513);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_74() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(514);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_75() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(515);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_76() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(516);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_77() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(517);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_78() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(518);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_79() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(519);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_80() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(520);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_81() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(521);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_82() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(522);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_83() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(523);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_84() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(524);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_85() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(525);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_86() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(526);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_87() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(527);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_88() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(528);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_89() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(529);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_90() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(530);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_91() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(531);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_92() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(532);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_93() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(533);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_94() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(534);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_95() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(535);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void newFolioCreation_TC_96() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(536);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
