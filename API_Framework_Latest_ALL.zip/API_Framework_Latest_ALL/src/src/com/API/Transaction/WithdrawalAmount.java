package src.com.API.Transaction;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class WithdrawalAmount {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Transaction.xlsx"), "Transaction");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void withdrawalAmount_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(605);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(606);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(607);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(608);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(609);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(610);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(611);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(612);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(613);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(614);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(615);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(616);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(617);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(618);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(619);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(620);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(621);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(622);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(623);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(624);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(625);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(626);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void withdrawalAmount_TC_23() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(627);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
