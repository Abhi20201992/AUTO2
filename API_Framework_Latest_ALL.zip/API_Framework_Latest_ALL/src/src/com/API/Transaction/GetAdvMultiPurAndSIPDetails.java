package src.com.API.Transaction;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetAdvMultiPurAndSIPDetails {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforeMethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Transaction.xlsx"), "Transaction");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(541);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(542);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(543);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(544);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(545);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(546);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(547);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(548);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(549);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(550);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(551);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(552);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(553);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(554);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(555);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(556);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getAdvMultiPurAndSIPDetails_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(557);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}