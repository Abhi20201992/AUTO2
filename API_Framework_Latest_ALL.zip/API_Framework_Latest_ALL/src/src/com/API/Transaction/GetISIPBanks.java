package src.com.API.Transaction;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetISIPBanks {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Transaction.xlsx"), "Transaction");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void getISIPBanks_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(335);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getISIPBanks_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(336);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getISIPBanks_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(337);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getISIPBanks_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(338);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getISIPBanks_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(339);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getISIPBanks_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(340);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getISIPBanks_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(341);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getISIPBanks_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(342);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getISIPBanks_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(343);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
