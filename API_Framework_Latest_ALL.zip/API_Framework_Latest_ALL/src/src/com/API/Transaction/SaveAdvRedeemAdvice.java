package src.com.API.Transaction;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class SaveAdvRedeemAdvice {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Transaction.xlsx"), "Transaction");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void saveAdvRedeemAdvice_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(59);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(60);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(61);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(62);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(63);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(64);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(65);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(66);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(67);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(68);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(69);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(70);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(71);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(72);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(73);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_16() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(74);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_17() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(75);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_18() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(76);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_19() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(77);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_20() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(78);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_21() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(79);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void saveAdvRedeemAdvice_TC_22() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(80);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
