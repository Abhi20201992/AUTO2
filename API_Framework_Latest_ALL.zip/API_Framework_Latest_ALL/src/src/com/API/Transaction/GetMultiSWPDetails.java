package src.com.API.Transaction;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetMultiSWPDetails {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Transaction.xlsx"), "Transaction");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void getMultiSWPDetails_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(275);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(276);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(277);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(278);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(279);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(280);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(281);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(282);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(283);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(284);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(285);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(286);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void getMultiSWPDetails_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(287);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
