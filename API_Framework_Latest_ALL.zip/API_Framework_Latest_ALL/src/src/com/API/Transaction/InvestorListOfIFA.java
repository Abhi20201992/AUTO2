package src.com.API.Transaction;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class InvestorListOfIFA {

	@BeforeMethod(groups = { "Sanity", "Regression" })
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Transaction.xlsx"), "Transaction");
	}

	@Test(timeOut = 20000, groups = { "Sanity", "Regression" })
	public void investorListOfIFA_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(363);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(364);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(365);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(366);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(367);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(368);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(369);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(370);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(371);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(372);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(373);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(374);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(375);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_14() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(376);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000, groups = { "Regression" })
	public void investorListOfIFA_TC_15() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(377);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
