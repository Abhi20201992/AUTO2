package src.com.API.Transaction;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class GetMultiSTPDetails {

	@BeforeMethod(groups ={"Sanity", "Regression"})
	public void beforemethod() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("Transaction.xlsx"), "Transaction");
	}

	@Test(timeOut = 20000,groups ={"Sanity", "Regression"})
	public void getMultiSTPDetails_TC_01() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegressionLargeOutput(243);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_02() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(244);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_03() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(245);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_04() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(246);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_05() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(247);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_06() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(248);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_07() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(249);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_08() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(250);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_09() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(251);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_10() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(252);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_11() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(253);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_12() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(254);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(timeOut = 20000,groups ={"Regression"})
	public void getMultiSTPDetails_TC_13() throws Exception {
		try {
			APIOperation.post_apiOperationWithHeaderRegression(255);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
