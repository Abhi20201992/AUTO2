package Sanity;

import org.apache.log4j.xml.DOMConfigurator;
import src.com.Lib.ExcelInputOutput.Constant;
import src.com.Lib.ExcelInputOutput.ExcelUtils;
import src.com.Lib.test.APIOperation;

public class Sanity {

	public static void main(String args[]) throws Exception {
		DOMConfigurator.configure("log4j.xml");

		ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.setfile_TestData("MultiAdvisor.xlsx"), "SaveAdvisorMultSTPTrans");


		for (int i = 21; i <= 95; i++) {
			APIOperation.post_apiOperationWithHeaderSanity(i);;

		}
	}

}
